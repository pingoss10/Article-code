import numpy as np
from scipy.ndimage import gaussian_filter
from networkx import shortest_path
from noaa_validation import great_circle_km

def network_route(graph, start, finish):
    return shortest_path(graph, source=start, target=finish, weight='weight')

def trajectory_passage_frequency(trajectories, lon_bins, lat_bins, smooth=1):
    counts = np.zeros((len(lat_bins) - 1, len(lon_bins) - 1), dtype=float)
    if not len(trajectories):
        raise ValueError('At least one trajectory is needed')
    for path in trajectories:
        points = np.asarray(path, dtype=float)
        lon_index = np.digitize(points[:, 0], lon_bins) - 1
        lat_index = np.digitize(points[:, 1], lat_bins) - 1
        mask = (lon_index >= 0) & (lon_index < counts.shape[1]) & (lat_index >= 0) & (lat_index < counts.shape[0])
        if np.any(mask):
            cells = np.unique(np.column_stack([lat_index[mask], lon_index[mask]]), axis=0)
            counts[cells[:, 0], cells[:, 1]] += 1
    return gaussian_filter(counts / len(trajectories), sigma=smooth)

def trajectory_corridor_overlap(trajectories, route_lon, route_lat, radius_km=600):
    route_lon = np.asarray(route_lon, dtype=float)
    route_lat = np.asarray(route_lat, dtype=float)
    scores = []
    for path in trajectories:
        points = np.asarray(path, dtype=float)
        if len(points) == 0:
            scores.append(np.nan)
            continue
        distances = great_circle_km(points[:, 1, None], points[:, 0, None], route_lat[None, :], route_lon[None, :])
        scores.append(np.mean(np.min(distances, axis=1) <= radius_km))
    return np.asarray(scores)

def empirical_pathway_p_value(real_overlaps, null_overlaps):
    observed = np.nanmean(real_overlaps)
    null = np.asarray(null_overlaps, dtype=float)
    if null.ndim != 2:
        raise ValueError('Null overlaps must have shape (realizations, trajectories)')
    averages = np.nanmean(null, axis=1)
    averages = averages[np.isfinite(averages)]
    if not len(averages):
        raise ValueError('No valid null pathways')
    p_value = (1 + np.sum(averages >= observed)) / (len(averages) + 1)
    return {'observed': observed, 'null_means': averages, 'p_value': p_value, 'p90': np.percentile(averages, 90)}
