import numpy as np
from scipy.stats import mannwhitneyu

def longitude_weighted_profile(lon, lat, values, lat_bounds=(35, 60)):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    values = np.asarray(values, dtype=float)
    valid = np.isfinite(lon) & np.isfinite(lat) & np.isfinite(values) & (lat >= lat_bounds[0]) & (lat <= lat_bounds[1])
    longitudes = np.round(lon[valid], 6)
    unique = np.sort(np.unique(longitudes))
    profile = np.full(len(unique), np.nan)
    for k, longitude in enumerate(unique):
        selected = longitudes == longitude
        weights = np.cos(np.deg2rad(lat[valid][selected]))
        profile[k] = np.average(values[valid][selected], weights=weights)
    return (unique, profile)

def wave_degree_associations(out_degree, in_degree, wave_anomaly, positive_tail=10, negative_tail=10):
    outgoing = np.asarray(out_degree, dtype=float)
    incoming = np.asarray(in_degree, dtype=float)
    wave = np.asarray(wave_anomaly, dtype=float)
    valid = np.isfinite(outgoing) & np.isfinite(incoming) & np.isfinite(wave)
    outgoing, incoming, wave = (outgoing[valid], incoming[valid], wave[valid])
    positive = wave >= np.percentile(wave, 100 - positive_tail)
    negative = wave <= np.percentile(wave, negative_tail)
    out_test = mannwhitneyu(outgoing[positive], outgoing[~positive], alternative='greater')
    in_test = mannwhitneyu(incoming[negative], incoming[~negative], alternative='greater')
    return {'positive_mask': positive, 'negative_mask': negative, 'out_u': out_test.statistic, 'out_p': out_test.pvalue, 'in_u': in_test.statistic, 'in_p': in_test.pvalue}

def composite_phase_locked_wave(weekly_wind, selected_weeks):
    return np.asarray(weekly_wind)[np.asarray(selected_weeks)].mean(axis=0)
