import numpy as np
from scipy.stats import linregress
from noaa_validation import great_circle_km

def pairwise_distances(lat, lon):
    lat = np.asarray(lat, dtype=float)
    lon = np.asarray(lon, dtype=float)
    return great_circle_km(lat[:, None], lon[:, None], lat[None, :], lon[None, :])

def significant_edge_distances(adjacency, distance, either_direction=False):
    adjacency = np.asarray(adjacency, dtype=bool)
    selected = adjacency | adjacency.T if either_direction else adjacency
    indices = np.triu_indices_from(selected, 1)
    return np.asarray(distance)[indices][selected[indices]]

def link_length_density(distances, bins=44, smoothing=2, clip_upper=99.5):
    values = np.asarray(distances, dtype=float)
    values = values[np.isfinite(values)]
    if not len(values):
        raise ValueError('No valid significant-edge distances')
    values = values[values <= np.percentile(values, clip_upper)]
    density, edges = np.histogram(values, bins=bins, density=True)
    if smoothing > 1:
        density = np.convolve(density, np.ones(smoothing) / smoothing, mode='same')
    return ((edges[1:] + edges[:-1]) / 2, density)

def log_log_slope(distance, density, fit_bounds):
    x = np.asarray(distance, dtype=float)
    y = np.asarray(density, dtype=float)
    mask = (x >= fit_bounds[0]) & (x <= fit_bounds[1]) & (x > 0) & (y > 0) & np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 2:
        raise ValueError('At least two positive bins are required for the fit')
    result = linregress(np.log10(x[mask]), np.log10(y[mask]))
    return (result.slope, result.intercept, result.rvalue ** 2)
