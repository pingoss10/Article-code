import numpy as np
import networkx as nx

def network_graph(weights, lags, distance_km, step_limit_km=1000, include_zero_lag=False):
    weights = np.asarray(weights, dtype=float)
    lags = np.asarray(lags)
    distance_km = np.asarray(distance_km, dtype=float)
    if weights.shape != lags.shape or weights.shape != distance_km.shape:
        raise ValueError('Weights, lags and distances must have identical shapes')
    n = weights.shape[0]
    graph = nx.DiGraph()
    graph.add_nodes_from(range(n))
    for i, j in zip(*np.where(np.isfinite(weights) & (weights != 0) & (distance_km < step_limit_km))):
        if i == j or (lags[i, j] == 0 and (not include_zero_lag)):
            continue
        if lags[i, j] > 0 or (include_zero_lag and lags[i, j] == 0):
            graph.add_edge(int(i), int(j), weight=float(abs(1 / weights[i, j])))
        elif lags[i, j] < 0:
            graph.add_edge(int(j), int(i), weight=float(abs(1 / weights[i, j])))
    return graph

def optimal_path(graph, source, target):
    return nx.dijkstra_path(graph, source, target, weight='weight')

def path_coordinates(path, lon, lat):
    ids = np.asarray(path, dtype=int)
    return (np.asarray(lon)[ids], np.asarray(lat)[ids])

def shuffled_weight_paths(graph, source, target, iterations=1000, seed=0):
    random = np.random.default_rng(seed)
    edges = list(graph.edges())
    weights = np.array([graph[u][v]['weight'] for u, v in edges])
    paths = []
    for _ in range(iterations):
        permuted = random.permutation(weights)
        randomized = nx.DiGraph()
        randomized.add_nodes_from(graph.nodes())
        randomized.add_weighted_edges_from(((u, v, float(w)) for (u, v), w in zip(edges, permuted)))
        paths.append(nx.dijkstra_path(randomized, source, target, weight='weight'))
    return paths
