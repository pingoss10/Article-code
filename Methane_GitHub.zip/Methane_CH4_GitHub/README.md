# Atmospheric Methane Connectivity — Analysis and Visualization

This repository provides core computational methods and figure-creation code for an atmospheric methane connectivity study. Figure rendering has been preserved, including panel arrangements, map projections, colormaps, individual colors, colorbars, legends, arrows, and graphical annotations.

## Organization

- `gosat_preprocessing.py`, `lagged_network.py`, and the other top-level modules contain reusable computational routines.
- `figures/` contains manuscript figure implementations and their display settings.
- `figures/analysis_versions/` contains alternative analysis and visualization scripts.
- `workflows/` contains processing, network-construction, and station-validation workflows.
- `tests/` provides limited computational checks.

## Data and file paths

The original local dataset and output file names have been replaced by generic, descriptive placeholders throughout the Python source. For example, scripts now refer to `data/node_longitudes.npy`, `data/node_latitudes.npy`, `data/pairwise_distances.npy`, and generic network/trajectory inputs. Original computer-specific file paths are not included.

To run the scripts, provide the required scientific data and adjust these placeholders to the paths of your local data files. **The renamed paths are placeholders, not links to downloadable source data.** Some figure scripts rely on computed variables from earlier analysis sessions, and are not stand-alone reproduction scripts.

## Plotting integrity

Source plotting calls, explicit color hex codes, map projections, layout settings, and graphical style assignments have not been removed or altered by the file-name anonymization. No raw GOSAT, NOAA, ERA5, HYSPLIT, or derived model arrays are distributed here.

## Dependencies

```bash
pip install -r requirements.txt
```

Optional packages for some exploratory plots can be installed with `pip install -r requirements-optional.txt`.

## Limitations

All Python files have passed syntax compilation, and the updated scripts underwent static checks of plot calls and explicit colors. Complete reproduction on original data was not performed; surrogate-threshold aggregation, lag orientation, and upstream intermediate generation require verification before these sources can be described as a fully reproducible computational pipeline.
