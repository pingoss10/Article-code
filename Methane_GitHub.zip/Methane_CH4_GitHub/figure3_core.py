import numpy as np
from sklearn.neighbors import KernelDensity

def spatial_seed_mask(lon, lat, lon_bounds, lat_bounds):
    x = (np.asarray(lon) + 180) % 360 - 180
    west, east = lon_bounds
    mask_x = (x >= west) & (x <= east) if west <= east else (x >= west) | (x <= east)
    return mask_x & (np.asarray(lat) >= lat_bounds[0]) & (np.asarray(lat) <= lat_bounds[1])

def regional_outgoing_incoming(links, tau, distance, seed_mask, distance_break=4260):
    n = len(links)
    selected = np.flatnonzero(seed_mask)
    if not len(selected):
        raise ValueError('Seed region is empty')
    close = np.min(distance[selected], axis=0) <= distance_break
    out = np.zeros(n, dtype=int)
    incoming = np.zeros(n, dtype=int)
    lags_out, lags_in = ([], [])
    for i in selected:
        for j in range(n):
            if i == j:
                continue
            if links[i, j] and tau[i, j] > 0 or (links[j, i] and tau[j, i] < 0):
                out[j] += 1
                lags_out.append((j, abs(tau[i, j]) if links[i, j] and tau[i, j] > 0 else abs(tau[j, i])))
            if links[i, j] and tau[i, j] < 0 or (links[j, i] and tau[j, i] > 0):
                incoming[j] += 1
                lags_in.append((j, abs(tau[i, j]) if links[i, j] and tau[i, j] < 0 else abs(tau[j, i])))
    return {'out_near': out * close, 'out_far': out * ~close, 'in_near': incoming * close, 'in_far': incoming * ~close, 'out_lags': np.asarray(lags_out).reshape(-1, 2), 'in_lags': np.asarray(lags_in).reshape(-1, 2), 'near_mask': close}

def spherical_kde_significance(endpoints, lat, lon, realizations=100, alpha=0.001, seed=0):
    locations = np.deg2rad(np.column_stack([lat, lon]))
    endpoints = np.asarray(endpoints, dtype=int)
    if len(endpoints) == 0:
        n = len(lat)
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    bandwidth = max(0.5 * len(endpoints) ** (-1 / 6), 0.05)
    estimator = KernelDensity(kernel='gaussian', metric='haversine', algorithm='ball_tree', bandwidth=bandwidth)
    real = np.exp(estimator.fit(locations[endpoints]).score_samples(locations))
    generator = np.random.default_rng(seed)
    null = np.empty((realizations, len(lat)), dtype=np.float32)
    for k in range(realizations):
        sample = generator.integers(0, len(lat), size=len(endpoints))
        null[k] = np.exp(estimator.fit(locations[sample]).score_samples(locations))
    boundary = np.quantile(null, 1 - alpha, axis=0)
    return (real > boundary, real, boundary)
