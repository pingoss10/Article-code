import numpy as np

def _standardized_correlation(left, right):
    a = np.asarray(left, dtype=float)
    b = np.asarray(right, dtype=float)
    a = a - a.mean(axis=0, keepdims=True)
    b = b - b.mean(axis=0, keepdims=True)
    norm_a = np.sqrt(np.sum(a * a, axis=0))
    norm_b = np.sqrt(np.sum(b * b, axis=0))
    return np.divide(a.T @ b, norm_a[:, None] * norm_b[None, :], out=np.full((a.shape[1], b.shape[1]), np.nan), where=norm_a[:, None] * norm_b[None, :] > 0)

def lagged_link_weights(data, max_lag=200):
    data = np.asarray(data, dtype=float)
    if data.ndim != 2 or data.shape[0] <= 2 * max_lag:
        raise ValueError('Expected time-by-node data longer than twice the lag window')
    center = data[max_lag:len(data) - max_lag]
    shape = (data.shape[1], data.shape[1])
    csum = np.zeros(shape)
    csq = np.zeros(shape)
    cmax = np.full(shape, -np.inf)
    cmin = np.full(shape, np.inf)
    cabs = np.zeros(shape)
    tau_pos = np.zeros(shape, dtype=np.int16)
    tau_neg = np.zeros(shape, dtype=np.int16)
    tau_abs = np.zeros(shape, dtype=np.int16)
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            left, right = (center, data[max_lag + lag:len(data) - max_lag + lag])
        else:
            left, right = (data[max_lag - lag:len(data) - max_lag - lag], center)
        corr = _standardized_correlation(left, right)
        better_max = corr > cmax
        better_min = corr < cmin
        better_abs = np.abs(corr) > np.abs(cabs)
        tau_pos[better_max], tau_neg[better_min], tau_abs[better_abs] = (lag, lag, lag)
        cmax = np.maximum(cmax, corr)
        cmin = np.minimum(cmin, corr)
        cabs = np.where(better_abs, corr, cabs)
        csum += corr
        csq += corr * corr
    count = 2 * max_lag + 1
    mean = csum / count
    std = np.sqrt(np.maximum(csq / count - mean * mean, 0) * count / (count - 1))
    w_pos = np.divide(cmax - mean, std, out=np.full(shape, np.nan), where=std > 0)
    w_neg = np.divide(cmin - mean, std, out=np.full(shape, np.nan), where=std > 0)
    return {'w_pos': w_pos, 'w_neg': w_neg, 'tau_pos': tau_pos, 'tau_neg': tau_neg, 'c_max': cmax, 'c_min': cmin, 'c_abs_max': cabs, 'tau_abs_max': tau_abs}

def surrogate_weight_threshold(surrogate_weights, percentile=99.5):
    weights = np.asarray(surrogate_weights, dtype=float)
    if weights.ndim == 3:
        weights = weights.mean(axis=0)
    upper = np.triu_indices(weights.shape[0], k=1)
    return float(np.nanpercentile(weights[upper], percentile))

def significant_links(weights, threshold, lag=None):
    adjacency = np.asarray(weights) >= threshold
    np.fill_diagonal(adjacency, False)
    if lag is not None:
        adjacency &= np.asarray(lag) != 0
    return adjacency
