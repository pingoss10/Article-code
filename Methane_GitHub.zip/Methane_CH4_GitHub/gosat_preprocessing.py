import numpy as np
from scipy.signal import detrend

def read_daily_surface_ch4(netcdf_path):
    from netCDF4 import Dataset
    with Dataset(netcdf_path) as ds:
        values = np.ma.filled(ds.variables['conc'][:], np.nan)
        lat = np.asarray(ds.variables['lat'][:], dtype=float)
        lon = np.asarray(ds.variables['lon'][:], dtype=float)
    surface = np.asarray(values[:, 0], dtype=float)
    if surface.shape[0] % 4:
        raise ValueError('Time dimension must contain four records per day')
    daily = surface.reshape(-1, 4, len(lat), len(lon)).mean(axis=1) * 1000000000.0
    return (daily, lat, lon)

def select_spatial_nodes(lat, lon):
    indices, out_lat, out_lon = ([], [], [])
    for i in range(0, len(lat), 2):
        cosine = np.cos(np.deg2rad(lat[i]))
        step = max(1, round(1 / cosine)) if cosine > 0 else 1
        for j in range(0, len(lon), step):
            indices.append(i * len(lon) + j)
            out_lat.append(lat[i])
            out_lon.append(lon[j])
    return (np.asarray(indices, dtype=int), np.asarray(out_lat), np.asarray(out_lon))

def standardized_daily_anomalies(data, dates):
    dates = np.asarray(dates, dtype='datetime64[D]')
    if data.shape[0] != len(dates):
        raise ValueError('Date count does not match time dimension')
    months = dates.astype('datetime64[M]').astype('datetime64[D]')
    years = dates.astype('datetime64[Y]').astype('datetime64[D]')
    doy = (dates - years).astype(int) + 1
    leap = ((dates.astype('datetime64[Y]').astype(int) + 1970) % 4 == 0) & (((dates.astype('datetime64[Y]').astype(int) + 1970) % 100 != 0) | ((dates.astype('datetime64[Y]').astype(int) + 1970) % 400 == 0))
    month_index = dates.astype('datetime64[M]').astype(int) % 12 + 1
    doy = doy - (leap & (month_index > 2))
    keep = ~((month_index == 2) & ((dates - months).astype(int) + 1 == 29))
    result = np.full(np.shape(data), np.nan, dtype=float)
    for day in range(1, 366):
        idx = np.flatnonzero((doy == day) & keep)
        if not len(idx):
            continue
        subset = np.asarray(data[idx], dtype=float)
        mean = np.nanmean(subset, axis=0)
        std = np.nanstd(subset, axis=0, ddof=1)
        std = np.where(np.isfinite(std) & (std >= 0.001), std, 1.0)
        result[idx] = (subset - mean) / std
    return (result[keep], dates[keep])

def linear_detrend(data):
    array = np.asarray(data, dtype=float).copy()
    average = np.nanmean(array, axis=0)
    array = np.where(np.isnan(array), average, array)
    return detrend(array, axis=0, type='linear')
