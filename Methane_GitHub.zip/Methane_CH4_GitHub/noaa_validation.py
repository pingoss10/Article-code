import numpy as np
from scipy.signal import detrend
from scipy.stats import pearsonr

def great_circle_km(lat1, lon1, lat2, lon2):
    a1, o1, a2, o2 = map(np.deg2rad, [lat1, lon1, lat2, lon2])
    h = np.sin((a2 - a1) / 2) ** 2 + np.cos(a1) * np.cos(a2) * np.sin((o2 - o1) / 2) ** 2
    return 12742.0 * np.arcsin(np.sqrt(np.clip(h, 0, 1)))

def closest_grid_nodes(site_lat, site_lon, grid_lat, grid_lon):
    distance = great_circle_km(np.asarray(site_lat)[:, None], np.asarray(site_lon)[:, None], np.asarray(grid_lat)[None, :], np.asarray(grid_lon)[None, :])
    indices = distance.argmin(axis=1)
    return (indices, distance[np.arange(len(indices)), indices])

def fill_missing(data):
    import pandas as pd
    return pd.DataFrame(data).interpolate(method='linear', axis=0, limit_direction='both').fillna(pd.DataFrame(data).mean()).to_numpy(dtype=float)

def monthly_means(daily, dates):
    import pandas as pd
    labels = pd.PeriodIndex(pd.to_datetime(dates), freq='M')
    return pd.DataFrame(daily).groupby(labels).mean().to_numpy()

def detrended_station_correlations(surface_monthly, satellite_monthly):
    a = detrend(fill_missing(surface_monthly), axis=0)
    b = detrend(fill_missing(satellite_monthly), axis=0)
    if a.shape != b.shape:
        raise ValueError('Both monthly observation matrices must have the same shape')
    return np.asarray([pearsonr(a[:, i], b[:, i])[0] for i in range(a.shape[1])])
