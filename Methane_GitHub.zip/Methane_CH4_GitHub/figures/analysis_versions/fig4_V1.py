import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import matplotlib.pyplot as plt
import networkx as nx
import cartopy.crs as ccrs
import numpy as np
from mpl_toolkits.basemap import Basemap
distance = np.load('data/pairwise_distances.npy')
W_pos1 = np.load('data/network/working/positive_link_weights.npy')
tau = np.load('data/network/working/positive_link_lags.npy')
lons_all = np.load('data/node_longitudes.npy')
lats_all = np.load('data/node_latitudes.npy')
mask = (lats_all >= -5) & (lats_all <= 90)
idx = np.where(mask)[0]
lons = lons_all[idx]
lats = lats_all[idx]
print(f'北半球节点数: {idx.size}')
distance_matrix = distance[np.ix_(idx, idx)]
the_w = W_pos1[np.ix_(idx, idx)]
the_tau = tau[np.ix_(idx, idx)] + 200
lattic = np.zeros((len(lons_all), 2))
lattic[:, 0] = lats_all
lattic[:, 1] = lons_all

def ConstructDG(include_0, distance_max, DG_nodes_type='1995', coor_file=None):
    print(DG_nodes_type)
    len_nodes = distance_matrix.shape[0]
    print(len_nodes)
    DG = nx.DiGraph()
    for i in range(0, len_nodes, 1):
        DG.add_node(i)
    if include_0:
        for i in range(0, len_nodes, 1):
            for j in range(0, len_nodes, 1):
                if i == j:
                    continue
                elif (the_tau[i][j] < 201) & (distance_matrix[i][j] < distance_max):
                    DG.add_weighted_edges_from([(i, j, abs(1 / the_w[i][j]))])
    else:
        for i in range(0, len_nodes, 1):
            for j in range(0, len_nodes, 1):
                if i == j:
                    continue
                elif (0 < the_tau[i][j] < 201) & (distance_matrix[i][j] < distance_max):
                    DG.add_weighted_edges_from([(i, j, abs(1 / the_w[i][j]))])
    return DG
dg = ConstructDG(True, 1000)

def Get_Draw_Path00(begining_point, ending_point, the_G, index, the_color, ax, lines, labels, whether_guss, whether_print_Path_days=True):
    path_in = nx.dijkstra_path(the_G, begining_point, ending_point)
    kw = dict(linewidth=12)
    lines += ax.plot(lattic[path_in][:, 1], lattic[path_in][:, 0], color=the_color, transform=ccrs.Geodetic(), **kw)
nc_path = 'data/topography.nc'
step = 6
var_name = None
ds = xr.open_dataset(nc_path)
print('Dataset vars:', list(ds.data_vars))
print('Dataset coords:', list(ds.coords))
if var_name is None:
    prefer = ['elevation', 'z', 'topo', 'dem', 'band1', 'bed', 'ice', 'surface']
    picked = None
    for p in prefer:
        for v in ds.data_vars:
            if v.lower() == p or p in v.lower():
                picked = v
                break
        if picked is not None:
            break
    if picked is None:
        for v in ds.data_vars:
            if ds[v].ndim >= 2:
                picked = v
                break
    if picked is None:
        picked = list(ds.data_vars)[0]
    var_name = picked
da = ds[var_name]
print('Using variable:', var_name)
print('Variable dims:', da.dims)
lat_name = None
lon_name = None
lat_cands = ['lat', 'latitude', 'y']
lon_cands = ['lon', 'longitude', 'x']
for c in da.coords:
    cl = c.lower()
    if cl in lat_cands:
        lat_name = c
    if cl in lon_cands:
        lon_name = c
if lat_name is None:
    for d in da.dims:
        if d.lower() in lat_cands:
            lat_name = d
            break
if lon_name is None:
    for d in da.dims:
        if d.lower() in lon_cands:
            lon_name = d
            break
if lat_name is None or lon_name is None:
    raise ValueError(f'无法自动识别经纬度坐标名。\ndims={da.dims}\ncoords={list(da.coords)}\n请把 print(ds) 输出贴出来，我帮你明确 lat/lon 名称。')
if lat_name != 'lat' or lon_name != 'lon':
    da = da.rename({lat_name: 'lat', lon_name: 'lon'})
lon_max = float(da['lon'].max())
if lon_max > 180:
    lon_new = (da['lon'] + 180) % 360 - 180
    da = da.assign_coords(lon=lon_new).sortby('lon')
da_nh = da.sel(lat=slice(-90, 90))
if step and step > 1:
    da_nh = da_nh.isel(lat=slice(None, None, step), lon=slice(None, None, step))
da_nh = da_nh.where(np.isfinite(da_nh))
lon11 = da_nh['lon'].values
lat11 = da_nh['lat'].values
data = da_nh.values
fig = plt.figure(figsize=(13, 6.8), dpi=220)
ax = plt.axes(projection=ccrs.Robinson())
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.set_extent([-180, 180, -90, 90], crs=ccrs.PlateCarree())
vmin, vmax = (-7000, 6000)
data_clip = np.clip(data, vmin, vmax)
mesh = ax.pcolormesh(lon11, lat11, data_clip, transform=ccrs.PlateCarree(), cmap='terrain', shading='auto', vmin=vmin, vmax=vmax, rasterized=True)
ax.coastlines(resolution='110m', linewidth=0.7, alpha=0.9)
ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=False, linewidth=0.4, color='k', alpha=0.18, linestyle='--')
cbar = plt.colorbar(mesh, ax=ax, orientation='horizontal', shrink=0.88, pad=0.06, aspect=35)
cbar.set_label('Elevation (m)', fontsize=11)
ax.set_title(f'Topography (ETOPO 2022)', fontsize=13, pad=10)
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
traj_data = np.load('data/trajectories/trajectory_route_a.npz')
traj_lon = traj_data['traj_lon']
traj_lat = traj_data['traj_lat']
vmin, vmax = (-7, 6)
data_clip = np.clip(data / 1000.0, vmin, vmax)
data_cyc, lon_cyc = add_cyclic_point(data_clip, coord=lon)
lon2d, lat2d = np.meshgrid(lon_cyc, lat)
plt.rcParams['font.family'] = 'sans-serif'
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=110, central_latitude=40))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap='terrain', shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=1, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='horizontal', shrink=0.6, pad=0.06, aspect=32)
cbar.set_label('Elevation (km)', fontsize=18)
cbar.ax.tick_params(labelsize=16)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=4, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=0.9), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 1.5, foreground='white', alpha=0.8), pe.Normal()])
ax.plot(lon_path, lat_path, transform=ccrs.Geodetic(), linewidth=24, color='#EA8379', alpha=0.5, solid_capstyle='round', zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=35, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=0.8), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=4, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=3, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.02, -0.09), fontsize=18, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'b', transform=ax.transAxes, ha='left', va='top', fontsize=40, fontweight='bold', color='black', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.show()
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.util import add_cyclic_point
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
print(ds_u)
print(ds_v)
u = ds_u['uwnd']
v = ds_v['vwnd']
u_250 = u.sel(level=500, time=slice('2010-01-01', '2020-12-31'))
v_250 = v.sel(level=500, time=slice('2010-01-01', '2020-12-31'))
u_mean = u_250.mean(dim='time')
v_mean = v_250.mean(dim='time')
ws_mean = np.sqrt(u_mean ** 2 + v_mean ** 2)
lat = ds_u['lat']
lon = ds_u['lon']
if lon.max() > 180:
    u_mean = u_mean.assign_coords(lon=(u_mean.lon + 180) % 360 - 180).sortby('lon')
    v_mean = v_mean.assign_coords(lon=(v_mean.lon + 180) % 360 - 180).sortby('lon')
    ws_mean = ws_mean.assign_coords(lon=(ws_mean.lon + 180) % 360 - 180).sortby('lon')
    lon = u_mean['lon']
lat = u_mean['lat']
ws_cyc, lon_cyc = add_cyclic_point(ws_mean.values, coord=lon.values)
u_cyc, _ = add_cyclic_point(u_mean.values, coord=lon.values)
v_cyc, _ = add_cyclic_point(v_mean.values, coord=lon.values)
lon2d, lat2d = np.meshgrid(lon_cyc, lat.values)
fig = plt.figure(figsize=(14, 7), dpi=200)
ax = plt.axes(projection=ccrs.Robinson(central_longitude=0))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
levels = np.arange(0, 55, 2)
cf = ax.contourf(lon_cyc, lat.values, ws_cyc, levels=levels, cmap='YlGnBu', extend='max', transform=ccrs.PlateCarree())
ax.coastlines(resolution='110m', linewidth=0.8, color='black')
ax.add_feature(cfeature.BORDERS, linewidth=0.3, edgecolor='gray')
ax.gridlines(draw_labels=False, linewidth=0.4, color='gray', alpha=0.3, linestyle='--')
skip = 4
q = ax.quiver(lon2d[::skip, ::skip], lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=700, width=0.0022, headwidth=3.8, headlength=5, headaxislength=4.5)
ax.quiverkey(q, X=0.88, Y=-0.08, U=20, label='20 m s$^{-1}$', labelpos='E', coordinates='axes', fontproperties={'size': 12})
cbar = plt.colorbar(cf, ax=ax, orientation='horizontal', pad=0.05, shrink=0.8, aspect=35)
cbar.set_label('250 hPa Wind Speed (m s$^{-1}$)', fontsize=14)
cbar.ax.tick_params(labelsize=12)
plt.title('Mean 250 hPa Wind Field (2010–2020)', fontsize=18)
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
import xarray as xr
traj_data = np.load('data/trajectories/trajectory_route_a.npz')
traj_lon = traj_data['traj_lon']
traj_lat = traj_data['traj_lat']
vmin, vmax = (-7, 6)
data_clip = np.clip(data / 1000.0, vmin, vmax)
terrain_lat = np.linspace(-90, 90, data.shape[0])
terrain_lon = np.linspace(-180, 180, data.shape[1], endpoint=False)
data_cyc, lon_cyc = add_cyclic_point(data_clip, coord=terrain_lon)
lon2d, lat2d = np.meshgrid(lon_cyc, terrain_lat)
plt.rcParams['font.family'] = 'sans-serif'
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=110, central_latitude=40))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap='terrain', shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=1, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='horizontal', shrink=0.6, pad=0.06, aspect=32)
cbar.set_label('Elevation (km)', fontsize=18)
cbar.ax.tick_params(labelsize=16)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=250, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=250, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 4
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=700, width=0.004, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
ax.quiverkey(q, X=0.74, Y=0.3, U=25, label='20 m s$^{-1}$', labelpos='E', coordinates='axes', fontproperties={'size': 18})
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=4, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=0.9), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 1.5, foreground='white', alpha=0.8), pe.Normal()])
ax.plot(lon_path, lat_path, transform=ccrs.Geodetic(), linewidth=24, color='#EA8379', alpha=0.5, solid_capstyle='round', zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=35, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=0.8), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=4, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=3, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.02, -0.09), fontsize=18, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'b', transform=ax.transAxes, ha='left', va='top', fontsize=40, fontweight='bold', color='black', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
import xarray as xr
import matplotlib.colors as mcolors
import numpy as np
import xarray as xr
import matplotlib.colors as mcolors
import matplotlib.colors as mcolors
import matplotlib.colors as mcolors
begining_point, ending_point = (1342, 1663)
lines_lgd, labels_lgd = ([], [])
path_in = nx.dijkstra_path(dg, begining_point, ending_point)

def create_super_smooth_stepped_cmap():
    colors = [(0.0, '#123f8a'), (0.2, '#1d91c0'), (0.3, '#36a7ba'), (0.4, '#41b6c4'), (0.45, '#7fcdbb'), (0.48, '#a1dab4'), (0.49, '#c1e7c1'), (0.5, '#addd8e'), (0.51, '#92d17d'), (0.52, '#78c679'), (0.53, '#5cb56b'), (0.54, '#41ab5d'), (0.55, '#4ea95a'), (0.56, '#63b457'), (0.57, '#79be57'), (0.58, '#8fc758'), (0.59, '#a4ce5b'), (0.6, '#b7d35f'), (0.61, '#c9d865'), (0.62, '#d8db6c'), (0.63, '#e5dd72'), (0.64, '#efde75'), (0.65, '#f8de77'), (0.7, '#fed976'), (0.75, '#feb24c'), (0.8, '#fd8d3c'), (0.85, '#f03b20'), (0.9, '#bd0026'), (0.95, '#800026'), (1.0, '#ffffff')]
    return mcolors.LinearSegmentedColormap.from_list('stepped_smooth', colors, N=2048)
custom_cmap = create_super_smooth_stepped_cmap()
traj_data = np.load('data/trajectories/trajectory_route_a.npz')
traj_lon = traj_data['traj_lon']
traj_lat = traj_data['traj_lat']
vmin, vmax = (-6, 6.5)
data_clip = np.clip(data / 1000.0, vmin, vmax)
terrain_lat = np.linspace(-90, 90, data.shape[0])
terrain_lon = np.linspace(-180, 180, data.shape[1], endpoint=False)
data_cyc, lon_cyc = add_cyclic_point(data_clip, coord=terrain_lon)
lon2d, lat2d = np.meshgrid(lon_cyc, terrain_lat)
plt.rcParams['font.family'] = 'sans-serif'
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=110, central_latitude=40))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap=custom_cmap, shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=1, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='vertical', shrink=0.6, pad=0.05, aspect=23)
cbar.set_label('Elevation (km)', fontsize=30)
cbar.ax.tick_params(labelsize=30)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 3
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=100, width=0.004, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
qk = ax.quiverkey(q, X=0.71, Y=0.16, U=10, label='10 m s$^{-1}$', labelpos='E', coordinates='figure', fontproperties={'size': 30}, color='black', labelsep=0.08)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=4, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=1), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 2, foreground='white', alpha=1), pe.Normal()])
ax.plot(lon_path, lat_path, transform=ccrs.Geodetic(), linewidth=24, color='#EA8379', alpha=0.5, solid_capstyle='round', zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=35, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=1), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=4, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=4, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.07, -0.12), ncol=2, fontsize=29, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'a', transform=ax.transAxes, ha='left', va='top', fontsize=44, fontweight='bold', color='black', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.savefig('outputs/figures/figure_023.jpg', dpi=300, bbox_inches='tight')
plt.show()
from shapely.geometry import LineString
from shapely.ops import transform
from pyproj import CRS, Transformer
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=110, central_latitude=40))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap=custom_cmap, shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=1, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='vertical', shrink=0.6, pad=0.05, aspect=23)
cbar.set_label('Elevation (km)', fontsize=30 + 10)
cbar.ax.tick_params(labelsize=30 + 10)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 3
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=100, width=0.004, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
qk = ax.quiverkey(q, X=0.71, Y=0.16, U=10, label='10 m s$^{-1}$', labelpos='E', coordinates='figure', fontproperties={'size': 30 + 5}, color='black', labelsep=0.08)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=4, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=1), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 2, foreground='white', alpha=1), pe.Normal()])
lon_path_buffer = np.array(lon_path, dtype=float)
lat_path_buffer = np.array(lat_path, dtype=float)
lon_path_buffer = (lon_path_buffer + 180) % 360 - 180
lon_path_buffer = np.rad2deg(np.unwrap(np.deg2rad(lon_path_buffer)))
lon0 = np.nanmean(lon_path_buffer)
lat0 = np.nanmean(lat_path_buffer)
geo_crs = CRS.from_epsg(4326)
aeqd_crs = CRS.from_proj4(f'+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs')
to_m = Transformer.from_crs(geo_crs, aeqd_crs, always_xy=True).transform
to_lonlat = Transformer.from_crs(aeqd_crs, geo_crs, always_xy=True).transform
line_geo = LineString(list(zip(lon_path_buffer, lat_path_buffer)))
line_m = transform(to_m, line_geo)
corridor_geo = transform(to_lonlat, line_m.buffer(580 * 1000))
ax.add_geometries([corridor_geo], crs=ccrs.PlateCarree(), facecolor='#EA8379', edgecolor='none', alpha=0.5, zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=45, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=1), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=4, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=4, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.07, -0.12), ncol=2, fontsize=29, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'a', transform=ax.transAxes, ha='left', va='top', fontsize=52 + 17, fontweight='bold', fontfamily='Arial')
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.savefig('outputs/figures/figure_024.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
import xarray as xr
begining_point, ending_point = (1259, 1195)
lines_lgd, labels_lgd = ([], [])
path_in = nx.dijkstra_path(dg, begining_point, ending_point)

def create_super_smooth_stepped_cmap():
    colors = [(0.0, '#123f8a'), (0.2, '#1d91c0'), (0.3, '#36a7ba'), (0.4, '#41b6c4'), (0.45, '#7fcdbb'), (0.48, '#a1dab4'), (0.49, '#c1e7c1'), (0.5, '#addd8e'), (0.51, '#92d17d'), (0.52, '#78c679'), (0.53, '#5cb56b'), (0.54, '#41ab5d'), (0.55, '#4ea95a'), (0.56, '#63b457'), (0.57, '#79be57'), (0.58, '#8fc758'), (0.59, '#a4ce5b'), (0.6, '#b7d35f'), (0.61, '#c9d865'), (0.62, '#d8db6c'), (0.63, '#e5dd72'), (0.64, '#efde75'), (0.65, '#f8de77'), (0.7, '#fed976'), (0.75, '#feb24c'), (0.8, '#fd8d3c'), (0.85, '#f03b20'), (0.9, '#bd0026'), (0.95, '#800026'), (1.0, '#ffffff')]
    return mcolors.LinearSegmentedColormap.from_list('stepped_smooth', colors, N=2048)
custom_cmap = create_super_smooth_stepped_cmap()
traj_data = np.load('data/trajectories/trajectory_route_b.npz')
traj_lon = traj_data['traj_lon']
traj_lat = traj_data['traj_lat']
vmin, vmax = (-6, 6)
data_clip = np.clip(data / 1000.0, vmin, vmax)
terrain_lat = np.linspace(-90, 90, data.shape[0])
terrain_lon = np.linspace(-180, 180, data.shape[1], endpoint=False)
data_cyc, lon_cyc = add_cyclic_point(data_clip, coord=terrain_lon)
lon2d, lat2d = np.meshgrid(lon_cyc, terrain_lat)
plt.rcParams['font.family'] = 'sans-serif'
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=190, central_latitude=55))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap=custom_cmap, shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=1, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='vertical', shrink=0.6, pad=0.05, aspect=23)
cbar.set_label('Elevation (km)', fontsize=30)
cbar.ax.tick_params(labelsize=30)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 4
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=100, width=0.004, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
qk = ax.quiverkey(q, X=0.71, Y=0.16, U=10, label='10 m s$^{-1}$', labelpos='E', coordinates='figure', fontproperties={'size': 30}, color='black', labelsep=0.08)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=7, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=1), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 2, foreground='white', alpha=1), pe.Normal()])
ax.plot(lon_path, lat_path, transform=ccrs.Geodetic(), linewidth=24, color='#EA8379', alpha=0.5, solid_capstyle='round', zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=35, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=1), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=6, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=4, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.07, -0.12), ncol=2, fontsize=29, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'b', transform=ax.transAxes, ha='left', va='top', fontsize=50, fontweight='bold', color='black', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.savefig('outputs/figures/figure_025.jpg', dpi=300, bbox_inches='tight')
plt.show()
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=190, central_latitude=55))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap=custom_cmap, shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=1, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='vertical', shrink=0.6, pad=0.05, aspect=23)
cbar.set_label('Elevation (km)', fontsize=30 + 10)
cbar.ax.tick_params(labelsize=30 + 10)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 4
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=100, width=0.004, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
qk = ax.quiverkey(q, X=0.71, Y=0.16, U=10, label='10 m s$^{-1}$', labelpos='E', coordinates='figure', fontproperties={'size': 30 + 5}, color='black', labelsep=0.08)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
center_lon = 190

def wrap_lon_to_center(lon, center=center_lon):
    lon = np.asarray(lon, dtype=float)
    return center + ((lon - center + 180) % 360 - 180)
lon_path = wrap_lon_to_center(np.flip(lon_path_orig))
lat_path = np.flip(lat_path_orig)
traj_lon = wrap_lon_to_center(traj_lon)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=7, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=1), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 2, foreground='white', alpha=1), pe.Normal()])
lon_path_buffer = np.array(lon_path, dtype=float)
lat_path_buffer = np.array(lat_path, dtype=float)
lon_path_buffer = (lon_path_buffer + 180) % 360 - 180
lon_path_buffer = np.rad2deg(np.unwrap(np.deg2rad(lon_path_buffer)))
lon0 = np.nanmean(lon_path_buffer)
lat0 = np.nanmean(lat_path_buffer)
geo_crs = CRS.from_epsg(4326)
aeqd_crs = CRS.from_proj4(f'+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs')
to_m = Transformer.from_crs(geo_crs, aeqd_crs, always_xy=True).transform
to_lonlat = Transformer.from_crs(aeqd_crs, geo_crs, always_xy=True).transform
line_geo = LineString(list(zip(lon_path_buffer, lat_path_buffer)))
line_m = transform(to_m, line_geo)
corridor_geo = transform(to_lonlat, line_m.buffer(600 * 1000))
lon_path_buffer = np.array(lon_path, dtype=float)
lat_path_buffer = np.array(lat_path, dtype=float)
lon0 = np.nanmean(lon_path_buffer)
lat0 = np.nanmean(lat_path_buffer)
geo_crs = CRS.from_epsg(4326)
aeqd_crs = CRS.from_proj4(f'+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs')
to_m = Transformer.from_crs(geo_crs, aeqd_crs, always_xy=True).transform
to_lonlat = Transformer.from_crs(aeqd_crs, geo_crs, always_xy=True).transform
line_geo = LineString(list(zip(lon_path_buffer, lat_path_buffer)))
line_m = transform(to_m, line_geo)
corridor_geo = transform(to_lonlat, line_m.buffer(580 * 1000))

def recenter_geometry_lon(x, y, z=None):
    x = np.asarray(x, dtype=float)
    x = center_lon + ((x - center_lon + 180) % 360 - 180)
    if z is None:
        return (x, y)
    return (x, y, z)
corridor_geo = transform(recenter_geometry_lon, corridor_geo)
ax.add_geometries([corridor_geo], crs=ccrs.PlateCarree(), facecolor='#EA8379', edgecolor='none', alpha=0.5, zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=45, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=1), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=6, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=4, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.07, -0.12), ncol=2, fontsize=29, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'b', transform=ax.transAxes, ha='left', va='top', fontsize=52 + 17, fontweight='bold', fontfamily='Arial', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.savefig('outputs/figures/figure_026.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches
import xarray as xr
import matplotlib.colors as mcolors
import matplotlib.colors as mcolors
import matplotlib.colors as mcolors
import matplotlib as mpl
begining_point, ending_point = (1740, 1406)
lines_lgd, labels_lgd = ([], [])
path_in = nx.dijkstra_path(dg, begining_point, ending_point)

def create_super_smooth_stepped_cmap():
    colors = [(0.0, '#123f8a'), (0.2, '#1d91c0'), (0.3, '#36a7ba'), (0.4, '#41b6c4'), (0.45, '#7fcdbb'), (0.48, '#a1dab4'), (0.49, '#c1e7c1'), (0.5, '#addd8e'), (0.51, '#92d17d'), (0.52, '#78c679'), (0.53, '#5cb56b'), (0.54, '#41ab5d'), (0.55, '#4ea95a'), (0.56, '#63b457'), (0.57, '#79be57'), (0.58, '#8fc758'), (0.59, '#a4ce5b'), (0.6, '#b7d35f'), (0.61, '#c9d865'), (0.62, '#d8db6c'), (0.63, '#e5dd72'), (0.64, '#efde75'), (0.65, '#f8de77'), (0.7, '#fed976'), (0.75, '#feb24c'), (0.8, '#fd8d3c'), (0.85, '#f03b20'), (0.9, '#bd0026'), (0.95, '#800026'), (1.0, '#ffffff')]
    return mcolors.LinearSegmentedColormap.from_list('stepped_smooth', colors, N=2048)
custom_cmap = create_super_smooth_stepped_cmap()
traj_data = np.load('data/trajectories/trajectory_route_c.npz')
traj_lon = traj_data['traj_lon']
traj_lat = traj_data['traj_lat']
vmin, vmax = (-6, 6.5)
data_clip = np.clip(data / 1000.0, vmin, vmax)
terrain_lat = np.linspace(-90, 90, data.shape[0])
terrain_lon = np.linspace(-180, 180, data.shape[1], endpoint=False)
data_cyc, lon_cyc = add_cyclic_point(data_clip, coord=terrain_lon)
lon2d, lat2d = np.meshgrid(lon_cyc, terrain_lat)
plt.rcParams['font.family'] = 'sans-serif'
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=1, central_latitude=45))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
terrain_soft = mpl.colors.LinearSegmentedColormap.from_list('terrain_soft', mpl.cm.terrain(np.linspace(0.05, 1.0, 256)))
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap=custom_cmap, shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=0.9, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='vertical', shrink=0.6, pad=0.05, aspect=23)
cbar.set_label('Elevation (km)', fontsize=30)
cbar.ax.tick_params(labelsize=30)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 4
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=100, width=0.005, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
qk = ax.quiverkey(q, X=0.71, Y=0.16, U=10, label='10 m s$^{-1}$', labelpos='E', coordinates='figure', fontproperties={'size': 30}, color='black', labelsep=0.08)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=7, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=1), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 1.5, foreground='white', alpha=1), pe.Normal()])
ax.plot(lon_path, lat_path, transform=ccrs.Geodetic(), linewidth=24, color='#EA8379', alpha=0.5, solid_capstyle='round', zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=35, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=0.8), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=6, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=3, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.07, -0.12), ncol=2, fontsize=29, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'c', transform=ax.transAxes, ha='left', va='top', fontsize=44, fontweight='bold', color='black', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.savefig('outputs/figures/figure_027.jpg', dpi=300, bbox_inches='tight')
plt.show()
from pyproj import CRS, Transformer
from shapely.geometry import LineString
from shapely.ops import transform
plt.rcParams['font.family'] = 'sans-serif'
fig = plt.figure(figsize=(12, 10), dpi=220, facecolor='white')
ax = plt.axes(projection=ccrs.Orthographic(central_longitude=1, central_latitude=45))
ax.set_global()
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
terrain_soft = mpl.colors.LinearSegmentedColormap.from_list('terrain_soft', mpl.cm.terrain(np.linspace(0.05, 1.0, 256)))
mesh = ax.pcolormesh(lon2d, lat2d, data_cyc, transform=ccrs.PlateCarree(), cmap=custom_cmap, shading='auto', vmin=vmin, vmax=vmax, rasterized=True, alpha=0.9, zorder=1)
ax.coastlines(resolution='50m', linewidth=0.8, color='black', zorder=5)
ax.gridlines(draw_labels=False, linewidth=0.3, color='gray', alpha=0.1, linestyle='--', zorder=2)
cbar = plt.colorbar(mesh, ax=ax, orientation='vertical', shrink=0.6, pad=0.05, aspect=23)
cbar.set_label('Elevation (km)', fontsize=30 + 10)
cbar.ax.tick_params(labelsize=30 + 10)
u_file = 'data/meteorology/zonal_wind_monthly.nc'
v_file = 'data/meteorology/meridional_wind_monthly.nc'
ds_u = xr.open_dataset(u_file)
ds_v = xr.open_dataset(v_file)
u = ds_u['uwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
v = ds_v['vwnd'].sel(level=850, time=slice('2010-01-01', '2020-12-31'))
u_mean = u.mean(dim='time')
v_mean = v.mean(dim='time')
wind_lat = u_mean['lat'].values
wind_lon = u_mean['lon'].values
u_plot = u_mean.values
v_plot = v_mean.values
if np.max(wind_lon) > 180:
    wind_lon_new = (wind_lon + 180) % 360 - 180
    sort_idx = np.argsort(wind_lon_new)
    wind_lon = wind_lon_new[sort_idx]
    u_plot = u_plot[:, sort_idx]
    v_plot = v_plot[:, sort_idx]
u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
skip = 4
q = ax.quiver(wind_lon2d[::skip, ::skip], wind_lat2d[::skip, ::skip], u_cyc[::skip, ::skip], v_cyc[::skip, ::skip], transform=ccrs.PlateCarree(), color='white', scale=100, width=0.005, headwidth=6, headlength=4.5, headaxislength=4.0, alpha=1, zorder=6)
qk = ax.quiverkey(q, X=0.71, Y=0.16, U=10, label='10 m s$^{-1}$', labelpos='E', coordinates='figure', fontproperties={'size': 30 + 5}, color='black', labelsep=0.08)
lon_path_orig = np.array([lons[k] for k in path_in], dtype=float)
lat_path_orig = np.array([lats[k] for k in path_in], dtype=float)
if np.max(lon_cyc) > 180:
    lon_path_orig = np.where(lon_path_orig < 0, lon_path_orig + 360, lon_path_orig)
    traj_lon = np.where(traj_lon < 0, traj_lon + 360, traj_lon)
lon_path = np.flip(lon_path_orig)
lat_path = np.flip(lat_path_orig)

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=7, color='#00e5ff', lw=2.5, ms=15, zo=16):

    def calc_haversine(l1, la1, l2, la2):
        R = 6371.0
        l1, la1, l2, la2 = map(np.radians, [l1, la1, l2, la2])
        a = np.sin((la2 - la1) / 2.0) ** 2 + np.cos(la1) * np.cos(la2) * np.sin((l2 - l1) / 2.0) ** 2
        return R * (2 * np.arcsin(np.sqrt(a)))
    seg_dist = [calc_haversine(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        if np.max(lon_cyc) > 180:
            x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=1), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=lw + 1.5, foreground='white', alpha=1), pe.Normal()])
center_lon = 1

def wrap_lon_to_center(lon, center=center_lon):
    lon = np.asarray(lon, dtype=float)
    return center + ((lon - center + 180) % 360 - 180)
lon_path_buffer = wrap_lon_to_center(lon_path)
lat_path_buffer = np.array(lat_path, dtype=float)
lon0 = np.nanmean(lon_path_buffer)
lat0 = np.nanmean(lat_path_buffer)
geo_crs = CRS.from_epsg(4326)
aeqd_crs = CRS.from_proj4(f'+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs')
to_m = Transformer.from_crs(geo_crs, aeqd_crs, always_xy=True).transform
to_lonlat = Transformer.from_crs(aeqd_crs, geo_crs, always_xy=True).transform
line_geo = LineString(list(zip(lon_path_buffer, lat_path_buffer)))
line_m = transform(to_m, line_geo)
corridor_geo = transform(to_lonlat, line_m.buffer(580 * 1000))

def recenter_geometry_lon(x, y, z=None):
    x = np.asarray(x, dtype=float)
    x = center_lon + ((x - center_lon + 180) % 360 - 180)
    if z is None:
        return (x, y)
    return (x, y, z)
corridor_geo = transform(recenter_geometry_lon, corridor_geo)
ax.add_geometries([corridor_geo], crs=ccrs.PlateCarree(), facecolor='#EA8379', edgecolor='none', alpha=0.5, zorder=10, label='Network Corridor')
pc = ccrs.PlateCarree()
xytr = pc._as_mpl_transform(ax)
for i in range(len(lon_path) - 1):
    x0, y0 = (lon_path[i], lat_path[i])
    x1, y1 = (lon_path[i + 1], lat_path[i + 1])
    if np.max(lon_cyc) > 180:
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
    ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color='#C9352B', lw=4.0, mutation_scale=45, shrinkA=15, shrinkB=15, alpha=0.8), zorder=12)
    ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=7, foreground='white', alpha=0.8), pe.Normal()])
traj_line, = ax.plot(traj_lon, traj_lat, transform=ccrs.Geodetic(), linewidth=3, color='#66529F', zorder=15, label='Physical Trajectory')
traj_line.set_path_effects([pe.Stroke(linewidth=8, foreground='white', alpha=0.7), pe.Normal()])
add_directional_arrows(ax, traj_lon, traj_lat, n_arrows=6, color='#66529F', lw=4, ms=28, zo=15)
start_sc = ax.scatter(lon_path[0], lat_path[0], s=250, marker='o', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=550, marker='*', color='#E0E0E0', edgecolors='black', linewidth=1.5, transform=ccrs.PlateCarree(), zorder=26)
for sc in [start_sc, end_sc]:
    sc.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
legend_elements = [Line2D([0], [0], color='#66529F', lw=3, label='Particle Trajectory'), mpatches.Patch(color='#C9352B', alpha=0.4, label='Network Pathway')]
leg = ax.legend(handles=legend_elements, loc='lower left', bbox_to_anchor=(-0.07, -0.12), ncol=2, fontsize=29, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
leg.get_frame().set_linewidth(1.0)
txt = ax.text(0.02, 0.98, 'c', transform=ax.transAxes, ha='left', va='top', fontsize=52 + 17, fontweight='bold', fontfamily='Arial', zorder=30)
txt.set_path_effects([pe.Stroke(linewidth=4, foreground='white'), pe.Normal()])
plt.tight_layout()
plt.savefig('outputs/figures/figure_028.jpg', dpi=300, bbox_inches='tight')
plt.show()
