import numpy as np
import matplotlib.pyplot as plt
dispath = 'data/'
path = 'data/network/observed/'
path1 = 'data/network/surrogates/'
distance = np.load(dispath + 'pairwise_distances.npy')
W_pos1 = np.load(path + 'positive_link_weights.npy')
W_neg1 = np.load(path + 'negative_link_weights.npy')
shuffle_W_pos1_all = np.load(path1 + 'surrogate_positive_weights.npy')
shuffle_W_neg1_all = np.load(path1 + 'surrogate_negative_weights.npy')
lat = np.load('data/node_latitudes.npy')
mask = (lat >= -5) & (lat <= 90)
idx = np.where(mask)[0]
n_sub = idx.size
print(f'北半球子集节点数: {n_sub}')
distance_sub = distance[np.ix_(idx, idx)]
W_pos_sub = W_pos1[np.ix_(idx, idx)]
W_neg_sub = W_neg1[np.ix_(idx, idx)]
shuffle_W_pos_mean = shuffle_W_pos1_all.mean(axis=0)[np.ix_(idx, idx)]
shuffle_W_neg_mean = shuffle_W_neg1_all.mean(axis=0)[np.ix_(idx, idx)]
tri_upper = np.triu_indices(n_sub, k=1)
dist_flat = distance_sub[tri_upper]
W_pos_flat = W_pos_sub[tri_upper]
W_neg_flat = W_neg_sub[tri_upper]
shuffle_W_pos_flat = shuffle_W_pos_mean[tri_upper]
shuffle_W_neg_flat = shuffle_W_neg_mean[tri_upper]

def clean_pair(x, y):
    m = np.isfinite(x) & np.isfinite(y)
    return (x[m], y[m])
dist_flat_pos, W_pos_flat = clean_pair(dist_flat, W_pos_flat)
_, shuffle_W_pos_flat = clean_pair(dist_flat, shuffle_W_pos_flat)
dist_flat_neg, W_neg_flat = clean_pair(dist_flat, W_neg_flat)
_, shuffle_W_neg_flat = clean_pair(dist_flat, shuffle_W_neg_flat)
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Helvetica', 'Arial', 'DejaVu Sans'], 'font.size': 11, 'axes.titlesize': 13, 'axes.labelsize': 12, 'xtick.labelsize': 10, 'ytick.labelsize': 10, 'legend.fontsize': 10, 'legend.frameon': True, 'legend.framealpha': 0.95, 'legend.edgecolor': 'gray', 'legend.facecolor': 'white', 'legend.borderpad': 0.6, 'axes.linewidth': 0.8, 'grid.linewidth': 0.5, 'axes.grid': True, 'grid.alpha': 0.3, 'grid.linestyle': '--'})
fig = plt.figure(figsize=(8, 8), dpi=300)
ax = plt.gca()
verts = np.array([[-0.5, -0.5], [0.5, 0.5]])
from matplotlib.path import Path
path = Path(verts, [Path.MOVETO, Path.LINETO])
ax.scatter(dist_flat_pos, W_pos_flat, c='#5b66a1', alpha=1, s=18, marker=path, label='Real data')
ax.scatter(dist_flat_pos, shuffle_W_pos_flat, c='#e6e6e6', alpha=1, s=20, marker=path, label='Shuffle data')
ax.set_xlabel('Distance (km)')
ax.set_ylabel('$   W_{\\rm pos}   $')
fig.text(0.025, 1.05, 'a', fontsize=45, fontweight='bold', ha='left', va='top', transform=fig.transFigure)
ax.legend(loc='upper right', borderpad=0.6, labelspacing=0.5, prop={'size': 18}, handletextpad=0.8, scatterpoints=1, markerscale=4)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_linewidth(0.8)
ax.spines['bottom'].set_linewidth(0.8)
ax.xaxis.label.set_size(25)
ax.yaxis.label.set_size(25)
ax.tick_params(axis='both', which='major', labelsize=25)
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
Detrended_methane = np.load('data/methane_anomalies.npy')
lat = np.load('data/node_latitudes.npy')
lon = np.load('data/node_longitudes.npy')
dispath = 'data/'
path = 'data/network/working/'
distance = np.load(dispath + 'pairwise_distances.npy')
W_pos1 = np.load(path + 'positive_link_weights.npy')
W_neg1 = np.load(path + 'negative_link_weights.npy')
shuffle_W_pos1_all = np.load(path1 + 'surrogate_positive_weights.npy')
shuffle_W_neg1_all = np.load(path1 + 'surrogate_negative_weights.npy')
lons_all = np.load('data/node_longitudes.npy')
lats_all = np.load('data/node_latitudes.npy')
lons_all = np.where(lons_all > 180, lons_all - 360, lons_all)
mask = (lats_all >= -5) & (lats_all <= 90)
idx = np.where(mask)[0]
lons = lons_all[idx]
lats = lats_all[idx]
print(f'北半球节点数: {idx.size}')
W_pos_sub = W_pos1[np.ix_(idx, idx)]
W_neg_sub = W_neg1[np.ix_(idx, idx)]
shuffle_pos_mean_sub = shuffle_W_pos1_all.mean(axis=0)[np.ix_(idx, idx)]
shuffle_neg_mean_sub = shuffle_W_neg1_all.mean(axis=0)[np.ix_(idx, idx)]
n_sub = idx.size
tri_u = np.triu_indices(n_sub, k=1)
shuffle_pos_flat = shuffle_pos_mean_sub[tri_u]
shuffle_neg_flat = shuffle_neg_mean_sub[tri_u]
W_pos_thr = np.percentile(shuffle_pos_flat, 99.5)
W_neg_thr = np.percentile(shuffle_neg_flat, 0.5)
sig_pos = (W_pos_sub > W_pos_thr) & ~np.eye(n_sub, dtype=bool)
sig_neg = (W_neg_sub < W_neg_thr) & ~np.eye(n_sub, dtype=bool)
edge_counts_pos = sig_pos.sum(axis=1)
edge_counts_neg = sig_neg.sum(axis=1)
lon_grid = np.linspace(-180, 180, 361)
lat_grid = np.linspace(-5, 90, 191)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf = Rbf(lons, lats, edge_counts_pos, function='multiquadric')
grid_data = rbf(lon2d, lat2d)
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
distance = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
distance = distance[np.ix_(idx, idx)]
tri_u = np.triu_indices_from(sig_pos, k=1)
sig_distances = distance[tri_u][sig_pos[tri_u]]
print(f'显著边数量: {sig_distances.size}')
print(f'平均距离: {np.mean(sig_distances):.1f} km')
sig_distances = sig_distances[sig_distances <= np.percentile(sig_distances, 99.5)]
counts, bins = np.histogram(sig_distances, bins=60, density=True)
bin_centers = (bins[:-1] + bins[1:]) / 2

def moving_average(x, w=3):
    return np.convolve(x, np.ones(w) / w, mode='same')
smoothed_counts = moving_average(counts, w=5)
plt.figure(figsize=(8, 5), dpi=200)
plt.plot(bin_centers, smoothed_counts, color='#2B6CA3', lw=2.2, label='Smoothed line')
plt.xlabel('Distance (km)', fontsize=13)
plt.ylabel('Probability density', fontsize=13)
plt.title('PDF of Significant Methane Link Distances (NH)', fontsize=14)
plt.grid(alpha=0.3, linestyle=':')
plt.legend(frameon=False)
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
counts, bins = np.histogram(sig_distances, bins=40, density=True)
bin_centers = (bins[:-1] + bins[1:]) / 2

def moving_average(x, w=2):
    return np.convolve(x, np.ones(w) / w, mode='same')
smoothed_counts = moving_average(counts, w=2)
idx = 10
x_11 = bin_centers[idx]
y_11 = smoothed_counts[idx]
print(f'第 11 个散点的 x 数值为: {x_11:.2f}')
plt.figure(figsize=(8, 5), dpi=200)
plt.scatter(bin_centers, smoothed_counts, color='#2B6CA3', s=30, alpha=0.7, label='Smoothed points')
plt.axvline(x=x_11, color='#E67E22', linestyle='-', linewidth=1.5, label=f'11th Point (x={x_11:.1f})')
plt.text(x_11 * 1.1, y_11, f'{x_11:.1f} km', color='#E67E22', fontweight='bold', va='bottom')
plt.xscale('log')
plt.yscale('log')
plt.xlabel('Distance (km)', fontsize=13)
plt.ylabel('Probability density', fontsize=13)
plt.title('PDF of Significant Methane Link Distances (NH)', fontsize=14)
plt.grid(alpha=0.3, linestyle=':')
plt.legend(frameon=False)
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
counts, bins = np.histogram(sig_distances, bins=44, density=True)
bin_centers = (bins[:-1] + bins[1:]) / 2

def moving_average(x, w=2):
    return np.convolve(x, np.ones(w) / w, mode='same')
smoothed_counts = moving_average(counts, w=2)
valid_mask = smoothed_counts > 0
y_min_data = np.min(smoothed_counts[valid_mask])
y_max_data = np.max(smoothed_counts[valid_mask])
mask_fit = (bin_centers >= 2000) & (bin_centers <= 4500) & (smoothed_counts > 0)
x_to_fit = bin_centers[mask_fit]
y_to_fit = smoothed_counts[mask_fit]
slope, intercept = (None, None)
if len(x_to_fit) > 1:
    log_x = np.log10(x_to_fit)
    log_y = np.log10(y_to_fit)
    slope, intercept = np.polyfit(log_x, log_y, 1)
    x_line = np.geomspace(2200, 5000, 50)
    y_line = 10 ** (slope * np.log10(x_line) + intercept)
    y_line = np.clip(y_line, y_min_data * 0.1, y_max_data * 10)
    print(f'拟合成功！斜率 (Slope): {slope:.4f}')
fig, ax = plt.subplots(figsize=(8, 8), dpi=200)
ax.scatter(bin_centers, smoothed_counts, color='#2B6CA3', s=30, alpha=0.3, label='All points')
ax.scatter(x_to_fit, y_to_fit, color='#D35400', s=35)
if slope is not None:
    ax.plot(x_line, y_line, color='red', linewidth=2.5, zorder=5, label=f'Power-law Fit: k={slope:.2f}')
if len(bin_centers) > 10:
    x_11 = bin_centers[10]
    ax.axvline(x=x_11, color='#E67E22', linestyle='--', alpha=0.6)
ax.set_xscale('log')
ax.set_yscale('log')
ax.set_xlim(max(1, bin_centers[bin_centers > 0].min()), bin_centers.max() * 1.2)
ax.set_ylim(y_min_data * 0.5, y_max_data * 2)
ax.axvline(x=x_11, color='#E67E22', linestyle='-', linewidth=1.5)
ax.text(x_11 * 1.1, y_11, f'{x_11:.1f} km', color='#E67E22', fontweight='bold', va='bottom')
fig.text(0.025, 1.05, 'a', fontsize=45, fontweight='bold', ha='left', va='top', transform=fig.transFigure)
ax.set_xlabel('Distance (km)', fontsize=12)
ax.set_ylabel('Probability density', fontsize=12)
ax.grid(alpha=0.2, which='both', linestyle=':')
ax.legend(frameon=False)
plt.tight_layout()
plt.show()
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial'], 'axes.linewidth': 1.5, 'xtick.major.width': 1.5, 'ytick.major.width': 1.5, 'xtick.direction': 'in', 'ytick.direction': 'in'})
fig, ax = plt.subplots(figsize=(8, 7), dpi=120)
ax.scatter(bin_centers, smoothed_counts, color='#34495E', s=100, alpha=0.4, edgecolor='none', zorder=2)
ax.scatter(x_to_fit, y_to_fit, color='#E67E22', s=120, alpha=0.9, edgecolor='white', linewidth=0.5, zorder=3)
if slope is not None:
    ax.plot(x_line, y_line, color='#C0392B', linewidth=3, label=f'Power-law Fit ($k$={slope:.2f})', zorder=5)
if len(bin_centers) > 10:
    x_11 = bin_centers[10]
    y_11_val = smoothed_counts[10]
    ax.axvline(x=x_11, color='#2980B9', linestyle='--', linewidth=2, alpha=0.6, zorder=1)
    ax.plot(x_11, y_11_val, marker='o', markersize=20, markerfacecolor='none', markeredgecolor='#2980B9', markeredgewidth=2, zorder=6)
    ax.text(x_11 * 1.2, y_11_val * 1.5, f'{x_11:.1f} km', color='#2980B9', fontsize=32, fontweight='bold', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=1))
ax.set_xscale('log')
ax.set_yscale('log')
left_limit = bin_centers[bin_centers > 0].min() * 0.8
right_limit = bin_centers.max() * 1.5
ax.set_xlim(left_limit, right_limit)
ax.set_ylim(y_min_data * 0.3, y_max_data * 3)
ax.set_xlabel('Distance (km)', fontsize=32)
ax.set_ylabel('PDF', fontsize=32)
ax.tick_params(axis='both', which='major', labelsize=32, length=8)
ax.tick_params(axis='both', which='minor', length=4, color='#bdc3c7')
ax.grid(True, which='major', linestyle='-', alpha=0.3, color='#bdc3c7')
ax.grid(True, which='minor', linestyle=':', alpha=0.15, color='#bdc3c7')
ax.legend(loc='lower left', frameon=False, fontsize=28, handletextpad=0.5)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.text(-0.08, 1.05, 'b', transform=ax.transAxes, fontsize=50, fontweight='bold', va='top', ha='right')
plt.tight_layout()
plt.savefig('outputs/figures/figure_010.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
counts, bins = np.histogram(sig_distances, bins=44, density=True)
bin_centers = (bins[:-1] + bins[1:]) / 2

def moving_average(x, w=2):
    return np.convolve(x, np.ones(w) / w, mode='same')
smoothed_counts = moving_average(counts, w=2)
valid_mask = smoothed_counts > 0
y_min_data = np.min(smoothed_counts[valid_mask])
y_max_data = np.max(smoothed_counts[valid_mask])
mask_fit_1 = (bin_centers >= 2000) & (bin_centers <= 4600) & (smoothed_counts > 0)
x_to_fit_1 = bin_centers[mask_fit_1]
y_to_fit_1 = smoothed_counts[mask_fit_1]
slope_1, intercept_1 = (None, None)
if len(x_to_fit_1) > 1:
    log_x_1 = np.log10(x_to_fit_1)
    log_y_1 = np.log10(y_to_fit_1)
    slope_1, intercept_1 = np.polyfit(log_x_1, log_y_1, 1)
    x_line_1 = np.geomspace(2000, 4600, 50)
    y_line_1 = 10 ** (slope_1 * np.log10(x_line_1) + intercept_1)
    y_line_1 = np.clip(y_line_1, y_min_data * 0.1, y_max_data * 10)
    print(f'拟合成功！斜率 (Slope): {slope_1:.4f}')
mask_fit_2 = (bin_centers >= 4300) & (bin_centers <= 5500) & (smoothed_counts > 0)
x_to_fit_2 = bin_centers[mask_fit_2]
y_to_fit_2 = smoothed_counts[mask_fit_2]
slope_2, intercept_2 = (None, None)
if len(x_to_fit_2) > 1:
    log_x_2 = np.log10(x_to_fit_2)
    log_y_2 = np.log10(y_to_fit_2)
    slope_2, intercept_2 = np.polyfit(log_x_2, log_y_2, 1)
    x_line_2 = np.geomspace(4300, 7000, 50)
    y_line_2 = 10 ** (slope_2 * np.log10(x_line_2) + intercept_2)
    y_line_2 = np.clip(y_line_2, y_min_data * 0.1, y_max_data * 10)
    print(f'拟合成功！斜率 (Slope): {slope_2:.4f}')
fig, ax = plt.subplots(figsize=(8, 8), dpi=200)
ax.scatter(bin_centers, smoothed_counts, color='#2B6CA3', s=30, alpha=0.3, label='All points')
if slope_1 is not None:
    ax.scatter(x_to_fit_1, y_to_fit_1, color='#D35400', s=35)
    ax.plot(x_line_1, y_line_1, color='red', linewidth=2.5, zorder=5, label=f'Power-law Fit (2000-4500 km): k={slope_1:.2f}')
if slope_2 is not None:
    ax.scatter(x_to_fit_2, y_to_fit_2, color='#8E44AD', s=35)
    ax.plot(x_line_2, y_line_2, color='#8E44AD', linewidth=2.5, zorder=5, label=f'Power-law Fit (4300-5500 km): k={slope_2:.2f}')
ax.set_xscale('log')
ax.set_yscale('log')
ax.set_xlim(max(1, bin_centers[bin_centers > 0].min()), bin_centers.max() * 1.2)
ax.set_ylim(y_min_data * 0.5, y_max_data * 2)
x_11 = bin_centers[10]
ax.axvline(x=x_11, color='#E67E22', linestyle='--', alpha=0.6)
ax.text(x_11 * 1.1, y_11, f'{x_11:.1f} km', color='#E67E22', fontweight='bold', va='bottom')
fig.text(0.025, 1.05, 'a', fontsize=45, fontweight='bold', ha='left', va='top', transform=fig.transFigure)
ax.set_xlabel('Distance (km)', fontsize=12)
ax.set_ylabel('Probability density', fontsize=12)
ax.grid(alpha=0.2, which='both', linestyle=':')
ax.legend(frameon=False)
plt.tight_layout()
plt.show()
mask_fit_2 = (bin_centers >= 4300) & (bin_centers <= 7000) & (smoothed_counts > 0)
x_to_fit_2 = bin_centers[mask_fit_2]
y_to_fit_2 = smoothed_counts[mask_fit_2]
slope_2, intercept_2 = (None, None)
if len(x_to_fit_2) > 1:
    log_x_2 = np.log10(x_to_fit_2)
    log_y_2 = np.log10(y_to_fit_2)
    slope_2, intercept_2 = np.polyfit(log_x_2, log_y_2, 1)
    x_line_2 = np.geomspace(4100, 7200, 100)
    y_line_2 = 10 ** (slope_2 * np.log10(x_line_2) + intercept_2)
    y_line_2 = np.clip(y_line_2, y_min_data * 0.1, y_max_data * 10)
if slope is not None:
    x_min_1 = x_to_fit_1.min() * 0.75
    x_max_1 = x_to_fit_1.max() * 1.4
    x_line_1 = np.geomspace(x_min_1, x_max_1, 150)
    y_line_1 = 10 ** (slope * np.log10(x_line_1) + intercept)
    y_line_1 = np.clip(y_line_1, y_min_data * 0.1, y_max_data * 10)
    ax.plot(x_line_1, y_line_1, color='#C0392B', linewidth=3, label=f'Power-law Fit ($k$={slope:.2f})', zorder=6)
if slope_2 is not None:
    x_min_2 = x_to_fit_2.min() * 0.85
    x_max_2 = x_to_fit_2.max() * 1.2
    x_line_2 = np.geomspace(x_min_2, x_max_2, 150)
    y_line_2 = 10 ** (slope_2 * np.log10(x_line_2) + intercept_2)
    y_line_2 = np.clip(y_line_2, y_min_data * 0.1, y_max_data * 10)
    ax.plot(x_line_2, y_line_2, color='#8E44AD', linewidth=4, linestyle='-', zorder=6)
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial'], 'axes.linewidth': 1.5, 'xtick.major.width': 1.5, 'ytick.major.width': 1.5, 'xtick.direction': 'in', 'ytick.direction': 'in'})
fig, ax = plt.subplots(figsize=(8, 7), dpi=120)
ax.scatter(bin_centers, smoothed_counts, color='#34495E', s=100, alpha=0.4, edgecolor='none', zorder=2)
ax.scatter(x_to_fit_1, y_to_fit_1, color='#E67E22', s=120, alpha=0.9, edgecolor='white', linewidth=0.5, zorder=3)
ax.scatter(x_to_fit_2, y_to_fit_2, color='#8E44AD', s=120, alpha=0.4, edgecolor='white', linewidth=0.5, zorder=4)
if slope is not None:
    ax.plot(x_line_1, y_line_1, color='#C0392B', linewidth=3, label=f'Power-law Fit ($k$={slope:.2f})', zorder=6)
if slope_2 is not None:
    ax.plot(x_line_2, y_line_2, color='#8E44AD', linewidth=4, linestyle='-', zorder=6)
if len(bin_centers) > 10:
    x_11 = bin_centers[10]
    y_11_val = smoothed_counts[10]
    ax.axvline(x=x_11, color='#2980B9', linestyle='--', linewidth=2, alpha=0.6, zorder=1)
    ax.plot(x_11, y_11_val, marker='o', markersize=20, markerfacecolor='none', markeredgecolor='#2980B9', markeredgewidth=2, zorder=7)
    ax.text(x_11 * 1.2, y_11_val * 1.5, f'{x_11:.0f} km', color='#2980B9', fontsize=31, fontweight='bold', bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=1))
ax.set_xscale('log')
ax.set_yscale('log')
left_limit = bin_centers[bin_centers > 0].min() * 0.8
right_limit = bin_centers.max() * 1.5
ax.set_xlim(left_limit, right_limit)
ax.set_ylim(y_min_data * 0.3, y_max_data * 3)
ax.set_xlabel('Distance (km)', fontsize=31)
ax.set_ylabel('PDF', fontsize=31)
ax.tick_params(axis='both', which='major', labelsize=31, length=8, pad=12)
ax.tick_params(axis='both', which='minor', length=6, color='#bdc3c7')
ax.legend(loc='lower left', frameon=False, fontsize=28, handletextpad=0.5)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.text(-0.08, 1.05, 'b', transform=ax.transAxes, fontsize=50, fontweight='bold', va='top', ha='right')
plt.tight_layout()
plt.savefig('outputs/figures/figure_010.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
dispath = 'data/'
path = 'data/network/observed/'
path1 = 'data/network/surrogates/'
distance = np.load(dispath + 'pairwise_distances.npy')
W_pos1 = np.load(path + 'positive_link_weights.npy')
W_neg1 = np.load(path + 'negative_link_weights.npy')
shuffle_W_pos1_all = np.load(path1 + 'surrogate_positive_weights.npy')
shuffle_W_neg1_all = np.load(path1 + 'surrogate_negative_weights.npy')
lat = np.load('data/node_latitudes.npy')
mask = (lat >= -5) & (lat <= 90)
idx = np.where(mask)[0]
n_sub = idx.size
print(f'北半球子集节点数: {n_sub}')
distance_sub = distance[np.ix_(idx, idx)]
W_pos_sub = W_pos1[np.ix_(idx, idx)]
W_neg_sub = W_neg1[np.ix_(idx, idx)]
shuffle_W_pos_mean_sub = shuffle_W_pos1_all.mean(axis=0)[np.ix_(idx, idx)]
shuffle_W_neg_mean_sub = shuffle_W_neg1_all.mean(axis=0)[np.ix_(idx, idx)]
tri_upper = np.triu_indices(n_sub, k=1)
dist_flat = distance_sub[tri_upper]
W_pos_flat = W_pos_sub[tri_upper]
W_neg_flat = W_neg_sub[tri_upper]
shuffle_pos_flat = shuffle_W_pos_mean_sub[tri_upper]
shuffle_neg_flat = shuffle_W_neg_mean_sub[tri_upper]
W_pos_95 = np.percentile(shuffle_pos_flat, 99.5)
W_neg_95 = np.percentile(shuffle_neg_flat, 0.5)
print('NH 99.5th for W_pos (shuffle mean):', W_pos_95)
print('NH 0.5th  for W_neg (shuffle mean):', W_neg_95)
d1 = plt.hist(W_pos_flat, bins=25, density=True, alpha=1)
dy = d1[0]
dx = d1[1][:-1] + (d1[1][1:] - d1[1][:-1]) / 2
d2 = plt.hist(shuffle_pos_flat, bins=25, density=True, alpha=1)
phdy = d2[0]
phdx = d2[1][:-1] + (d2[1][1:] - d2[1][:-1]) / 2
import matplotlib.pyplot as plt
import numpy as np
fig, ax = plt.subplots(figsize=(8, 8), dpi=200, facecolor='white')
ax.plot(dx, dy, color='#C24976', linewidth=5, markersize=7, markeredgecolor='white', markeredgewidth=1.2, label='Original data', alpha=0.95)
ax.plot(phdx, phdy, color='#828D93', linewidth=5, markersize=7, markeredgecolor='white', markeredgewidth=1.2, label='Shuffle data', alpha=0.95)
ax.plot(phdx, phdy, color='#7F8C8D', linewidth=2.2, alpha=0.95, zorder=2)
ax.axvline(x=W_pos_95, color='#F1A93B', linestyle='--', linewidth=4, alpha=0.85, label=f'99.5% percentile: {W_pos_95:.2f}')
ax.set_xlabel('$   W   $', fontsize=32, fontweight='medium')
ax.set_ylabel('PDF', fontsize=32, fontweight='medium')
ax.set_yscale('log')
ax.legend(loc='upper right', borderpad=0.6, labelspacing=0.5, prop={'size': 20}, handletextpad=0.8, scatterpoints=1, markerscale=4)
fig.text(0.07, 1.01, 'a', fontsize=54, fontweight='bold', ha='left', va='top', transform=fig.transFigure)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_linewidth(1.2)
ax.spines['bottom'].set_linewidth(1.2)
ax.xaxis.label.set_size(35)
ax.yaxis.label.set_size(35)
ax.tick_params(axis='both', which='major', labelsize=32, pad=12)
ax.minorticks_off()
ax.grid(False)
plt.tight_layout()
plt.savefig('outputs/figures/figure_011.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
dispath = 'data/'
path = 'data/network/observed/'
path1 = 'data/network/surrogates/'
distance = np.load(dispath + 'pairwise_distances.npy')
W_pos1 = np.load(path + 'positive_link_weights.npy')
W_neg1 = np.load(path + 'negative_link_weights.npy')
shuffle_W_pos_all = np.load(path1 + 'surrogate_positive_weights.npy')
shuffle_W_neg_all = np.load(path1 + 'surrogate_negative_weights.npy')
lons_all = np.load('data/node_longitudes.npy')
lats_all = np.load('data/node_latitudes.npy')
lons_all = np.where(lons_all > 180, lons_all - 360, lons_all)
mask = (lats_all >= -5) & (lats_all <= 90)
idx = np.where(mask)[0]
lons = lons_all[idx]
lats = lats_all[idx]
print(f'北半球节点数: {idx.size}')
W_pos_sub = W_pos1[np.ix_(idx, idx)]
W_neg_sub = W_neg1[np.ix_(idx, idx)]
shuffle_pos_mean_sub = shuffle_W_pos_all.mean(axis=0)[np.ix_(idx, idx)]
shuffle_neg_mean_sub = shuffle_W_neg_all.mean(axis=0)[np.ix_(idx, idx)]
n_sub = idx.size
tri_u = np.triu_indices(n_sub, k=1)
shuffle_pos_flat = shuffle_pos_mean_sub[tri_u]
shuffle_neg_flat = shuffle_neg_mean_sub[tri_u]
W_pos_thr = np.percentile(shuffle_pos_flat, 99.5)
W_neg_thr = np.percentile(shuffle_neg_flat, 0.5)
sig_pos = (W_pos_sub > W_pos_thr) & ~np.eye(n_sub, dtype=bool)
sig_neg = (W_neg_sub < W_neg_thr) & ~np.eye(n_sub, dtype=bool)
edge_counts_pos = sig_pos.sum(axis=1)
edge_counts_neg = sig_neg.sum(axis=1)
lon_grid = np.linspace(-180, 180, 361)
lat_grid = np.linspace(-5, 90, 191)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf = Rbf(lons, lats, edge_counts_pos, function='multiquadric')
grid_data = rbf(lon2d, lat2d)
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import matplotlib as mpl
mpl.rcParams.update({'font.size': 14})
path = 'data/network/working/'
W_pos1 = np.load(path + 'positive_link_weights.npy')
tau = np.load(path + 'positive_link_lags.npy')
W_pos_all = np.load(path + 'surrogate_positive_weights.npy')
lons_all = np.load('data/node_longitudes.npy')
lats_all = np.load('data/node_latitudes.npy')
lons_all = np.where(lons_all > 180, lons_all - 360, lons_all)
mask = (lats_all >= -5) & (lats_all <= 90)
idx = np.where(mask)[0]
lons = lons_all[idx]
lats = lats_all[idx]
n_sub = len(idx)
print(f'北半球节点数: {n_sub}')
W_pos_sub = W_pos1[np.ix_(idx, idx)]
tau_sub = tau[np.ix_(idx, idx)]
shuffle_pos_mean_sub = W_pos_all.mean(axis=0)[np.ix_(idx, idx)]
n_sub = idx.size
tri_u = np.triu_indices(n_sub, k=1)
shuffle_pos_flat = shuffle_pos_mean_sub[tri_u]
W_pos_95_overall = np.percentile(shuffle_pos_flat.flatten(), 99.5)
W_pos_5_overall = np.percentile(shuffle_pos_flat.flatten(), 0.5)
sig_edges = (W_pos_sub > W_pos_95_overall) & ~np.eye(n_sub, dtype=bool)
out_degree = np.zeros(n_sub, dtype=int)
in_degree = np.zeros(n_sub, dtype=int)
for i in range(n_sub):
    print(f'处理节点 {i}/{n_sub}')
    for j in range(i + 1, n_sub):
        if sig_edges[i, j]:
            tau_ij = tau_sub[i, j]
            if tau_ij > 0:
                out_degree[i] += 1
                in_degree[j] += 1
            elif tau_ij < 0:
                out_degree[j] += 1
                in_degree[i] += 1
        elif sig_edges[j, i]:
            tau_ji = tau_sub[j, i]
            if tau_ji > 0:
                out_degree[j] += 1
                in_degree[i] += 1
            elif tau_ji < 0:
                out_degree[i] += 1
                in_degree[j] += 1
print('北半球节点出度和入度计算完成！')
print('平均出度:', np.mean(out_degree))
print('平均入度:', np.mean(in_degree))
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
import matplotlib as mpl
mpl.rcParams.update({'font.size': 14})
divergence = out_degree - in_degree
lon_grid = np.linspace(np.min(lons) - 2, np.max(lons) + 2, 200)
lat_grid = np.linspace(np.min(lats) - 2, np.max(lats) + 2, 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_out = Rbf(lons, lats, out_degree, function='multiquadric', smooth=2)
rbf_in = Rbf(lons, lats, in_degree, function='multiquadric', smooth=2)
rbf_div = Rbf(lons, lats, divergence, function='multiquadric', smooth=2)
out_interp = rbf_out(lon2d, lat2d)
in_interp = rbf_in(lon2d, lat2d)
div_interp = rbf_div(lon2d, lat2d)
plt.figure(figsize=(12, 8), dpi=200)
ax = plt.axes(projection=ccrs.PlateCarree())
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.set_extent([np.min(lons) - 5, np.max(lons) + 5, np.min(lats), np.max(lats)], ccrs.PlateCarree())
ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.5)
ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.5, linewidth=0.5)
gl.top_labels = False
gl.right_labels = False
gl.left_labels = True
gl.bottom_labels = True
gl.xlabel_style = {'size': 18}
gl.ylabel_style = {'size': 18}
cf = ax.contourf(lon2d, lat2d, out_interp, 20, cmap='Purples', transform=ccrs.PlateCarree(), alpha=0.85)
vmin, vmax = (0, 200)
ticks = np.arange(vmin, vmax + 1, 50)
cbar = plt.colorbar(cf, orientation='vertical', shrink=0.35, pad=0.02, aspect=15, extend='both')
cbar.set_ticks(ticks)
cbar.ax.tick_params(labelsize=14, width=2, length=6)
cbar.outline.set_linewidth(0.8)
cbar.extend = 'both'
ax.text(-0.05, 1.15, 'c', transform=ax.transAxes, fontsize=35, fontweight='bold', va='top', ha='left')
plt.tight_layout()
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
import matplotlib as mpl
from matplotlib.patches import Ellipse
mpl.rcParams.update({'font.size': 10})
lon_grid = np.linspace(np.min(lons) - 2, np.max(lons) + 2, 200)
lat_grid = np.linspace(-5, 90, 150)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_out = Rbf(lons, lats, out_degree, function='multiquadric', smooth=2)
out_interp = rbf_out(lon2d, lat2d)
fig = plt.figure(figsize=(9, 8), dpi=300)
proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.set_extent([lon_grid.min(), lon_grid.max(), -5, 90], crs=proj)
ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.3)
ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 15}
gl.ylabel_style = {'size': 15}
vmin, vmax = (20, 180)
levels = np.linspace(vmin, vmax, 17)
cf = ax.contourf(lon2d, lat2d, out_interp, levels=levels, cmap='Purples', extend='both', alpha=0.85, transform=proj)
cbar = plt.colorbar(cf, ax=ax, orientation='vertical', shrink=0.25, pad=0.02, aspect=15)
cbar.ax.tick_params(labelsize=15, width=1.2, length=5)
cbar.outline.set_linewidth(0.4)
all_ticks = cbar.get_ticks()
cbar.set_ticks(all_ticks[::2])
ax.text(-0.06, 1.16, 'c', transform=ax.transAxes, fontsize=25, fontweight='bold', va='top', ha='left')
ax.text(0.01, 1.12, 'Out degree', transform=ax.transAxes, fontsize=16, va='top', ha='left')
plt.tight_layout()
region_boxes = {'China': {'lon_min': 95, 'lon_max': 130, 'lat_min': 20, 'lat_max': 50}, 'India': {'lon_min': 68, 'lon_max': 97, 'lat_min': 8, 'lat_max': 37}, 'America': {'lon_min': -110, 'lon_max': -70, 'lat_min': 25, 'lat_max': 55}, 'Europe': {'lon_min': 20, 'lon_max': 80, 'lat_min': 48, 'lat_max': 67}}
for name, box in region_boxes.items():
    lon_c = (box['lon_min'] + box['lon_max']) / 2
    lat_c = (box['lat_min'] + box['lat_max']) / 2
    width = (box['lon_max'] - box['lon_min']) * 1.12
    height = (box['lat_max'] - box['lat_min']) * 1.25
    ellipse = Ellipse((lon_c, lat_c), width=width, height=height, angle=0, fill=False, edgecolor='#343434', linewidth=2, linestyle='--', alpha=0.95, transform=ccrs.PlateCarree(), zorder=6)
    ax.add_patch(ellipse)
plt.savefig('outputs/figures/figure_012.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
import matplotlib as mpl
mpl.rcParams.update({'font.size': 14})
lon_grid = np.linspace(np.min(lons) - 2, np.max(lons) + 2, 200)
lat_grid = np.linspace(-5, 90, 150)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_out = Rbf(lons, lats, in_degree, function='multiquadric', smooth=2)
in_interp = rbf_out(lon2d, lat2d)
fig = plt.figure(figsize=(9, 8), dpi=300)
proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.set_extent([lon_grid.min(), lon_grid.max(), -5, 90], crs=proj)
ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 15}
gl.ylabel_style = {'size': 15}
vmin, vmax = (20, 140)
levels = np.linspace(vmin, vmax, 13)
cf = ax.contourf(lon2d, lat2d, in_interp, levels=levels, cmap='Oranges', extend='both', alpha=0.85, transform=proj)
cbar = plt.colorbar(cf, ax=ax, orientation='vertical', shrink=0.25, pad=0.02, aspect=15)
cbar.ax.tick_params(labelsize=15, width=1.2, length=5)
cbar.outline.set_linewidth(0.4)
all_ticks = cbar.get_ticks()
cbar.set_ticks(all_ticks[::2])
ax.text(-0.06, 1.16, 'd', transform=ax.transAxes, fontsize=25, fontweight='bold', va='top', ha='left')
region_boxes = {'China': {'lon_min': 95, 'lon_max': 130, 'lat_min': 20, 'lat_max': 50}, 'India': {'lon_min': 68, 'lon_max': 97, 'lat_min': 8, 'lat_max': 37}, 'America': {'lon_min': -110, 'lon_max': -70, 'lat_min': 25, 'lat_max': 55}, 'Europe': {'lon_min': 20, 'lon_max': 80, 'lat_min': 48, 'lat_max': 67}}
for name, box in region_boxes.items():
    lon_c = (box['lon_min'] + box['lon_max']) / 2
    lat_c = (box['lat_min'] + box['lat_max']) / 2
    width = (box['lon_max'] - box['lon_min']) * 1.12
    height = (box['lat_max'] - box['lat_min']) * 1.25
    ellipse = Ellipse((lon_c, lat_c), width=width, height=height, angle=0, fill=False, edgecolor='#343434', linewidth=2, linestyle='--', alpha=0.95, transform=ccrs.PlateCarree(), zorder=6)
    ax.add_patch(ellipse)
ax.text(0.01, 1.12, 'In degree', transform=ax.transAxes, fontsize=16, va='top', ha='left')
plt.tight_layout()
plt.savefig('outputs/figures/figure_013.jpg', dpi=300, bbox_inches='tight')
plt.show()
import xarray as xr
file = 'data/meteorology/meridional_wind_2010.nc'
ds = xr.open_dataset(file)
list(ds.data_vars)
list(ds.coords)
print(ds['time_bnds'][:])
import xarray as xr
import os
import numpy as np
import xarray as xr
data_dir = 'data/observations/vwind_rossby'
years = range(2010, 2020)
v250_list = []
for y in years:
    file = os.path.join(data_dir, f'meridional_wind_{y}.nc')
    print('Processing:', file)
    ds = xr.open_dataset(file, engine='netcdf4')
    v250 = ds['vwnd'].sel(level=250)
    v250_list.append(v250)
v250_all = xr.concat(v250_list, dim='time')
print(v250_all)
is_feb29 = (v250_all['time.month'] == 2) & (v250_all['time.day'] == 29)
v250_noleap = v250_all.sel(time=~is_feb29)
time = v250_noleap['time'].values
doy_array = v250_noleap['time'].dt.dayofyear.values
lat = v250_noleap['lat'].values
lon = v250_noleap['lon'].values
data = v250_noleap.values
nt, nlat, nlon = data.shape
data_2d = data.reshape(nt, nlat * nlon)
detrended_data = np.empty_like(data_2d, dtype=np.float32)
for j in range(data_2d.shape[1]):
    if j % 500 == 0:
        print(f'处理格点 {j}/{data_2d.shape[1]}')
    for k in range(1, 366):
        indices = np.where(doy_array == k)[0]
        if len(indices) == 0:
            continue
        values = data_2d[indices, j]
        mean_k = np.mean(values)
        std_k = np.std(values, ddof=1)
        if std_k <= 0 or std_k < 0.001:
            std_k = 1.0
        detrended_data[indices, j] = (values - mean_k) / std_k
detrended_3d = detrended_data.reshape(nt, nlat, nlon)
v250_deseason = xr.DataArray(detrended_3d, dims=('time', 'lat', 'lon'), coords={'time': time, 'lat': lat, 'lon': lon}, name='v250')
week_index = np.arange(v250_deseason.sizes['time']) // 7
v250_weekly = v250_deseason.groupby(xr.DataArray(week_index, dims='time')).mean('time')
print(v250_weekly)
print(v250_weekly.dims)
v250_weekly = v250_weekly.rename({'group': 'week'})
v250_midlat = v250_weekly.sel(lat=slice(60, 35))
import numpy as np
weights = np.cos(np.deg2rad(v250_midlat['lat']))
v250_zonal = v250_midlat.weighted(weights).mean(dim='lat')
print(v250_zonal)
from scipy.fft import fft, fftfreq
lon = v250_zonal['lon'].values
N = lon.size
fft_list = []
for i in range(v250_zonal.sizes['week']):
    signal = v250_zonal.isel(week=i).values
    fft_res = fft(signal)
    fft_list.append(fft_res)
fft_arr = np.array(fft_list)
k = fftfreq(N, d=1 / N)
amplitude = 2.0 / N * np.abs(fft_arr)
phase = np.angle(fft_arr)
import xarray as xr
SinAmpl = xr.DataArray(amplitude, dims=('week', 'wavenumber'), coords={'week': v250_zonal['week'], 'wavenumber': k}, name='amplitude')
SinPhase = xr.DataArray(phase, dims=('week', 'wavenumber'), coords={'week': v250_zonal['week'], 'wavenumber': k}, name='phase')
import scipy.stats
from scipy.fft import fft, fftfreq
weeks_PhaseLocking = []
MeanPhase_PhaseLocking = []
MeanAmplitude_PhaseLocking = []
for each_wavenumber in [1, 2, 3, 4, 5, 6, 7, 8]:
    phase_k = SinPhase.sel(wavenumber=each_wavenumber)
    ampl_k = SinAmpl.sel(wavenumber=each_wavenumber)
    thr = ampl_k.quantile(0.9)
    phase_strong = phase_k.where(ampl_k >= thr).dropna('week')
    ampl_strong = ampl_k.where(ampl_k >= thr).dropna('week')
    x = np.linspace(-np.pi, np.pi, 300)
    kde = scipy.stats.gaussian_kde(phase_strong.values, bw_method='silverman')
    pdf = kde(x)
    phi0 = x[pdf.argmax()]
    uncertainty = 0.25
    low = phi0 - uncertainty * np.pi
    high = phi0 + uncertainty * np.pi
    phase_locked = phase_strong.where((phase_strong >= low) & (phase_strong <= high)).dropna('week')
    weeks_locked = phase_locked['week'].values
    mean_phase = phase_locked.mean().values
    mean_ampl = ampl_strong.where((phase_strong >= low) & (phase_strong <= high)).mean().values
    weeks_PhaseLocking.append(weeks_locked)
    MeanPhase_PhaseLocking.append(mean_phase)
    MeanAmplitude_PhaseLocking.append(mean_ampl)
k0 = 7
weeks_wave5 = weeks_PhaseLocking[k0 - 1]
v250_wave7_composite = v250_weekly.sel(week=weeks_wave5).mean('week')
v250_wave5_composite = v250_weekly.sel(week=weeks_wave5).mean('week')
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
vplot = v250_wave5_composite.copy()
if vplot.lon.max() > 180:
    vplot = vplot.assign_coords(lon=(vplot.lon + 180) % 360 - 180).sortby('lon')
else:
    vplot = vplot.sortby('lon')
lon = vplot['lon'].values
lat = vplot['lat'].values
fig = plt.figure(figsize=(12, 8), dpi=300)
m = Basemap(projection='cyl', llcrnrlon=-180, urcrnrlon=180, llcrnrlat=0, urcrnrlat=90, resolution='c')
m.drawcoastlines(linewidth=0.6)
m.drawparallels(np.arange(-60, 91, 30), labels=[1, 0, 0, 0], linewidth=0.3, fontsize=9)
m.drawmeridians(np.arange(-180, 181, 60), labels=[0, 0, 0, 1], linewidth=0.3, fontsize=9)
lon2d, lat2d = np.meshgrid(lon, lat)
x, y = m(lon2d, lat2d)
vmax = np.nanmax(np.abs(vplot.values))
levels = np.linspace(-vmax, vmax, 21)
cf = m.contourf(x, y, vplot.values, levels=levels, cmap='RdBu_r', extend='both')
cbar = m.colorbar(cf, location='bottom', pad='15%')
cbar.set_label('250 hPa meridional wind anomaly (m s$^{-1}$)', fontsize=11)
plt.title('Phase-locked Rossby wave-7 pattern (250 hPa)', loc='left', fontsize=13)
plt.text(-0.05, 1.15, 'd', transform=ax.transAxes, fontsize=35, fontweight='bold', va='top', ha='left')
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.ticker import MaxNLocator
from matplotlib.ticker import MultipleLocator
vplot = v250_wave5_composite.copy()
if vplot.lon.max() > 180:
    vplot = vplot.assign_coords(lon=(vplot.lon + 180) % 360 - 180).sortby('lon')
else:
    vplot = vplot.sortby('lon')
vplot = vplot.sel(lat=slice(90, -5))
lon = vplot.lon.values
lat = vplot.lat.values
fig = plt.figure(figsize=(9, 8), dpi=300)
proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.set_extent([lon.min(), lon.max(), lat.min(), lat.max()], crs=proj)
ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 15}
gl.ylabel_style = {'size': 15}
vmax = 0.6
levels = np.linspace(-vmax, vmax, 13)
cf = ax.contourf(lon, lat, vplot.values, levels=levels, cmap='PuOr', extend='both', transform=proj)
cbar = plt.colorbar(cf, ax=ax, orientation='vertical', shrink=0.25, pad=0.02, aspect=15)
cbar.ax.tick_params(labelsize=15, width=1.2, length=5)
for i, tick in enumerate(cbar.ax.yaxis.get_major_ticks()):
    if i % 2 == 1:
        tick.label1.set_visible(False)
        tick.tick1line.set_visible(False)
        tick.tick2line.set_visible(False)
for i, label in enumerate(cbar.ax.get_yticklabels()):
    if i % 2 == 1:
        label.set_visible(False)
cbar.outline.set_linewidth(0.4)
ax.text(-0.06, 1.16, 'e', transform=ax.transAxes, fontsize=25, fontweight='bold', va='top', ha='left')
ax.text(0.01, 1.12, '250 hPa meridional wind (wave-7)', transform=ax.transAxes, fontsize=16, va='top', ha='left')
plt.tight_layout()
plt.savefig('outputs/figures/figure_014.jpg', dpi=300, bbox_inches='tight')
plt.show()
