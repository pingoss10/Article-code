import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
dispath = 'data/'
path = 'data/network/observed/'
path1 = 'data/network/surrogates/'
distance = np.load(dispath + 'pairwise_distances.npy')
W_pos1 = np.load(path + 'positive_link_weights.npy')
W_neg1 = np.load(path + 'negative_link_weights.npy')
shuffle_W_pos_all = np.load(path1 + 'surrogate_positive_weights.npy')
shuffle_W_neg_all = np.load(path1 + 'surrogate_negative_weights.npy')
lons_all = np.load('data/node_longitudes.npy')
lats_all = np.load('data/node_latitudes.npy')
lons_all = np.where(lons_all > 180, lons_all - 360, lons_all)
mask = (lats_all >= -5) & (lats_all <= 90)
idx = np.where(mask)[0]
lons = lons_all[idx]
lats = lats_all[idx]
print(f'北半球节点数: {idx.size}')
W_pos_sub = W_pos1[np.ix_(idx, idx)]
W_neg_sub = W_neg1[np.ix_(idx, idx)]
shuffle_pos_mean_sub = shuffle_W_pos_all.mean(axis=0)[np.ix_(idx, idx)]
shuffle_neg_mean_sub = shuffle_W_neg_all.mean(axis=0)[np.ix_(idx, idx)]
n_sub = idx.size
tri_u = np.triu_indices(n_sub, k=1)
shuffle_pos_flat = shuffle_pos_mean_sub[tri_u]
shuffle_neg_flat = shuffle_neg_mean_sub[tri_u]
W_pos_thr = np.percentile(shuffle_pos_flat, 99.5)
W_neg_thr = np.percentile(shuffle_neg_flat, 0.5)
sig_pos = (W_pos_sub > W_pos_thr) & ~np.eye(n_sub, dtype=bool)
sig_neg = (W_neg_sub < W_neg_thr) & ~np.eye(n_sub, dtype=bool)
edge_counts_pos = sig_pos.sum(axis=1)
edge_counts_neg = sig_neg.sum(axis=1)
lon_grid = np.linspace(-180, 180, 361)
lat_grid = np.linspace(-5, 90, 191)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf = Rbf(lons, lats, edge_counts_pos, function='multiquadric')
grid_data = rbf(lon2d, lat2d)
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import matplotlib as mpl
mpl.rcParams.update({'font.size': 14})
path = 'data/network/working/'
W_pos1 = np.load(path + 'positive_link_weights.npy')
tau = np.load(path + 'positive_link_lags.npy')
W_pos_all = np.load(path + 'surrogate_positive_weights.npy')
lons_all = np.load('data/node_longitudes.npy')
lats_all = np.load('data/node_latitudes.npy')
lons_all = np.where(lons_all > 180, lons_all - 360, lons_all)
mask = (lats_all >= -5) & (lats_all <= 90)
idx = np.where(mask)[0]
lons = lons_all[idx]
lats = lats_all[idx]
n_sub = len(idx)
print(f'北半球节点数: {n_sub}')
W_pos_sub = W_pos1[np.ix_(idx, idx)]
tau_sub = tau[np.ix_(idx, idx)]
shuffle_pos_mean_sub = W_pos_all.mean(axis=0)[np.ix_(idx, idx)]
n_sub = idx.size
tri_u = np.triu_indices(n_sub, k=1)
shuffle_pos_flat = shuffle_pos_mean_sub[tri_u]
W_pos_95_overall = np.percentile(shuffle_pos_flat.flatten(), 99.5)
W_pos_5_overall = np.percentile(shuffle_pos_flat.flatten(), 0.5)
sig_edges = (W_pos_sub > W_pos_95_overall) & ~np.eye(n_sub, dtype=bool)
out_degree = np.zeros(n_sub, dtype=int)
in_degree = np.zeros(n_sub, dtype=int)
for i in range(n_sub):
    print(f'处理节点 {i}/{n_sub}')
    for j in range(i + 1, n_sub):
        if sig_edges[i, j]:
            tau_ij = tau_sub[i, j]
            if tau_ij > 0:
                out_degree[i] += 1
                in_degree[j] += 1
            elif tau_ij < 0:
                out_degree[j] += 1
                in_degree[i] += 1
        elif sig_edges[j, i]:
            tau_ji = tau_sub[j, i]
            if tau_ji > 0:
                out_degree[j] += 1
                in_degree[i] += 1
            elif tau_ji < 0:
                out_degree[i] += 1
                in_degree[j] += 1
print('北半球节点出度和入度计算完成！')
print('平均出度:', np.mean(out_degree))
print('平均入度:', np.mean(in_degree))
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from sklearn.neighbors import KernelDensity
from matplotlib import gridspec
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
distance_full = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lat_all[idx_nh]
lons = lon_all[idx_nh]
lons = (lons + 180) % 360 - 180
distance = distance_full[np.ix_(idx_nh, idx_nh)]
n_sub = len(lons)
lon_min, lon_max = (-110, -70)
lat_min, lat_max = (30, 50)
region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
region_idx = np.where(region_mask)[0]
print(f'目标区域节点数: {len(region_idx)}')
dist_th = 4260.0
dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
min_dist_to_region = dist_region_to_all.min(axis=0)
near_nodes = min_dist_to_region <= dist_th
far_nodes = ~near_nodes
print('近场节点数:', int(near_nodes.sum()), '远场节点数:', int(far_nodes.sum()))
influence_near = np.zeros(n_sub, dtype=np.int32)
influence_far = np.zeros(n_sub, dtype=np.int32)
endpoints_near = []
endpoints_far = []
for i in region_idx:
    for j in range(n_sub):
        if i == j:
            continue
        is_outgoing = sig_edges[i, j] and tau_sub[i, j] > 0 or (sig_edges[j, i] and tau_sub[j, i] < 0)
        if not is_outgoing:
            continue
        if near_nodes[j]:
            influence_near[j] += 1
            endpoints_near.append(j)
        else:
            influence_far[j] += 1
            endpoints_far.append(j)
endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
print('近场端点数 L_near =', len(endpoints_near))
print('远场端点数 L_far  =', len(endpoints_far))
np.save('regional_near_endpoints.npy', endpoints_near)
np.save('regional_far_endpoints.npy', endpoints_far)
print('endpoints 已保存：')
print('input_015.npy')
print('input_016.npy')

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        print(k)
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)
sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=100, seed=1)
sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=100, seed=2)
print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
influence_near_sig = influence_near.copy()
influence_far_sig = influence_far.copy()
influence_near_sig[~sig_mask_near] = 0
influence_far_sig[~sig_mask_far] = 0
lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_near = Rbf(lons, lats, influence_near_sig.astype(float), function='linear', smooth=3)
rbf_far = Rbf(lons, lats, influence_far_sig.astype(float), function='linear', smooth=3)
influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(int)
influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(int)
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

def setup_ax(ax):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.4)
    gl.top_labels = False
    gl.right_labels = False
setup_ax(ax1)
vmax = int(np.nanmax(influence_interp_near))
levels = np.arange(0, max(vmax, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.set_title('Out-degree (< 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
setup_ax(ax2)
vmax1 = int(np.nanmax(influence_interp_far))
levels1 = np.arange(0, max(vmax1, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels1, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.set_title('Out-degree (> 4260 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
for ax in (ax1, ax2):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 13}
    gl.ylabel_style = {'size': 13}
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, max(vmax_near, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels_near, cmap='Reds', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.text(-0.06, 1.15, 'i', transform=ax1.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax1.text(0.01, 1.11, 'Out-degree (< 4260 km)', transform=ax1.transAxes, fontsize=13, va='top', ha='left')
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar1.outline.set_linewidth(0.4)
ticks1 = cbar1.get_ticks()
cbar1.set_ticks(ticks1[::2])
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, max(vmax_far, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels_far, cmap='Reds', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.text(-0.06, 1.15, 'j', transform=ax2.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax2.text(0.01, 1.11, 'Out degree (> 4260 km)', transform=ax2.transAxes, fontsize=13, va='top', ha='left')
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar2.outline.set_linewidth(0.4)
ticks2 = cbar2.get_ticks()
cbar2.set_ticks(ticks2[::2])
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.linewidth'] = 0.8
fig = plt.figure(figsize=(12, 7), dpi=300)
proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax.set_extent([-180, 180, -5, 90], crs=proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333', zorder=1)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 16}
gl.ylabel_style = {'size': 16}
data_near_masked = np.ma.masked_less(influence_interp_near, 0.1)
data_far_masked = np.ma.masked_less(influence_interp_far, 0.1)
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, vmax_near + 5, 5)
PuRd_mid = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p8', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
cf_near = ax.contourf(lon2d, lat2d, data_near_masked, levels=levels_near, cmap=PuRd_mid, alpha=0.8, transform=proj, extend='both', zorder=2, antialiased=True)
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, vmax_far + 2, 2)
cf_far = ax.contourf(lon2d, lat2d, data_far_masked, levels=levels_far, cmap='GnBu', alpha=0.7, transform=proj, extend='both', zorder=3, antialiased=True)
lon_min, lon_max = (-110, -70)
lat_min, lat_max = (30, 50)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax.plot(rect_lons, rect_lats, color='black', linewidth=1.5, transform=proj, zorder=10)
cax1 = fig.add_axes([0.15, 0.28, 0.34, 0.025])
cb1 = fig.colorbar(cf_near, cax=cax1, orientation='horizontal')
cb1.set_label('Out-degree (< 4,260 km)', fontsize=16)
cb1.set_ticks(levels_near[::2])
cb1.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cb1.ax.tick_params(labelsize=16)
cb1.outline.set_linewidth(0.8)
cax2 = fig.add_axes([0.55, 0.28, 0.34, 0.025])
cb2 = fig.colorbar(cf_far, cax=cax2, orientation='horizontal')
cb2.set_label('Out-degree (> 4,260 km)', fontsize=16)
cb2.set_ticks(levels_far[::2])
cb2.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cb2.ax.tick_params(labelsize=16)
cb2.outline.set_linewidth(0.8)
ax.text(0.01, 1, 'e', transform=ax.transAxes, fontsize=30, fontweight='bold', va='top')
plt.subplots_adjust(bottom=0.2)
plt.savefig('outputs/figures/figure_017.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from sklearn.neighbors import KernelDensity
from matplotlib import gridspec
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
distance_full = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lat_all[idx_nh]
lons = lon_all[idx_nh]
lons = (lons + 180) % 360 - 180
distance = distance_full[np.ix_(idx_nh, idx_nh)]
n_sub = len(lons)
lon_min, lon_max = (-110, -70)
lat_min, lat_max = (30, 50)
region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
region_idx = np.where(region_mask)[0]
print(f'目标区域节点数: {len(region_idx)}')
dist_th = 4260.0
dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
min_dist_to_region = dist_region_to_all.min(axis=0)
near_nodes = min_dist_to_region <= dist_th
far_nodes = ~near_nodes
print('近场节点数:', int(near_nodes.sum()), '远场节点数:', int(far_nodes.sum()))
influence_near = np.zeros(n_sub, dtype=np.int32)
influence_far = np.zeros(n_sub, dtype=np.int32)
endpoints_near = []
endpoints_far = []
for i in region_idx:
    for j in range(n_sub):
        if i == j:
            continue
        is_incoming = sig_edges[j, i] and tau_sub[j, i] > 0 or (sig_edges[i, j] and tau_sub[i, j] < 0)
        if not is_incoming:
            continue
        if near_nodes[j]:
            influence_near[j] += 1
            endpoints_near.append(j)
        else:
            influence_far[j] += 1
            endpoints_far.append(j)
endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
print('近场入度端点数 L_near =', len(endpoints_near))
print('远场入度端点数 L_far  =', len(endpoints_far))

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        print(k)
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)
sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=100, seed=1)
sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=100, seed=2)
print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
influence_near_sig = influence_near.copy()
influence_far_sig = influence_far.copy()
influence_near_sig[~sig_mask_near] = 0
influence_far_sig[~sig_mask_far] = 0
lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_near = Rbf(lons, lats, influence_near_sig.astype(float), function='linear', smooth=3)
rbf_far = Rbf(lons, lats, influence_far_sig.astype(float), function='linear', smooth=3)
influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(int)
influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(int)
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

def setup_ax(ax):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.4)
    gl.top_labels = False
    gl.right_labels = False
setup_ax(ax1)
vmax = int(np.nanmax(influence_interp_near))
levels = np.arange(0, max(vmax, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.set_title('Out-degree (< 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
setup_ax(ax2)
vmax1 = int(np.nanmax(influence_interp_far))
levels1 = np.arange(0, max(vmax1, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels1, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.set_title('Out-degree (> 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
for ax in (ax1, ax2):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 13}
    gl.ylabel_style = {'size': 13}
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, max(vmax_near, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels_near, cmap='Blues', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.text(-0.06, 1.15, 'k', transform=ax1.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax1.text(0.01, 1.11, 'In-degree (< 2500 km)', transform=ax1.transAxes, fontsize=13, va='top', ha='left')
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar1.outline.set_linewidth(0.4)
ticks1 = cbar1.get_ticks()
cbar1.set_ticks(ticks1[::2])
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, max(vmax_far, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels_far, cmap='Blues', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.text(-0.06, 1.15, 'l', transform=ax2.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax2.text(0.01, 1.11, 'In degree (> 2500 km)', transform=ax2.transAxes, fontsize=13, va='top', ha='left')
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar2.outline.set_linewidth(0.4)
ticks2 = cbar2.get_ticks()
cbar2.set_ticks(ticks2[::2])
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
import matplotlib as mpl
from cartopy.util import add_cyclic_point
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.linewidth'] = 0.8
fig = plt.figure(figsize=(12, 7), dpi=300)
proj = ccrs.PlateCarree(central_longitude=-120)
data_proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax.set_extent([-180, 180, -5, 90], crs=data_proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333', zorder=1)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 16}
gl.ylabel_style = {'size': 16}

def handle_cyclic_data(data, lon, lat):
    lon_1d = lon[0, :] if lon.ndim > 1 else lon
    lat_1d = lat[:, 0] if lat.ndim > 1 else lat
    cyclic_data, cyclic_lon = add_cyclic_point(data, coord=lon_1d)
    cyclic_lon2d, cyclic_lat2d = np.meshgrid(cyclic_lon, lat_1d)
    return (cyclic_data, cyclic_lon2d, cyclic_lat2d)
data_near_cyc, lon2d_cyc, lat2d_cyc = handle_cyclic_data(influence_interp_near, lon2d, lat2d)
data_far_cyc, _, _ = handle_cyclic_data(influence_interp_far, lon2d, lat2d)
data_near_masked = np.ma.masked_less(data_near_cyc, 0.1)
data_far_masked = np.ma.masked_less(data_far_cyc, 0.1)
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, vmax_near + 5, 5)
PuRd_mid = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p8', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
cf_near = ax.contourf(lon2d_cyc, lat2d_cyc, data_near_masked, levels=levels_near, cmap='YlOrRd', alpha=0.8, transform=data_proj, extend='both', zorder=2, antialiased=False, linewidths=0.2, edgecolor='face')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, vmax_far - 4, 2)
cf_far = ax.contourf(lon2d_cyc, lat2d_cyc, data_far_masked, levels=levels_far, cmap='PuBu', alpha=0.7, transform=data_proj, extend='both', zorder=3, antialiased=False, linewidths=0.2, edgecolor='face')
lon_min, lon_max = (-110, -70)
lat_min, lat_max = (30, 50)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax.plot(rect_lons, rect_lats, color='black', linewidth=1.5, transform=data_proj, zorder=10)
cax1 = fig.add_axes([0.15, 0.28, 0.34, 0.025])
cb1 = fig.colorbar(cf_near, cax=cax1, orientation='horizontal')
cb1.set_label('In-degree (< 4,260 km)', fontsize=16)
cb1.set_ticks(levels_near[::2])
cb1.ax.tick_params(labelsize=16)
cb1.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cax2 = fig.add_axes([0.55, 0.28, 0.34, 0.025])
cb2 = fig.colorbar(cf_far, cax=cax2, orientation='horizontal')
cb2.set_label('In-degree (> 4,260 km)', fontsize=16)
cb2.set_ticks(levels_far[::2])
cb2.ax.tick_params(labelsize=16)
cb2.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
ax.text(0.01, 0.99, 'f', transform=ax.transAxes, fontsize=30, fontweight='bold', va='top')
plt.subplots_adjust(bottom=0.2)
plt.savefig('outputs/figures/figure_018.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from sklearn.neighbors import KernelDensity
from matplotlib import gridspec
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
distance_full = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lat_all[idx_nh]
lons = lon_all[idx_nh]
lons = (lons + 180) % 360 - 180
distance = distance_full[np.ix_(idx_nh, idx_nh)]
n_sub = len(lons)
lon_min, lon_max = (20, 80)
lat_min, lat_max = (48, 67)
region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
region_idx = np.where(region_mask)[0]
print(f'目标区域节点数: {len(region_idx)}')
dist_th = 4260.0
dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
min_dist_to_region = dist_region_to_all.min(axis=0)
near_nodes = min_dist_to_region <= dist_th
far_nodes = ~near_nodes
print('近场节点数:', int(near_nodes.sum()), '远场节点数:', int(far_nodes.sum()))
influence_near = np.zeros(n_sub, dtype=np.int32)
influence_far = np.zeros(n_sub, dtype=np.int32)
endpoints_near = []
endpoints_far = []
for i in region_idx:
    for j in range(n_sub):
        if i == j:
            continue
        is_outgoing = sig_edges[i, j] and tau_sub[i, j] > 0 or (sig_edges[j, i] and tau_sub[j, i] < 0)
        if not is_outgoing:
            continue
        if near_nodes[j]:
            influence_near[j] += 1
            endpoints_near.append(j)
        else:
            influence_far[j] += 1
            endpoints_far.append(j)
endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
print('近场端点数 L_near =', len(endpoints_near))
print('远场端点数 L_far  =', len(endpoints_far))
np.save('regional_near_endpoints.npy', endpoints_near)
np.save('regional_far_endpoints.npy', endpoints_far)
print('endpoints 已保存：')
print('input_015.npy')
print('input_016.npy')

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        print(k)
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)
sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=100, seed=1)
sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=100, seed=2)
print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
influence_near_sig = influence_near.copy()
influence_far_sig = influence_far.copy()
influence_near_sig[~sig_mask_near] = 0
influence_far_sig[~sig_mask_far] = 0
lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_near = Rbf(lons, lats, influence_near_sig.astype(float), function='linear', smooth=3)
rbf_far = Rbf(lons, lats, influence_far_sig.astype(float), function='linear', smooth=3)
influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(int)
influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(int)
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

def setup_ax(ax):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.4)
    gl.top_labels = False
    gl.right_labels = False
setup_ax(ax1)
vmax = int(np.nanmax(influence_interp_near))
levels = np.arange(0, max(vmax, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.set_title('Out-degree (< 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
setup_ax(ax2)
vmax1 = int(np.nanmax(influence_interp_far))
levels1 = np.arange(0, max(vmax1, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels1, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.set_title('Out-degree (> 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
for ax in (ax1, ax2):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 13}
    gl.ylabel_style = {'size': 13}
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, max(vmax_near, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels_near, cmap='Reds', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.text(-0.06, 1.15, 'a', transform=ax1.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax1.text(0.01, 1.11, 'Out-degree (< 2500 km)', transform=ax1.transAxes, fontsize=13, va='top', ha='left')
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar1.outline.set_linewidth(0.4)
ticks1 = cbar1.get_ticks()
cbar1.set_ticks(ticks1[::2])
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, max(vmax_far, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels_far, cmap='Reds', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.text(-0.06, 1.15, 'b', transform=ax2.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax2.text(0.01, 1.11, 'Out degree (> 2500 km)', transform=ax2.transAxes, fontsize=13, va='top', ha='left')
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar2.outline.set_linewidth(0.4)
ticks2 = cbar2.get_ticks()
cbar2.set_ticks(ticks2[::2])
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.linewidth'] = 0.8
fig = plt.figure(figsize=(12, 7), dpi=300)
proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax.set_extent([-180, 180, -5, 90], crs=proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333', zorder=1)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 16}
gl.ylabel_style = {'size': 16}
data_near_masked = np.ma.masked_less(influence_interp_near, 0.1)
data_far_masked = np.ma.masked_less(influence_interp_far, 0.1)
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, vmax_near + 5, 5)
PuRd_mid = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p8', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
cf_near = ax.contourf(lon2d, lat2d, data_near_masked, levels=levels_near, cmap=PuRd_mid, alpha=0.8, transform=proj, extend='both', zorder=2, antialiased=True)
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, vmax_far + 2, 2)
cf_far = ax.contourf(lon2d, lat2d, data_far_masked, levels=levels_far, cmap='GnBu', alpha=0.7, transform=proj, extend='both', zorder=3, antialiased=True)
lon_min, lon_max = (20, 80)
lat_min, lat_max = (48, 67)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax.plot(rect_lons, rect_lats, color='black', linewidth=1.5, transform=proj, zorder=10)
cax1 = fig.add_axes([0.15, 0.28, 0.34, 0.025])
cb1 = fig.colorbar(cf_near, cax=cax1, orientation='horizontal')
cb1.set_label('Out-degree (< 4,260 km)', fontsize=16)
cb1.set_ticks(levels_near[::2])
cb1.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cb1.ax.tick_params(labelsize=16)
cb1.outline.set_linewidth(0.8)
cax2 = fig.add_axes([0.55, 0.28, 0.34, 0.025])
cb2 = fig.colorbar(cf_far, cax=cax2, orientation='horizontal')
cb2.set_label('Out-degree (> 4,260 km)', fontsize=16)
cb2.set_ticks(levels_far[::2])
cb2.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cb2.ax.tick_params(labelsize=16)
cb2.outline.set_linewidth(0.8)
ax.text(0.01, 1, 'a', transform=ax.transAxes, fontsize=30, fontweight='bold', va='top')
plt.subplots_adjust(bottom=0.2)
plt.savefig('outputs/figures/figure_019.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from sklearn.neighbors import KernelDensity
from matplotlib import gridspec
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
distance_full = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lat_all[idx_nh]
lons = lon_all[idx_nh]
lons = (lons + 180) % 360 - 180
distance = distance_full[np.ix_(idx_nh, idx_nh)]
n_sub = len(lons)
lon_min, lon_max = (20, 80)
lat_min, lat_max = (48, 67)
region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
region_idx = np.where(region_mask)[0]
print(f'目标区域节点数: {len(region_idx)}')
dist_th = 4260.0
dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
min_dist_to_region = dist_region_to_all.min(axis=0)
near_nodes = min_dist_to_region <= dist_th
far_nodes = ~near_nodes
print('近场节点数:', int(near_nodes.sum()), '远场节点数:', int(far_nodes.sum()))
influence_near = np.zeros(n_sub, dtype=np.int32)
influence_far = np.zeros(n_sub, dtype=np.int32)
endpoints_near = []
endpoints_far = []
for i in region_idx:
    for j in range(n_sub):
        if i == j:
            continue
        is_incoming = sig_edges[j, i] and tau_sub[j, i] > 0 or (sig_edges[i, j] and tau_sub[i, j] < 0)
        if not is_incoming:
            continue
        if near_nodes[j]:
            influence_near[j] += 1
            endpoints_near.append(j)
        else:
            influence_far[j] += 1
            endpoints_far.append(j)
endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
print('近场入度端点数 L_near =', len(endpoints_near))
print('远场入度端点数 L_far  =', len(endpoints_far))

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        print(k)
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)
sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=100, seed=1)
sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=100, seed=2)
print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
influence_near_sig = influence_near.copy()
influence_far_sig = influence_far.copy()
influence_near_sig[~sig_mask_near] = 0
influence_far_sig[~sig_mask_far] = 0
lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_near = Rbf(lons, lats, influence_near_sig.astype(float), function='linear', smooth=3)
rbf_far = Rbf(lons, lats, influence_far_sig.astype(float), function='linear', smooth=3)
influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(int)
influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(int)
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

def setup_ax(ax):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.4)
    gl.top_labels = False
    gl.right_labels = False
setup_ax(ax1)
vmax = int(np.nanmax(influence_interp_near))
levels = np.arange(0, max(vmax, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.set_title('Out-degree (< 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
setup_ax(ax2)
vmax1 = int(np.nanmax(influence_interp_far))
levels1 = np.arange(0, max(vmax1, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels1, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.set_title('Out-degree (> 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
for ax in (ax1, ax2):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 13}
    gl.ylabel_style = {'size': 13}
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, max(vmax_near, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels_near, cmap='Blues', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.text(-0.06, 1.15, 'c', transform=ax1.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax1.text(0.01, 1.11, 'In-degree (< 2500 km)', transform=ax1.transAxes, fontsize=13, va='top', ha='left')
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar1.outline.set_linewidth(0.4)
ticks1 = cbar1.get_ticks()
cbar1.set_ticks(ticks1[::2])
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, max(vmax_far, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels_far, cmap='Blues', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.text(-0.06, 1.15, 'd', transform=ax2.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax2.text(0.01, 1.11, 'In degree (> 2500 km)', transform=ax2.transAxes, fontsize=13, va='top', ha='left')
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar2.outline.set_linewidth(0.4)
ticks2 = cbar2.get_ticks()
cbar2.set_ticks(ticks2[::2])
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
import matplotlib as mpl
from cartopy.util import add_cyclic_point
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.linewidth'] = 0.8
fig = plt.figure(figsize=(12, 7), dpi=300)
proj = ccrs.PlateCarree()
data_proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax.set_extent([-180, 180, -5, 90], crs=data_proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333', zorder=1)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 16}
gl.ylabel_style = {'size': 16}

def handle_cyclic_data(data, lon, lat):
    lon_1d = lon[0, :] if lon.ndim > 1 else lon
    lat_1d = lat[:, 0] if lat.ndim > 1 else lat
    cyclic_data, cyclic_lon = add_cyclic_point(data, coord=lon_1d)
    cyclic_lon2d, cyclic_lat2d = np.meshgrid(cyclic_lon, lat_1d)
    return (cyclic_data, cyclic_lon2d, cyclic_lat2d)
data_near_cyc, lon2d_cyc, lat2d_cyc = handle_cyclic_data(influence_interp_near, lon2d, lat2d)
data_far_cyc, _, _ = handle_cyclic_data(influence_interp_far, lon2d, lat2d)
data_near_masked = np.ma.masked_less(data_near_cyc, 0.1)
data_far_masked = np.ma.masked_less(data_far_cyc, 0.1)
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, vmax_near + 5, 4)
PuRd_mid = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p8', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
cf_near = ax.contourf(lon2d_cyc, lat2d_cyc, data_near_masked, levels=levels_near, cmap='YlOrRd', alpha=0.8, transform=data_proj, extend='both', zorder=2, antialiased=False, linewidths=0.2, edgecolor='face')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, vmax_far, 1)
cf_far = ax.contourf(lon2d_cyc, lat2d_cyc, data_far_masked, levels=levels_far, cmap='PuBu', alpha=0.7, transform=data_proj, extend='both', zorder=3, antialiased=False, linewidths=0.2, edgecolor='face')
lon_min, lon_max = (20, 80)
lat_min, lat_max = (48, 67)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax.plot(rect_lons, rect_lats, color='black', linewidth=1.5, transform=data_proj, zorder=10)
cax1 = fig.add_axes([0.15, 0.28, 0.34, 0.025])
cb1 = fig.colorbar(cf_near, cax=cax1, orientation='horizontal')
cb1.set_label('In-degree (< 4,260 km)', fontsize=16)
cb1.set_ticks(levels_near[::2])
cb1.ax.tick_params(labelsize=16)
cb1.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cax2 = fig.add_axes([0.55, 0.28, 0.34, 0.025])
cb2 = fig.colorbar(cf_far, cax=cax2, orientation='horizontal')
cb2.set_label('In-degree (> 4,260 km)', fontsize=16)
cb2.set_ticks(levels_far[::2])
cb2.ax.tick_params(labelsize=16)
cb2.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
ax.text(0.01, 0.99, 'b', transform=ax.transAxes, fontsize=30, fontweight='bold', va='top')
plt.subplots_adjust(bottom=0.2)
plt.savefig('outputs/figures/figure_020.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from sklearn.neighbors import KernelDensity
from matplotlib import gridspec
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
distance_full = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lat_all[idx_nh]
lons = lon_all[idx_nh]
lons = (lons + 180) % 360 - 180
distance = distance_full[np.ix_(idx_nh, idx_nh)]
n_sub = len(lons)
lon_min, lon_max = (95, 120)
lat_min, lat_max = (20, 40)
region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
region_idx = np.where(region_mask)[0]
print(f'目标区域节点数: {len(region_idx)}')
dist_th = 4260.0
dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
min_dist_to_region = dist_region_to_all.min(axis=0)
near_nodes = min_dist_to_region <= dist_th
far_nodes = ~near_nodes
print('近场节点数:', int(near_nodes.sum()), '远场节点数:', int(far_nodes.sum()))
influence_near = np.zeros(n_sub, dtype=np.int32)
influence_far = np.zeros(n_sub, dtype=np.int32)
endpoints_near = []
endpoints_far = []
for i in region_idx:
    for j in range(n_sub):
        if i == j:
            continue
        is_outgoing = sig_edges[i, j] and tau_sub[i, j] > 0 or (sig_edges[j, i] and tau_sub[j, i] < 0)
        if not is_outgoing:
            continue
        if near_nodes[j]:
            influence_near[j] += 1
            endpoints_near.append(j)
        else:
            influence_far[j] += 1
            endpoints_far.append(j)
endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
print('近场端点数 L_near =', len(endpoints_near))
print('远场端点数 L_far  =', len(endpoints_far))
np.save('regional_near_endpoints.npy', endpoints_near)
np.save('regional_far_endpoints.npy', endpoints_far)
print('endpoints 已保存：')
print('input_015.npy')
print('input_016.npy')

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        print(k)
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)
sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=100, seed=1)
sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=100, seed=2)
print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
influence_near_sig = influence_near.copy()
influence_far_sig = influence_far.copy()
influence_near_sig[~sig_mask_near] = 0
influence_far_sig[~sig_mask_far] = 0
lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_near = Rbf(lons, lats, influence_near_sig.astype(float), function='linear', smooth=3)
rbf_far = Rbf(lons, lats, influence_far_sig.astype(float), function='linear', smooth=3)
influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(int)
influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(int)
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

def setup_ax(ax):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.4)
    gl.top_labels = False
    gl.right_labels = False
setup_ax(ax1)
vmax = int(np.nanmax(influence_interp_near))
levels = np.arange(0, max(vmax, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.set_title('Out-degree (< 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
setup_ax(ax2)
vmax1 = int(np.nanmax(influence_interp_far))
levels1 = np.arange(0, max(vmax1, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels1, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.set_title('Out-degree (> 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
for ax in (ax1, ax2):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 13}
    gl.ylabel_style = {'size': 13}
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, max(vmax_near, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels_near, cmap='Reds', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.text(-0.06, 1.15, 'e', transform=ax1.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax1.text(0.01, 1.11, 'Out-degree (< 2500 km)', transform=ax1.transAxes, fontsize=13, va='top', ha='left')
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar1.outline.set_linewidth(0.4)
ticks1 = cbar1.get_ticks()
cbar1.set_ticks(ticks1[::2])
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, max(vmax_far, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels_far, cmap='Reds', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.text(-0.06, 1.15, 'f', transform=ax2.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax2.text(0.01, 1.11, 'Out degree (> 2500 km)', transform=ax2.transAxes, fontsize=13, va='top', ha='left')
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar2.outline.set_linewidth(0.4)
ticks2 = cbar2.get_ticks()
cbar2.set_ticks(ticks2[::2])
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.linewidth'] = 0.8
fig = plt.figure(figsize=(12, 7), dpi=300)
proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax.set_extent([-180, 180, -5, 90], crs=proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333', zorder=1)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 16}
gl.ylabel_style = {'size': 16}
data_near_masked = np.ma.masked_less(influence_interp_near, 0.1)
data_far_masked = np.ma.masked_less(influence_interp_far, 0.1)
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, vmax_near + 5, 5)
PuRd_mid = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p8', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
cf_near = ax.contourf(lon2d, lat2d, data_near_masked, levels=levels_near, cmap=PuRd_mid, alpha=0.8, transform=proj, extend='both', zorder=2, antialiased=True)
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, vmax_far + 2, 2)
cf_far = ax.contourf(lon2d, lat2d, data_far_masked, levels=levels_far, cmap='GnBu', alpha=0.7, transform=proj, extend='both', zorder=3, antialiased=True)
lon_min, lon_max = (95, 120)
lat_min, lat_max = (20, 40)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax.plot(rect_lons, rect_lats, color='black', linewidth=1.5, transform=proj, zorder=10)
cax1 = fig.add_axes([0.15, 0.28, 0.34, 0.025])
cb1 = fig.colorbar(cf_near, cax=cax1, orientation='horizontal')
cb1.set_label('Out-degree (< 4,260 km)', fontsize=16)
cb1.set_ticks(levels_near[::2])
cb1.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cb1.ax.tick_params(labelsize=16)
cb1.outline.set_linewidth(0.8)
cax2 = fig.add_axes([0.55, 0.28, 0.34, 0.025])
cb2 = fig.colorbar(cf_far, cax=cax2, orientation='horizontal')
cb2.set_label('Out-degree (> 4,260 km)', fontsize=16)
cb2.set_ticks(levels_far[::2])
cb2.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cb2.ax.tick_params(labelsize=16)
cb2.outline.set_linewidth(0.8)
ax.text(0.01, 1, 'c', transform=ax.transAxes, fontsize=30, fontweight='bold', va='top')
plt.subplots_adjust(bottom=0.2)
plt.savefig('outputs/figures/figure_021.jpg', dpi=300, bbox_inches='tight')
plt.show()
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from sklearn.neighbors import KernelDensity
from matplotlib import gridspec
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
distance_full = np.load('data/pairwise_distances.npy')
lat_all = np.load('data/node_latitudes.npy')
lon_all = np.load('data/node_longitudes.npy')
mask_nh = (lat_all >= -5) & (lat_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lat_all[idx_nh]
lons = lon_all[idx_nh]
lons = (lons + 180) % 360 - 180
distance = distance_full[np.ix_(idx_nh, idx_nh)]
n_sub = len(lons)
lon_min, lon_max = (95, 120)
lat_min, lat_max = (20, 40)
region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
region_idx = np.where(region_mask)[0]
print(f'目标区域节点数: {len(region_idx)}')
dist_th = 4260.0
dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
min_dist_to_region = dist_region_to_all.min(axis=0)
near_nodes = min_dist_to_region <= dist_th
far_nodes = ~near_nodes
print('近场节点数:', int(near_nodes.sum()), '远场节点数:', int(far_nodes.sum()))
influence_near = np.zeros(n_sub, dtype=np.int32)
influence_far = np.zeros(n_sub, dtype=np.int32)
endpoints_near = []
endpoints_far = []
for i in region_idx:
    for j in range(n_sub):
        if i == j:
            continue
        is_incoming = sig_edges[j, i] and tau_sub[j, i] > 0 or (sig_edges[i, j] and tau_sub[i, j] < 0)
        if not is_incoming:
            continue
        if near_nodes[j]:
            influence_near[j] += 1
            endpoints_near.append(j)
        else:
            influence_far[j] += 1
            endpoints_far.append(j)
endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
print('近场入度端点数 L_near =', len(endpoints_near))
print('远场入度端点数 L_far  =', len(endpoints_far))

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        print(k)
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)
sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=100, seed=1)
sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=100, seed=2)
print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
influence_near_sig = influence_near.copy()
influence_far_sig = influence_far.copy()
influence_near_sig[~sig_mask_near] = 0
influence_far_sig[~sig_mask_far] = 0
lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
rbf_near = Rbf(lons, lats, influence_near_sig.astype(float), function='linear', smooth=3)
rbf_far = Rbf(lons, lats, influence_far_sig.astype(float), function='linear', smooth=3)
influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(int)
influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(int)
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]

def setup_ax(ax):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', alpha=0.4)
    gl.top_labels = False
    gl.right_labels = False
setup_ax(ax1)
vmax = int(np.nanmax(influence_interp_near))
levels = np.arange(0, max(vmax, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.set_title('Out-degree (< 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
setup_ax(ax2)
vmax1 = int(np.nanmax(influence_interp_far))
levels1 = np.arange(0, max(vmax1, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels1, cmap='Oranges', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.set_title('Out-degree (> 2500 km, KDE bias-corrected, P<0.001)', fontsize=11)
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.yaxis.set_major_locator(MaxNLocator(integer=True))
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
fig = plt.figure(figsize=(8, 6), dpi=200)
proj = ccrs.PlateCarree()
gs = gridspec.GridSpec(2, 1, hspace=0.06)
ax1 = fig.add_subplot(gs[0, 0], projection=proj)
ax2 = fig.add_subplot(gs[1, 0], projection=proj)
ax1._autoscaleXon = getattr(ax1, '_autoscaleXon', True)
ax1._autoscaleYon = getattr(ax1, '_autoscaleYon', True)
ax2._autoscaleXon = getattr(ax2, '_autoscaleXon', True)
ax2._autoscaleYon = getattr(ax2, '_autoscaleYon', True)
for ax in (ax1, ax2):
    ax.set_extent([-180, 180, -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=0.4)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.5, alpha=0.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': 13}
    gl.ylabel_style = {'size': 13}
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, max(vmax_near, 1) + 1, 5)
cf1 = ax1.contourf(lon2d, lat2d, influence_interp_near, levels=levels_near, cmap='Blues', extend='both', transform=proj, alpha=0.9)
ax1.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax1.text(-0.06, 1.15, 'g', transform=ax1.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax1.text(0.01, 1.11, 'In-degree (< 2500 km)', transform=ax1.transAxes, fontsize=13, va='top', ha='left')
cax1 = inset_axes(ax1, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax1.transAxes, borderpad=0)
cbar1 = fig.colorbar(cf1, cax=cax1, orientation='vertical')
cbar1.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar1.outline.set_linewidth(0.4)
ticks1 = cbar1.get_ticks()
cbar1.set_ticks(ticks1[::2])
cax1.yaxis.set_ticks_position('right')
cax1.yaxis.set_label_position('right')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, max(vmax_far, 1) + 1, 2)
cf2 = ax2.contourf(lon2d, lat2d, influence_interp_far, levels=levels_far, cmap='Blues', extend='both', transform=proj, alpha=0.9)
ax2.plot(rect_lons, rect_lats, color='black', lw=2.0, transform=proj, zorder=6)
ax2.text(-0.06, 1.15, 'h', transform=ax2.transAxes, fontsize=22, fontweight='bold', va='top', ha='left')
ax2.text(0.01, 1.11, 'In degree (> 2500 km)', transform=ax2.transAxes, fontsize=13, va='top', ha='left')
cax2 = inset_axes(ax2, width='3%', height='60%', loc='center left', bbox_to_anchor=(1.02, -0.3, 1, 1.6), bbox_transform=ax2.transAxes, borderpad=0)
cbar2 = fig.colorbar(cf2, cax=cax2, orientation='vertical')
cbar2.ax.tick_params(labelsize=13, width=1.0, length=4)
cbar2.outline.set_linewidth(0.4)
ticks2 = cbar2.get_ticks()
cbar2.set_ticks(ticks2[::2])
cax2.yaxis.set_ticks_position('right')
cax2.yaxis.set_label_position('right')
plt.show()
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import numpy as np
import matplotlib as mpl
from cartopy.util import add_cyclic_point
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.linewidth'] = 0.8
fig = plt.figure(figsize=(12, 7), dpi=300)
proj = ccrs.PlateCarree()
data_proj = ccrs.PlateCarree()
ax = fig.add_subplot(1, 1, 1, projection=proj)
ax.set_extent([-180, 180, -5, 90], crs=data_proj)
ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
ax.add_feature(cfeature.COASTLINE, linewidth=0.4, color='#333333', zorder=1)
gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=0.3, color='gray', alpha=0.3)
gl.top_labels = False
gl.right_labels = False
gl.xlabel_style = {'size': 16}
gl.ylabel_style = {'size': 16}

def handle_cyclic_data(data, lon, lat):
    lon_1d = lon[0, :] if lon.ndim > 1 else lon
    lat_1d = lat[:, 0] if lat.ndim > 1 else lat
    cyclic_data, cyclic_lon = add_cyclic_point(data, coord=lon_1d)
    cyclic_lon2d, cyclic_lat2d = np.meshgrid(cyclic_lon, lat_1d)
    return (cyclic_data, cyclic_lon2d, cyclic_lat2d)
data_near_cyc, lon2d_cyc, lat2d_cyc = handle_cyclic_data(influence_interp_near, lon2d, lat2d)
data_far_cyc, _, _ = handle_cyclic_data(influence_interp_far, lon2d, lat2d)
data_near_masked = np.ma.masked_less(data_near_cyc, 0.1)
data_far_masked = np.ma.masked_less(data_far_cyc, 0.1)
vmax_near = int(np.nanmax(influence_interp_near))
levels_near = np.arange(0, vmax_near - 5, 4)
PuRd_mid = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p8', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
cf_near = ax.contourf(lon2d_cyc, lat2d_cyc, data_near_masked, levels=levels_near, cmap='YlOrRd', alpha=0.8, transform=data_proj, extend='both', zorder=2, antialiased=False, linewidths=0.2, edgecolor='face')
vmax_far = int(np.nanmax(influence_interp_far))
levels_far = np.arange(0, vmax_far, 1)
cf_far = ax.contourf(lon2d_cyc, lat2d_cyc, data_far_masked, levels=levels_far, cmap='PuBu', alpha=0.7, transform=data_proj, extend='both', zorder=3, antialiased=False, linewidths=0.2, edgecolor='face')
lon_min, lon_max = (95, 120)
lat_min, lat_max = (20, 40)
rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
ax.plot(rect_lons, rect_lats, color='black', linewidth=1.5, transform=data_proj, zorder=10)
cax1 = fig.add_axes([0.15, 0.28, 0.34, 0.025])
cb1 = fig.colorbar(cf_near, cax=cax1, orientation='horizontal')
cb1.set_label('In-degree (< 4,260 km)', fontsize=16)
cb1.set_ticks(levels_near[::2])
cb1.ax.tick_params(labelsize=16)
cb1.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
cax2 = fig.add_axes([0.55, 0.28, 0.34, 0.025])
cb2 = fig.colorbar(cf_far, cax=cax2, orientation='horizontal')
cb2.set_label('In-degree (> 4,260 km)', fontsize=16)
cb2.set_ticks(levels_far[::2])
cb2.ax.tick_params(labelsize=16)
cb2.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))
ax.text(0.01, 0.99, 'd', transform=ax.transAxes, fontsize=30, fontweight='bold', va='top')
plt.subplots_adjust(bottom=0.2)
plt.savefig('outputs/figures/figure_022.jpg', dpi=300, bbox_inches='tight')
plt.show()
