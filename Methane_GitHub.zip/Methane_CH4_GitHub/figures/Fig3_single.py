import os
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from scipy.stats import gaussian_kde
from sklearn.neighbors import KernelDensity
from cartopy.util import add_cyclic_point
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.cm import ScalarMappable
BASE_PATH = 'data/'
NETWORK_PATH = 'data/network/working/'
SHUFFLE_PATH = NETWORK_PATH
W_POS_FILE = os.path.join(NETWORK_PATH, 'positive_link_weights.npy')
TAU_POS_FILE = os.path.join(NETWORK_PATH, 'positive_link_lags.npy')
SHUFFLE_W_POS_FILE = os.path.join(SHUFFLE_PATH, 'surrogate_positive_weights.npy')
DISTANCE_FILE = os.path.join(BASE_PATH, 'pairwise_distances.npy')
LAT_FILE = os.path.join(BASE_PATH, 'node_latitudes.npy')
LON_FILE = os.path.join(BASE_PATH, 'node_longitudes.npy')
OUT_FIG = 'outputs/figures/figure_005.jpg'
OUT_FIG_PDF = 'outputs/figures/figure_006.pdf'
OUT_TABLE = 'outputs/link_lag_summary.csv'
SAVE_RESULTS = True
SHUFFLE_EDGE_PERCENTILE = 99.5
DIST_TH_KM = 4260.0
KDE_N_ITER = 1
KDE_P = 0.001
KDE_MIN_BW = 0.05
USE_EXTRA_W_FILTER = False
EXTRA_W_PERCENTILE = 90.0
USE_HIGH_DEGREE_NODE_FILTER = False
DEGREE_TOP_PERCENT = 10.0
USE_ABS_TAU = True
MAX_SCATTER_POINTS_PER_BOX = 500
NORMALIZE_DENSITY_WITHIN_GROUP = True
FIG_WIDTH = 9.2
FIG_HEIGHT = 8.4
FIG_DPI = 300
SAVE_DPI = 600
RECT_A = [0.07, 0.795, 0.41, 0.112]
RECT_B = [0.53, 0.795, 0.41, 0.112]
RECT_C = [0.07, 0.645, 0.41, 0.112]
RECT_D = [0.53, 0.645, 0.41, 0.112]
RECT_E = [0.07, 0.495, 0.41, 0.112]
RECT_F = [0.53, 0.495, 0.41, 0.112]
CBAR_OUT_NEAR_POS = [0.09, 0.445, 0.16, 0.012]
CBAR_OUT_FAR_POS = [0.28, 0.445, 0.16, 0.012]
CBAR_IN_NEAR_POS = [0.56, 0.445, 0.16, 0.012]
CBAR_IN_FAR_POS = [0.75, 0.445, 0.16, 0.012]
RECT_G = [0.1, 0.213, 0.83, 0.175]
SHOW_G_DENSITY_COLORBAR = True
G_CBAR_SHORT_POS = [0.18, 0.147, 0.28, 0.01]
G_CBAR_LONG_POS = [0.585, 0.147, 0.28, 0.01]
MAP_LON_TICKS = [-180, -120, -60, 0, 60, 120, 180]
MAP_LAT_TICKS = [0, 35, 70]
FONT_SCALE = 1.11
FONT_SCALE1 = 1.15
FS_BASE = 10 * FONT_SCALE
FS_PANEL_MAP = 16 * FONT_SCALE1
FS_PANEL_G = 16 * FONT_SCALE1
FS_MAP_TITLE = 12 * FONT_SCALE
FS_MAP_TICK = 12 * FONT_SCALE
FS_MAP_CBAR_LABEL = 12 * FONT_SCALE
FS_MAP_CBAR_TICK = 12 * FONT_SCALE
FS_G_XTICK = 12 * FONT_SCALE
FS_G_YTICK = 12 * FONT_SCALE
FS_G_YLABEL = 12 * FONT_SCALE
FS_G_MEAN_TEXT = 12 * FONT_SCALE
FS_G_CBAR_LABEL = 12 * FONT_SCALE
FS_G_CBAR_TICK = 12 * FONT_SCALE
LW_AXIS = 0.75
LW_COAST = 0.32
LW_GRID = 0.26
LW_REGION_BOX = 1.05
LW_CBAR_OUTLINE = 0.55
LW_G_BOX = 1.2
LW_G_WHISKER = 0.75
LW_G_CAP = 0.75
LW_G_MEAN = 1.3
LW_G_MEAN_CIRCLE = 0.95
LW_G_SCATTER_EDGE = 0.08
MAP_ALPHA_NEAR = 0.8
MAP_ALPHA_FAR = 0.8
MAP_NEAR_THRESH = 0.005
MAP_FAR_THRESH = 0.005
S_G_DENSITY_POINT = 4
S_G_MEAN_CIRCLE = 34
G_DENSITY_POINT_ALPHA = 0.9
G_DENSITY_JITTER_SCALE = 0.045
G_REGION_GAP = 2.8
G_DIR_GAP = 1.15
G_BOX_OFFSET = 0.23
G_BOX_WIDTH = 0.3
G_X_MARGIN = 0.45
G_MEAN_TEXT_XSHIFT = 0.25
COLOR_SHORT = '#E67E22'
COLOR_LONG = '#138D75'
COLOR_AXIS = '#222222'
COLOR_WHISKER = '#4A4A4A'
COLOR_SCATTER_EDGE = '#666666'
COLOR_REGION_BOX = '#999999'
CMAP_OUT_NEAR = mpl.colors.LinearSegmentedColormap.from_list('PuRd_0p2_0p85', mpl.cm.PuRd(np.linspace(0, 0.8, 256)))
CMAP_OUT_FAR = mpl.colors.LinearSegmentedColormap.from_list('GnBu_0p20_0p90', mpl.cm.GnBu(np.linspace(0, 1, 256)))
CMAP_IN_NEAR = mpl.colors.LinearSegmentedColormap.from_list('YlOrRd_0p15_0p90', mpl.cm.YlOrRd(np.linspace(0, 0.9, 256)))
CMAP_IN_FAR = mpl.colors.LinearSegmentedColormap.from_list('PuBu_0p20_0p90', mpl.cm.PuBu(np.linspace(0, 1, 256)))
CMAP_G_SHORT_DENSITY = LinearSegmentedColormap.from_list('short_white_to_orange', ['#FFFFFF', '#FFF3E0', '#F8C471', '#E67E22', '#A04000'])
CMAP_G_LONG_DENSITY = LinearSegmentedColormap.from_list('long_white_to_teal', ['#FFFFFF', '#E8F8F5', '#A3E4D7', '#16A085', '#0B5345'])
LEVELS_OUT_NEAR = np.linspace(0.0, 0.2, 11)
LEVELS_OUT_FAR = np.linspace(0.0, 0.08, 11)
LEVELS_IN_NEAR = np.linspace(0.0, 0.2, 11)
LEVELS_IN_FAR_BY_REGION = {'North America': np.linspace(0.0, 0.06, 11), 'Europe': np.linspace(0.0, 0.05, 11), 'East Asia': np.linspace(0.0, 0.05, 11)}
REGIONS = {'North America': {'lon_min': -110, 'lon_max': -70, 'lat_min': 25, 'lat_max': 55, 'norm': 221.0}, 'Europe': {'lon_min': 20, 'lon_max': 80, 'lat_min': 48, 'lat_max': 67, 'norm': 175.0}, 'East Asia': {'lon_min': 95, 'lon_max': 130, 'lat_min': 20, 'lat_max': 50, 'norm': 195.0}}
mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial'], 'font.size': FS_BASE, 'axes.linewidth': LW_AXIS, 'xtick.direction': 'out', 'ytick.direction': 'out', 'xtick.major.width': LW_AXIS, 'ytick.major.width': LW_AXIS, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})
print('\n=====================================================')
print('读取网络数据')
print('=====================================================')
W_pos1 = np.load(W_POS_FILE)
tau_pos1 = np.load(TAU_POS_FILE)
W_pos_all = np.load(SHUFFLE_W_POS_FILE)
distance_full = np.load(DISTANCE_FILE)
lats_all = np.load(LAT_FILE)
lons_all = np.load(LON_FILE)
lons_all = (lons_all + 180) % 360 - 180
print('W_pos1 shape:', W_pos1.shape)
print('tau_pos1 shape:', tau_pos1.shape)
print('W_pos_all shape:', W_pos_all.shape)
print('distance shape:', distance_full.shape)
print('node number:', len(lats_all))
mask_nh = (lats_all >= -5) & (lats_all <= 90)
idx_nh = np.where(mask_nh)[0]
lats = lats_all[idx_nh]
lons = lons_all[idx_nh]
n_sub = len(idx_nh)
print('\n北半球节点数:', n_sub)
W_pos_sub = W_pos1[np.ix_(idx_nh, idx_nh)]
tau_sub = tau_pos1[np.ix_(idx_nh, idx_nh)]
distance = distance_full[np.ix_(idx_nh, idx_nh)]
shuffle_pos_mean_sub = W_pos_all.mean(axis=0)[np.ix_(idx_nh, idx_nh)]
tri_u = np.triu_indices(n_sub, k=1)
shuffle_pos_flat = shuffle_pos_mean_sub[tri_u]
shuffle_pos_flat = shuffle_pos_flat[np.isfinite(shuffle_pos_flat)]
W_pos_thr = np.percentile(shuffle_pos_flat, SHUFFLE_EDGE_PERCENTILE)
sig_edges = np.isfinite(W_pos_sub) & np.isfinite(tau_sub) & (W_pos_sub > W_pos_thr) & ~np.eye(n_sub, dtype=bool)
print('\n=====================================================')
print('显著边阈值')
print('=====================================================')
print('SHUFFLE_EDGE_PERCENTILE =', SHUFFLE_EDGE_PERCENTILE)
print('W_pos_thr =', W_pos_thr)
print('sig_edges matrix True count =', int(np.sum(sig_edges)))
n_sig_matrix_entries = int(np.sum(sig_edges))
sig_pair_matrix = sig_edges | sig_edges.T
n_sig_unique_pairs = int(np.sum(sig_pair_matrix[tri_u]))
n_sig_valid_tau_pairs = 0
n_sig_tau_positive = 0
n_sig_tau_negative = 0
n_sig_tau_zero_or_nan = 0
for i in range(n_sub):
    for j in range(i + 1, n_sub):
        if sig_edges[i, j]:
            tau_ij = tau_sub[i, j]
            if np.isfinite(tau_ij) and tau_ij != 0:
                n_sig_valid_tau_pairs += 1
                if tau_ij > 0:
                    n_sig_tau_positive += 1
                elif tau_ij < 0:
                    n_sig_tau_negative += 1
            else:
                n_sig_tau_zero_or_nan += 1
        elif sig_edges[j, i]:
            tau_ji = tau_sub[j, i]
            if np.isfinite(tau_ji) and tau_ji != 0:
                n_sig_valid_tau_pairs += 1
                if tau_ji > 0:
                    n_sig_tau_positive += 1
                elif tau_ji < 0:
                    n_sig_tau_negative += 1
            else:
                n_sig_tau_zero_or_nan += 1
print('\n=====================================================')
print('显著边数量统计')
print('=====================================================')
print('sig_edges matrix True count        :', n_sig_matrix_entries)
print('unique significant node-pair count :', n_sig_unique_pairs)
print('valid directed significant edges   :', n_sig_valid_tau_pairs)
print('tau > 0 significant edges          :', n_sig_tau_positive)
print('tau < 0 significant edges          :', n_sig_tau_negative)
print('tau = 0 or NaN significant pairs   :', n_sig_tau_zero_or_nan)
if USE_EXTRA_W_FILTER:
    w_sig = W_pos_sub[sig_edges]
    w_sig = w_sig[np.isfinite(w_sig)]
    if len(w_sig) == 0:
        raise ValueError('没有显著边，无法计算额外边强度阈值。')
    EXTRA_W_THRESHOLD = np.percentile(w_sig, EXTRA_W_PERCENTILE)
else:
    EXTRA_W_THRESHOLD = -np.inf
print('\n=====================================================')
print('额外边强度筛选')
print('=====================================================')
print('USE_EXTRA_W_FILTER =', USE_EXTRA_W_FILTER)
print('EXTRA_W_PERCENTILE =', EXTRA_W_PERCENTILE)
print('EXTRA_W_THRESHOLD =', EXTRA_W_THRESHOLD)

def compute_directed_degree_from_sig_edges(sig_edges, tau_sub):
    out_degree = np.zeros(n_sub, dtype=float)
    in_degree = np.zeros(n_sub, dtype=float)
    for i in range(n_sub):
        for j in range(i + 1, n_sub):
            if sig_edges[i, j]:
                tau_ij = tau_sub[i, j]
                if tau_ij > 0:
                    out_degree[i] += 1
                    in_degree[j] += 1
                elif tau_ij < 0:
                    out_degree[j] += 1
                    in_degree[i] += 1
            elif sig_edges[j, i]:
                tau_ji = tau_sub[j, i]
                if tau_ji > 0:
                    out_degree[j] += 1
                    in_degree[i] += 1
                elif tau_ji < 0:
                    out_degree[i] += 1
                    in_degree[j] += 1
    total_degree = out_degree + in_degree
    return (out_degree, in_degree, total_degree)
out_degree, in_degree, total_degree = compute_directed_degree_from_sig_edges(sig_edges, tau_sub)
if USE_HIGH_DEGREE_NODE_FILTER:
    valid_deg = np.isfinite(total_degree)
    degree_thr = np.percentile(total_degree[valid_deg], 100 - DEGREE_TOP_PERCENT)
    high_degree_mask = np.isfinite(total_degree) & (total_degree >= degree_thr)
else:
    degree_thr = -np.inf
    high_degree_mask = np.ones(n_sub, dtype=bool)
print('\n=====================================================')
print('High-degree 节点筛选')
print('=====================================================')
print('USE_HIGH_DEGREE_NODE_FILTER =', USE_HIGH_DEGREE_NODE_FILTER)
print('DEGREE_TOP_PERCENT =', DEGREE_TOP_PERCENT)
print('degree_thr =', degree_thr)
print('high-degree node count =', int(np.sum(high_degree_mask)))

def spherical_kde_sigmask(endpoints, lats_deg, lons_deg, n_iter=100, p=0.001, seed=0, min_bw=0.05):
    n = len(lats_deg)
    L = len(endpoints)
    if L == 0:
        return (np.zeros(n, dtype=bool), np.zeros(n), np.zeros(n))
    rng = np.random.default_rng(seed)
    xy = np.vstack([lats_deg, lons_deg]).T * np.pi / 180.0
    values_obs = np.vstack([lats_deg[endpoints], lons_deg[endpoints]]).T * np.pi / 180.0
    bw = 0.5 * L ** (-1.0 / 6.0)
    bw = max(bw, min_bw)
    print(f'[KDE] L={L}, bw={bw:.4f} rad (~{bw * 6371:.0f} km), n_iter={n_iter}')
    kde = KernelDensity(bandwidth=bw, metric='haversine', kernel='gaussian', algorithm='ball_tree')
    kde.fit(values_obs)
    rho_obs = np.exp(kde.score_samples(xy))
    rho_null = np.empty((n_iter, n), dtype=np.float32)
    for k in range(n_iter):
        rand_idx = rng.integers(0, n, size=L)
        values_rand = xy[rand_idx]
        kde.fit(values_rand)
        rho_null[k] = np.exp(kde.score_samples(xy))
        if (k + 1) % 200 == 0:
            print(f'  null {k + 1}/{n_iter} done')
    thr = np.quantile(rho_null, 1 - p, axis=0)
    sig_mask = rho_obs > thr
    return (sig_mask, rho_obs, thr)

def compute_region_propagation_fields(region_name, region_info, direction, seed_base=0):
    lon_min = region_info['lon_min']
    lon_max = region_info['lon_max']
    lat_min = region_info['lat_min']
    lat_max = region_info['lat_max']
    norm_factor = region_info['norm']
    region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
    region_idx = np.where(region_mask)[0]
    if len(region_idx) == 0:
        raise ValueError(f'{region_name} 区域没有节点，请检查经纬度范围。')
    dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
    min_dist_to_region = np.nanmin(dist_region_to_all, axis=0)
    near_nodes = min_dist_to_region <= DIST_TH_KM
    far_nodes = ~near_nodes
    print('\n=====================================================')
    print(f'计算区域: {region_name} | direction = {direction}')
    print('=====================================================')
    print('区域节点数:', len(region_idx))
    print('近场节点数:', int(near_nodes.sum()))
    print('远场节点数:', int(far_nodes.sum()))
    influence_near = np.zeros(n_sub, dtype=np.int32)
    influence_far = np.zeros(n_sub, dtype=np.int32)
    endpoints_near = []
    endpoints_far = []
    for i in region_idx:
        for j in range(n_sub):
            if i == j:
                continue
            if direction == 'out':
                is_link = sig_edges[i, j] and tau_sub[i, j] > 0 or (sig_edges[j, i] and tau_sub[j, i] < 0)
            elif direction == 'in':
                is_link = sig_edges[j, i] and tau_sub[j, i] > 0 or (sig_edges[i, j] and tau_sub[i, j] < 0)
            else:
                raise ValueError("direction 只能是 'out' 或 'in'。")
            if not is_link:
                continue
            if near_nodes[j]:
                influence_near[j] += 1
                endpoints_near.append(j)
            else:
                influence_far[j] += 1
                endpoints_far.append(j)
    endpoints_near = np.asarray(endpoints_near, dtype=np.int32)
    endpoints_far = np.asarray(endpoints_far, dtype=np.int32)
    print('近场端点数 L_near =', len(endpoints_near))
    print('远场端点数 L_far  =', len(endpoints_far))
    sig_mask_near, _, _ = spherical_kde_sigmask(endpoints_near, lats, lons, n_iter=KDE_N_ITER, p=KDE_P, seed=seed_base + 1, min_bw=KDE_MIN_BW)
    sig_mask_far, _, _ = spherical_kde_sigmask(endpoints_far, lats, lons, n_iter=KDE_N_ITER, p=KDE_P, seed=seed_base + 2, min_bw=KDE_MIN_BW)
    print('near 显著格点数:', int(sig_mask_near.sum()), '/', n_sub)
    print('far  显著格点数:', int(sig_mask_far.sum()), '/', n_sub)
    influence_near_sig = influence_near.copy().astype(float)
    influence_far_sig = influence_far.copy().astype(float)
    influence_near_sig[~sig_mask_near] = 0.0
    influence_far_sig[~sig_mask_far] = 0.0
    lon_grid = np.linspace(np.min(lons), np.max(lons), 200)
    lat_grid = np.linspace(np.min(lats), np.max(lats), 100)
    lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
    rbf_near = Rbf(lons, lats, influence_near_sig, function='linear', smooth=3)
    rbf_far = Rbf(lons, lats, influence_far_sig, function='linear', smooth=3)
    use_continuous_rbf = region_name == 'North America' and direction == 'out'
    if use_continuous_rbf:
        influence_interp_near = rbf_near(lon2d, lat2d)
        influence_interp_far = rbf_far(lon2d, lat2d)
        influence_interp_near = np.clip(influence_interp_near, 0, None)
        influence_interp_far = np.clip(influence_interp_far, 0, None)
    else:
        influence_interp_near = np.rint(rbf_near(lon2d, lat2d)).astype(float)
        influence_interp_far = np.rint(rbf_far(lon2d, lat2d)).astype(float)
    region_grid_mask = (lon2d >= lon_min) & (lon2d <= lon_max) & (lat2d >= lat_min) & (lat2d <= lat_max)
    influence_plot_near = influence_interp_near.astype(float).copy()
    influence_plot_far = influence_interp_far.astype(float).copy()
    influence_plot_near[region_grid_mask] = np.nan
    influence_plot_far[region_grid_mask] = np.nan
    influence_plot_near = influence_plot_near / norm_factor
    influence_plot_far = influence_plot_far / norm_factor
    return {'region_name': region_name, 'direction': direction, 'lon2d': lon2d, 'lat2d': lat2d, 'near': influence_plot_near, 'far': influence_plot_far, 'lon_min': lon_min, 'lon_max': lon_max, 'lat_min': lat_min, 'lat_max': lat_max}
map_fields = {}
seed_counter = 10
for r_id, (region_name, region_info) in enumerate(REGIONS.items()):
    map_fields[region_name, 'out'] = compute_region_propagation_fields(region_name, region_info, direction='out', seed_base=seed_counter + r_id * 10)
    map_fields[region_name, 'in'] = compute_region_propagation_fields(region_name, region_info, direction='in', seed_base=seed_counter + r_id * 10 + 100)

def add_tau_record(records, region_name, direction, range_type, region_node, external_node, edge_i, edge_j, tau_value, w_value, min_dist_to_region, edge_distance):
    if not np.isfinite(tau_value):
        return
    if tau_value == 0:
        return
    if not np.isfinite(w_value):
        return
    if w_value < EXTRA_W_THRESHOLD:
        return
    if not high_degree_mask[external_node]:
        return
    if USE_ABS_TAU:
        tau_to_record = abs(tau_value)
    else:
        tau_to_record = tau_value
    records.append({'region': region_name, 'direction': direction, 'range': range_type, 'region_node': int(region_node), 'external_node': int(external_node), 'edge_i': int(edge_i), 'edge_j': int(edge_j), 'lon_external': float(lons[external_node]), 'lat_external': float(lats[external_node]), 'tau': float(tau_value), 'tau_abs': float(abs(tau_value)), 'tau_used': float(tau_to_record), 'W': float(w_value), 'min_dist_to_region_km': float(min_dist_to_region), 'edge_distance_km': float(edge_distance), 'out_degree_external': float(out_degree[external_node]), 'in_degree_external': float(in_degree[external_node]), 'total_degree_external': float(total_degree[external_node])})

def collect_tau_for_region(region_name, region_info):
    lon_min = region_info['lon_min']
    lon_max = region_info['lon_max']
    lat_min = region_info['lat_min']
    lat_max = region_info['lat_max']
    region_mask = (lons >= lon_min) & (lons <= lon_max) & (lats >= lat_min) & (lats <= lat_max)
    region_idx = np.where(region_mask)[0]
    if len(region_idx) == 0:
        raise ValueError(f'{region_name} 区域没有节点，请检查经纬度范围。')
    external_mask = ~region_mask
    external_idx = np.where(external_mask)[0]
    dist_region_to_all = distance[np.ix_(region_idx, np.arange(n_sub))]
    min_dist_to_region = np.nanmin(dist_region_to_all, axis=0)
    near_nodes = min_dist_to_region <= DIST_TH_KM
    far_nodes = min_dist_to_region > DIST_TH_KM
    print('\n=====================================================')
    print(f'收集 tau: {region_name}')
    print('=====================================================')
    print('区域节点数:', len(region_idx))
    print('外部节点数:', len(external_idx))
    print('near external nodes:', int(np.sum(near_nodes & external_mask)))
    print('far external nodes:', int(np.sum(far_nodes & external_mask)))
    records = []
    for i in region_idx:
        for j in external_idx:
            if i == j:
                continue
            if near_nodes[j]:
                range_type = 'short'
            elif far_nodes[j]:
                range_type = 'long'
            else:
                continue
            if sig_edges[i, j] and tau_sub[i, j] > 0:
                add_tau_record(records=records, region_name=region_name, direction='out', range_type=range_type, region_node=i, external_node=j, edge_i=i, edge_j=j, tau_value=tau_sub[i, j], w_value=W_pos_sub[i, j], min_dist_to_region=min_dist_to_region[j], edge_distance=distance[i, j])
            elif sig_edges[j, i] and tau_sub[j, i] < 0:
                add_tau_record(records=records, region_name=region_name, direction='out', range_type=range_type, region_node=i, external_node=j, edge_i=j, edge_j=i, tau_value=tau_sub[j, i], w_value=W_pos_sub[j, i], min_dist_to_region=min_dist_to_region[j], edge_distance=distance[i, j])
            if sig_edges[j, i] and tau_sub[j, i] > 0:
                add_tau_record(records=records, region_name=region_name, direction='in', range_type=range_type, region_node=i, external_node=j, edge_i=j, edge_j=i, tau_value=tau_sub[j, i], w_value=W_pos_sub[j, i], min_dist_to_region=min_dist_to_region[j], edge_distance=distance[i, j])
            elif sig_edges[i, j] and tau_sub[i, j] < 0:
                add_tau_record(records=records, region_name=region_name, direction='in', range_type=range_type, region_node=i, external_node=j, edge_i=i, edge_j=j, tau_value=tau_sub[i, j], w_value=W_pos_sub[i, j], min_dist_to_region=min_dist_to_region[j], edge_distance=distance[i, j])
    df_region = pd.DataFrame(records)
    print(f'{region_name} tau records:', len(df_region))
    if len(df_region) > 0:
        print(df_region.groupby(['direction', 'range'], as_index=False).agg(n_edges=('tau_used', 'count'), mean_tau=('tau_abs', 'mean'), median_tau=('tau_abs', 'median'), mean_W=('W', 'mean'), mean_dist=('min_dist_to_region_km', 'mean')).to_string(index=False))
    return df_region
df_tau_all_list = []
for region_name, region_info in REGIONS.items():
    df_region = collect_tau_for_region(region_name, region_info)
    if len(df_region) > 0:
        df_tau_all_list.append(df_region)
if len(df_tau_all_list) == 0:
    raise ValueError('没有提取到任何 tau 记录，请检查显著边阈值或区域设置。')
df_tau_all = pd.concat(df_tau_all_list, ignore_index=True)
print('\n=====================================================')
print('全部 tau 记录统计')
print('=====================================================')
print('total records:', len(df_tau_all))
df_tau_summary = df_tau_all.groupby(['region', 'direction', 'range'], as_index=False).agg(n_edges=('tau_abs', 'count'), mean_tau=('tau_abs', 'mean'), median_tau=('tau_abs', 'median'), std_tau=('tau_abs', 'std'), q25_tau=('tau_abs', lambda x: np.nanpercentile(x, 25)), q75_tau=('tau_abs', lambda x: np.nanpercentile(x, 75)), min_tau=('tau_abs', 'min'), max_tau=('tau_abs', 'max'), mean_W=('W', 'mean'), median_W=('W', 'median'), mean_min_dist_km=('min_dist_to_region_km', 'mean'), median_min_dist_km=('min_dist_to_region_km', 'median'))
print('\n=====================================================')
print('tau 分布统计表')
print('=====================================================')
print(df_tau_summary.to_string(index=False))
if SAVE_RESULTS:
    out_table_dir = os.path.dirname(OUT_TABLE)
    if out_table_dir != '':
        os.makedirs(out_table_dir, exist_ok=True)
    df_tau_summary.to_csv(OUT_TABLE, index=False, encoding='utf-8-sig')
    print('Summary table saved:')
    print(OUT_TABLE)

def handle_cyclic_data(data, lon, lat):
    lon_1d = lon[0, :] if lon.ndim > 1 else lon
    lat_1d = lat[:, 0] if lat.ndim > 1 else lat
    cyclic_data, cyclic_lon = add_cyclic_point(data, coord=lon_1d)
    cyclic_lon2d, cyclic_lat2d = np.meshgrid(cyclic_lon, lat_1d)
    return (cyclic_data, cyclic_lon2d, cyclic_lat2d)

def setup_map_ax(ax, show_left_labels=True, show_bottom_labels=False):
    data_proj = ccrs.PlateCarree()
    ax.set_extent([-180, 180, -5, 90], crs=data_proj)
    ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
    ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
    ax.add_feature(cfeature.LAND, facecolor='white', zorder=0)
    ax.add_feature(cfeature.COASTLINE, linewidth=LW_COAST, color='#333333', zorder=1)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=LW_GRID, color='gray', alpha=0.3)
    gl.top_labels = False
    gl.right_labels = False
    gl.left_labels = show_left_labels
    gl.bottom_labels = show_bottom_labels
    gl.xlabel_style = {'size': FS_MAP_TICK}
    gl.ylabel_style = {'size': FS_MAP_TICK}
    gl.xlocator = mticker.FixedLocator([-180, -120, -60, 0, 60, 120, 180])
    gl.ylocator = mticker.FixedLocator([0, 35, 70])
    return gl

def plot_map_panel(ax, field, panel_label, direction, title=None, show_left_labels=True, show_bottom_labels=False):
    data_proj = ccrs.PlateCarree()
    setup_map_ax(ax, show_left_labels=show_left_labels, show_bottom_labels=show_bottom_labels)
    lon2d = field['lon2d']
    lat2d = field['lat2d']
    data_near = field['near']
    data_far = field['far']
    lon_min = field['lon_min']
    lon_max = field['lon_max']
    lat_min = field['lat_min']
    lat_max = field['lat_max']
    region_name = field['region_name']
    if direction == 'out':
        levels_near = LEVELS_OUT_NEAR
        levels_far = LEVELS_OUT_FAR
        cmap_near = CMAP_OUT_NEAR
        cmap_far = CMAP_OUT_FAR
        plot_lon2d = lon2d
        plot_lat2d = lat2d
        plot_near = data_near
        plot_far = data_far
    elif direction == 'in':
        levels_near = LEVELS_IN_NEAR
        levels_far = LEVELS_IN_FAR_BY_REGION[region_name]
        cmap_near = CMAP_IN_NEAR
        cmap_far = CMAP_IN_FAR
        plot_near, plot_lon2d, plot_lat2d = handle_cyclic_data(data_near, lon2d, lat2d)
        plot_far, _, _ = handle_cyclic_data(data_far, lon2d, lat2d)
    else:
        raise ValueError("direction 只能是 'out' 或 'in'。")
    data_near_masked = np.ma.masked_where(~np.isfinite(plot_near) | (plot_near <= MAP_NEAR_THRESH), plot_near)
    data_far_masked = np.ma.masked_where(~np.isfinite(plot_far) | (plot_far <= MAP_FAR_THRESH), plot_far)
    cf_near = ax.contourf(plot_lon2d, plot_lat2d, data_near_masked, levels=levels_near, cmap=cmap_near, alpha=MAP_ALPHA_NEAR, transform=data_proj, extend='both', zorder=2, antialiased=False)
    cf_far = ax.contourf(plot_lon2d, plot_lat2d, data_far_masked, levels=levels_far, cmap=cmap_far, alpha=MAP_ALPHA_FAR, transform=data_proj, extend='both', zorder=3, antialiased=False)
    rect_lons = [lon_min, lon_max, lon_max, lon_min, lon_min]
    rect_lats = [lat_min, lat_min, lat_max, lat_max, lat_min]
    ax.plot(rect_lons, rect_lats, color=COLOR_REGION_BOX, linewidth=LW_REGION_BOX, transform=data_proj, zorder=10)
    rect_patch = mpatches.Rectangle((lon_min, lat_min), lon_max - lon_min, lat_max - lat_min, transform=data_proj, facecolor='none', edgecolor=COLOR_REGION_BOX, linewidth=0, hatch='xxxx', zorder=4)
    ax.add_patch(rect_patch)
    if title is not None:
        ax.set_title(title, fontsize=FS_MAP_TITLE, pad=2.5)
    else:
        ax.set_title('')
    ax.text(-0.05, 1.25, panel_label, transform=ax.transAxes, fontsize=FS_PANEL_MAP, fontweight='bold', fontfamily='Arial', va='top', ha='left', color='black', zorder=20)
    return (cf_near, cf_far)

def add_map_colorbar(fig, mappable, rect, label, levels):
    cax = fig.add_axes(rect)
    cb = fig.colorbar(mappable, cax=cax, orientation='horizontal')
    cb.set_label(label, fontsize=FS_MAP_CBAR_LABEL, labelpad=1.0)
    cb.set_ticks(levels[::3])
    cb.ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%.2f'))
    cb.ax.tick_params(labelsize=FS_MAP_CBAR_TICK, length=2.0, width=0.55, pad=1.0)
    cb.outline.set_linewidth(LW_CBAR_OUTLINE)
    return cb

def compute_1d_density(values):
    values = np.asarray(values, dtype=float)
    valid = np.isfinite(values)
    density = np.full(values.shape, np.nan, dtype=float)
    if np.sum(valid) < 3:
        density[valid] = 1.0
        return density
    vals_valid = values[valid]
    if np.nanstd(vals_valid) < 1e-12:
        density[valid] = 1.0
        return density
    try:
        kde = gaussian_kde(vals_valid)
        dens_valid = kde(vals_valid)
    except Exception:
        hist, bin_edges = np.histogram(vals_valid, bins=20, density=True)
        bin_idx = np.searchsorted(bin_edges, vals_valid, side='right') - 1
        bin_idx = np.clip(bin_idx, 0, len(hist) - 1)
        dens_valid = hist[bin_idx]
    if NORMALIZE_DENSITY_WITHIN_GROUP:
        d_min = np.nanmin(dens_valid)
        d_max = np.nanmax(dens_valid)
        if np.isfinite(d_min) and np.isfinite(d_max) and (d_max > d_min):
            dens_valid = (dens_valid - d_min) / (d_max - d_min)
        else:
            dens_valid = np.ones_like(dens_valid)
    density[valid] = dens_valid
    return density

def plot_g_panel(fig, ax, df_tau_all):
    region_names = list(REGIONS.keys())
    directions = ['out', 'in']
    direction_tick_labels = {'out': 'From', 'in': 'To'}
    rng = np.random.default_rng(42)
    norm = Normalize(vmin=0.0, vmax=1.0)
    data_list = []
    positions = []
    box_colors = []
    range_types_for_groups = []
    group_info = []
    xtick_positions = []
    xtick_labels = []
    for r_id, region_name in enumerate(region_names):
        region_base = r_id * G_REGION_GAP
        for d_id, direction in enumerate(directions):
            direction_center = region_base + (d_id - 0.5) * G_DIR_GAP
            xtick_positions.append(direction_center)
            if region_name == 'North America':
                xtick_label = f'{direction_tick_labels[direction]} North\nAmerica'
            elif region_name == 'East Asia':
                xtick_label = f'{direction_tick_labels[direction]} East\nAsia'
            elif region_name == 'Europe':
                xtick_label = f'{direction_tick_labels[direction]}\nEurope'
            else:
                xtick_label = f'{direction_tick_labels[direction]}\n{region_name}'
            xtick_labels.append(xtick_label)
            for range_type, offset, c_box in [('short', -G_BOX_OFFSET, COLOR_SHORT), ('long', G_BOX_OFFSET, COLOR_LONG)]:
                vals = df_tau_all[(df_tau_all['region'] == region_name) & (df_tau_all['direction'] == direction) & (df_tau_all['range'] == range_type)]['tau_abs'].dropna().values
                if len(vals) == 0:
                    continue
                pos = direction_center + offset
                data_list.append(vals)
                positions.append(pos)
                box_colors.append(c_box)
                range_types_for_groups.append(range_type)
                group_info.append({'region': region_name, 'direction': direction, 'range': range_type, 'position': pos, 'n': len(vals), 'mean': np.nanmean(vals), 'median': np.nanmedian(vals)})
    if len(data_list) == 0:
        raise ValueError('没有可绘制的 tau 数据，请检查 df_tau_all。')
    bp = ax.boxplot(data_list, positions=positions, widths=G_BOX_WIDTH, patch_artist=True, showfliers=False, showmeans=False, medianprops=dict(color=COLOR_AXIS, linewidth=LW_G_MEAN, linestyle='-'), whiskerprops=dict(color=COLOR_WHISKER, linewidth=LW_G_WHISKER), capprops=dict(color=COLOR_WHISKER, linewidth=LW_G_CAP))
    for patch, c in zip(bp['boxes'], box_colors):
        patch.set_facecolor('white')
        patch.set_alpha(0.42)
        patch.set_edgecolor(c)
        patch.set_linewidth(LW_G_BOX)
        patch.set_zorder(2)
    for whisker in bp['whiskers']:
        whisker.set_color(COLOR_WHISKER)
        whisker.set_linewidth(LW_G_WHISKER)
    for cap in bp['caps']:
        cap.set_color(COLOR_WHISKER)
        cap.set_linewidth(LW_G_CAP)
    for median_line, c in zip(bp['medians'], box_colors):
        median_line.set_color(c)
        median_line.set_linewidth(LW_G_MEAN)
        median_line.set_linestyle('-')
        median_line.set_zorder(6)
    for vals, pos, range_type in zip(data_list, positions, range_types_for_groups):
        vals_all = vals.copy()
        density_all = compute_1d_density(vals_all)
        if len(vals_all) > MAX_SCATTER_POINTS_PER_BOX:
            show_idx = rng.choice(np.arange(len(vals_all)), size=MAX_SCATTER_POINTS_PER_BOX, replace=False)
            vals_plot = vals_all[show_idx]
            density_plot = density_all[show_idx]
        else:
            vals_plot = vals_all
            density_plot = density_all
        jitter = rng.normal(loc=0.0, scale=G_DENSITY_JITTER_SCALE, size=len(vals_plot))
        order = np.argsort(density_plot)
        if range_type == 'short':
            cmap_use = CMAP_G_SHORT_DENSITY
        else:
            cmap_use = CMAP_G_LONG_DENSITY
        ax.scatter(np.full(len(vals_plot), pos)[order] + jitter[order], vals_plot[order], c=density_plot[order], cmap=cmap_use, norm=norm, s=S_G_DENSITY_POINT, alpha=G_DENSITY_POINT_ALPHA, edgecolor=COLOR_SCATTER_EDGE, linewidths=LW_G_SCATTER_EDGE, zorder=3)
    for info in group_info:
        if info['range'] == 'short':
            text_x = info['position'] - G_MEAN_TEXT_XSHIFT
            ha = 'right'
            text_color = COLOR_SHORT
        else:
            text_x = info['position'] + G_MEAN_TEXT_XSHIFT
            ha = 'left'
            text_color = COLOR_LONG
        ax.scatter(info['position'], info['median'], s=S_G_MEAN_CIRCLE, marker='o', facecolor='white', edgecolor=text_color, linewidth=LW_G_MEAN_CIRCLE, zorder=8)
        ax.text(text_x, info['median'], f"{info['median']:.0f}", ha=ha, va='center', fontsize=FS_G_MEAN_TEXT, color=text_color, fontweight='bold', zorder=9)
    ax.set_xticks(xtick_positions)
    ax.set_xticklabels(xtick_labels, rotation=0, fontsize=FS_G_XTICK, linespacing=1.1)
    ax.set_ylabel('Lag time, $|\\tau|$ (days)', fontsize=FS_G_YLABEL, labelpad=4)
    ax.set_xlabel('')
    ax.set_title('')
    ax.set_xlim(min(positions) - G_X_MARGIN, max(positions) + G_X_MARGIN)
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_linewidth(LW_AXIS)
    ax.spines['bottom'].set_linewidth(LW_AXIS)
    ax.tick_params(axis='both', which='major', labelsize=FS_G_YTICK, width=LW_AXIS, length=3.0)
    ax.tick_params(axis='x', labelsize=FS_G_XTICK, pad=3)
    ax.tick_params(axis='y', labelsize=FS_G_YTICK)
    ax.text(-0.045, 1.025, 'g', transform=ax.transAxes, ha='left', va='bottom', fontsize=FS_PANEL_G, fontweight='bold', color='black')
    if SHOW_G_DENSITY_COLORBAR:
        sm_short = ScalarMappable(norm=norm, cmap=CMAP_G_SHORT_DENSITY)
        sm_short.set_array([])
        sm_long = ScalarMappable(norm=norm, cmap=CMAP_G_LONG_DENSITY)
        sm_long.set_array([])
        cax1 = fig.add_axes(G_CBAR_SHORT_POS)
        cbar1 = fig.colorbar(sm_short, cax=cax1, orientation='horizontal')
        cbar1.set_label('Short-link density', fontsize=FS_G_CBAR_LABEL, labelpad=1.0)
        cbar1.ax.tick_params(labelsize=FS_G_CBAR_TICK, length=2.0, width=0.55, pad=1.0)
        cbar1.outline.set_linewidth(LW_CBAR_OUTLINE)
        cax2 = fig.add_axes(G_CBAR_LONG_POS)
        cbar2 = fig.colorbar(sm_long, cax=cax2, orientation='horizontal')
        cbar2.set_label('Long-link density', fontsize=FS_G_CBAR_LABEL, labelpad=1.0)
        cbar2.ax.tick_params(labelsize=FS_G_CBAR_TICK, length=2.0, width=0.55, pad=1.0)
        cbar2.outline.set_linewidth(LW_CBAR_OUTLINE)
fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT), dpi=FIG_DPI, facecolor='white')
ax_a = fig.add_axes(RECT_A, projection=ccrs.PlateCarree())
cf_a_near, cf_a_far = plot_map_panel(ax=ax_a, field=map_fields['North America', 'out'], panel_label='a', direction='out', title='$\\mathrm{nOUTD}_{\\mathcal{R}}$', show_left_labels=True, show_bottom_labels=False)
ax_b = fig.add_axes(RECT_B, projection=ccrs.PlateCarree(central_longitude=-120))
cf_b_near, cf_b_far = plot_map_panel(ax=ax_b, field=map_fields['North America', 'in'], panel_label='b', direction='in', title='$\\mathrm{nIND}_{\\mathcal{R}}$', show_left_labels=False, show_bottom_labels=False)
ax_c = fig.add_axes(RECT_C, projection=ccrs.PlateCarree())
cf_c_near, cf_c_far = plot_map_panel(ax=ax_c, field=map_fields['Europe', 'out'], panel_label='c', direction='out', title=None, show_left_labels=True, show_bottom_labels=False)
ax_d = fig.add_axes(RECT_D, projection=ccrs.PlateCarree())
cf_d_near, cf_d_far = plot_map_panel(ax=ax_d, field=map_fields['Europe', 'in'], panel_label='d', direction='in', title=None, show_left_labels=False, show_bottom_labels=False)
ax_e = fig.add_axes(RECT_E, projection=ccrs.PlateCarree())
cf_e_near, cf_e_far = plot_map_panel(ax=ax_e, field=map_fields['East Asia', 'out'], panel_label='e', direction='out', title=None, show_left_labels=True, show_bottom_labels=True)
ax_f = fig.add_axes(RECT_F, projection=ccrs.PlateCarree())
cf_f_near, cf_f_far = plot_map_panel(ax=ax_f, field=map_fields['East Asia', 'in'], panel_label='f', direction='in', title=None, show_left_labels=False, show_bottom_labels=True)
add_map_colorbar(fig=fig, mappable=cf_e_near, rect=CBAR_OUT_NEAR_POS, label='< 4,260.3 km', levels=LEVELS_OUT_NEAR)
add_map_colorbar(fig=fig, mappable=cf_e_far, rect=CBAR_OUT_FAR_POS, label='> 4,260.3 km', levels=LEVELS_OUT_FAR)
add_map_colorbar(fig=fig, mappable=cf_f_near, rect=CBAR_IN_NEAR_POS, label='< 4,260.3 km', levels=LEVELS_IN_NEAR)
add_map_colorbar(fig=fig, mappable=cf_f_far, rect=CBAR_IN_FAR_POS, label='> 4,260.3 km', levels=LEVELS_IN_FAR_BY_REGION['East Asia'])
ax_g = fig.add_axes(RECT_G)
plot_g_panel(fig=fig, ax=ax_g, df_tau_all=df_tau_all)
if SAVE_RESULTS:
    out_dir = os.path.dirname(OUT_FIG)
    if out_dir != '':
        os.makedirs(out_dir, exist_ok=True)
    fig.savefig(OUT_FIG, dpi=SAVE_DPI, bbox_inches='tight', pad_inches=0.02)
    fig.savefig(OUT_FIG_PDF, bbox_inches='tight', pad_inches=0.02)
    print('\nFigure saved:')
    print(OUT_FIG)
    print(OUT_FIG_PDF)
plt.show()
print('\n=====================================================')
print('最终可汇报统计')
print('=====================================================')
for _, row in df_tau_summary.iterrows():
    direction_text = 'selected region -> external nodes' if row['direction'] == 'out' else 'external nodes -> selected region'
    print(f"{row['region']:15s} | {direction_text:35s} | {row['range']:5s} | N={int(row['n_edges']):6d} | mean={row['mean_tau']:.2f} d | median={row['median_tau']:.2f} d | IQR=[{row['q25_tau']:.2f}, {row['q75_tau']:.2f}] d")
