import numpy as np
import matplotlib.pyplot as plt
import xarray as xr
from scipy.stats import gaussian_kde, mannwhitneyu
from scipy.interpolate import griddata
from scipy.ndimage import gaussian_filter
from matplotlib.ticker import MaxNLocator
from matplotlib.path import Path
import cartopy.crs as ccrs
import cartopy.feature as cfeature
K0 = 7
WAVE_LABEL = f'wave-{K0}'
LAT_MIN = -5.0
LAT_MAX = 90.0
PROFILE_LAT_MIN = 35
PROFILE_LAT_MAX = 60
PROFILE_USE_COSLAT_WEIGHT = True
MAP_ROSSBY_POS_PERCENT = 15.0
MAP_ROSSBY_NEG_PERCENT = 15.0
MAP_DEGREE_TOP_PERCENT = 15.0
PDF_ROSSBY_POS_PERCENT = 10
PDF_ROSSBY_NEG_PERCENT = 10
PDF_DEGREE_TOP_PERCENT = 10
FIG_WIDTH = 7.2
FIG_HEIGHT = 5.71
FIG_DPI = 300
RECT_A = [0.06, 0.685, 0.525, 0.28]
RECT_C = [0.06, 0.36, 0.525, 0.28]
RECT_E = [0.06, 0.035, 0.525, 0.28]
CBAR_A = [0.595, 0.735, 0.01, 0.18]
CBAR_C = [0.595, 0.41, 0.01, 0.18]
CBAR_E = [0.595, 0.085, 0.01, 0.18]
RECT_B = [0.79, 0.74, 0.26, 0.2]
RECT_D = [0.79, 0.415, 0.26, 0.2]
RECT_F = [0.79, 0.09, 0.26, 0.2]
FONT_FAMILY = 'Arial'
FS_PANEL = 20
FS_MAP_TITLE = 15
FS_AXIS_LABEL = 15
FS_TICK = 15
FS_LEGEND = 8
FS_CBAR_LABEL = 15
FS_CBAR_TICK = 15
PANEL_MAP_X = -0.078
PANEL_MAP_Y = 1.38
PANEL_PDF_X = -0.16
PANEL_PDF_Y = 1.16
MAP_EXTENT = [-180, 180, LAT_MIN, LAT_MAX]
MAP_XTICKS = [-180, -120, -60, 0, 60, 120, 180]
MAP_XTICKLABELS = ['180°', '120°W', '60°W', '0°', '60°E', '120°E', '180°']
MAP_YTICKS = [0, 30, 60, 90]
MAP_YTICKLABELS = ['0°', '30°N', '60°N', '90°N']
OUT_CMAP = 'Purples'
IN_CMAP = 'Oranges'
ROSSBY_CMAP = 'PuOr_r'
OUT_COLOR = '#E44A33'
IN_COLOR = '#4DBAD6'
ALL_COLOR = '#999999'
DEGREE_COLOR = '#E9C46A'
MAP_POS_COLOR = '#D73027'
MAP_NEG_COLOR = '#2166AC'
MAP_HIGH_OUT_COLOR = '#D73027'
MAP_HIGH_IN_COLOR = '#2166AC'
SLASH_MARKER = Path([[-0.5, -0.5], [0.5, 0.5]], [Path.MOVETO, Path.LINETO])
DEGREE_VMIN_PERCENTILE = 1.0
DEGREE_VMAX_PERCENTILE = 99.0
DEGREE_N_LEVELS = 18
MAP_GRID_RESOLUTION = 1.0
DEGREE_INTERP_METHOD = 'linear'
DEGREE_SMOOTH_SIGMA = 1.0
ROSSBY_N_LEVELS = 17
ROSSBY_ABS_LIMIT = None
ROSSBY_ABS_PERCENTILE = 98.0
COASTLINE_WIDTH = 0.38
COASTLINE_COLOR = '#303030'
BORDER_WIDTH = 0.16
BORDER_COLOR = '#777777'
ROSSBY_NODE_SIZE = 8
ROSSBY_NODE_LINEWIDTH = 0.75
HIGH_DEGREE_SIZE = 6
HIGH_DEGREE_LINEWIDTH = 0.75
PDF_LINEWIDTH = 2
KDE_BW_ALL = 0.35
KDE_BW_SELECTED = 0.5
PDF_XMIN_PERCENTILE = 0.5
PDF_XMAX_PERCENTILE = 99.5
PDF_Y_MARGIN = 1.3
PDF_X_NBINS = 5
PDF_Y_NBINS = 4
LEGEND_LOC = 'upper right'
LEGEND_HANDLE_LENGTH = 1.15
LEGEND_HANDLE_TEXTPAD = 0.5
LEGEND_LABEL_SPACING = 0.1
LEGEND_BORDERAXESPAD = 0.01
TITLE_A = 'Out degree'
TITLE_C = 'In degree'
TITLE_E = f'250 hPa meridional wind ({WAVE_LABEL})'
SAVE_FIG = False
SAVE_PATH = 'outputs/figures/figure_009.pdf'
plt.rcParams.update({'font.family': FONT_FAMILY, 'font.size': FS_TICK, 'axes.linewidth': 0.55, 'xtick.direction': 'out', 'ytick.direction': 'out', 'xtick.major.size': 2.2, 'ytick.major.size': 2.2, 'xtick.major.width': 0.55, 'ytick.major.width': 0.55, 'xtick.major.pad': 1.5, 'ytick.major.pad': 1.5, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False})
weeks_wave = weeks_PhaseLocking[K0 - 1]
v250_wave_composite = v250_weekly.sel(week=weeks_wave).mean('week')
vplot = v250_wave_composite.copy()
vplot = vplot.assign_coords(lon=(vplot.lon + 180.0) % 360.0 - 180.0)
vplot = vplot.sortby('lon').sortby('lat')
vplot = vplot.sel(lat=slice(LAT_MIN, LAT_MAX))
print('\n==============================')
print('Rossby field')
print('==============================')
print('shape =', vplot.shape)
print('grid number =', vplot.size)
out_degree_node = np.asarray(out_degree, dtype=float).reshape(-1)
in_degree_node = np.asarray(in_degree, dtype=float).reshape(-1)
lon_node = np.asarray(lons, dtype=float).reshape(-1)
lat_node = np.asarray(lats, dtype=float).reshape(-1)
if not len(out_degree_node) == len(in_degree_node) == len(lon_node) == len(lat_node):
    raise ValueError('out_degree / in_degree / lons / lats 长度不一致')
lon_node = (lon_node + 180.0) % 360.0 - 180.0
v_left = vplot.assign_coords(lon=vplot.lon - 360.0)
v_center = vplot.copy()
v_right = vplot.assign_coords(lon=vplot.lon + 360.0)
vplot_periodic = xr.concat([v_left, v_center, v_right], dim='lon').sortby('lon')
node_lon_da = xr.DataArray(lon_node, dims='points')
node_lat_da = xr.DataArray(lat_node, dims='points')
rossby_at_nodes_da = vplot_periodic.interp(lon=node_lon_da, lat=node_lat_da, method='linear')
rossby_at_nodes = np.asarray(rossby_at_nodes_da.values, dtype=float).reshape(-1)
valid = np.isfinite(rossby_at_nodes) & np.isfinite(out_degree_node) & np.isfinite(in_degree_node) & np.isfinite(lon_node) & np.isfinite(lat_node) & (lat_node >= LAT_MIN) & (lat_node <= LAT_MAX)
rossby_pair = rossby_at_nodes[valid]
out_pair = out_degree_node[valid]
in_pair = in_degree_node[valid]
lon_pair = lon_node[valid]
lat_pair = lat_node[valid]
degree_pair = out_pair + in_pair
print('\n==============================')
print('Valid paired nodes')
print('==============================')
print('N =', len(rossby_pair))
map_rossby_pos_threshold = np.nanpercentile(rossby_pair, 100.0 - MAP_ROSSBY_POS_PERCENT)
map_rossby_pos_mask = rossby_pair >= map_rossby_pos_threshold
map_rossby_neg_threshold = np.nanpercentile(rossby_pair, MAP_ROSSBY_NEG_PERCENT)
map_rossby_neg_mask = rossby_pair <= map_rossby_neg_threshold
map_out_threshold = np.nanpercentile(out_pair, 100.0 - MAP_DEGREE_TOP_PERCENT)
map_out_high_mask = out_pair >= map_out_threshold
map_in_threshold = np.nanpercentile(in_pair, 100.0 - MAP_DEGREE_TOP_PERCENT)
map_in_high_mask = in_pair >= map_in_threshold

def longitude_mean_from_nodes(lon, lat, values, lat_min=PROFILE_LAT_MIN, lat_max=PROFILE_LAT_MAX, use_cos_weight=PROFILE_USE_COSLAT_WEIGHT):
    lon = np.asarray(lon, dtype=float).reshape(-1)
    lat = np.asarray(lat, dtype=float).reshape(-1)
    values = np.asarray(values, dtype=float).reshape(-1)
    valid_prof = np.isfinite(lon) & np.isfinite(lat) & np.isfinite(values) & (lat >= lat_min) & (lat <= lat_max)
    lon_use = lon[valid_prof]
    lat_use = lat[valid_prof]
    values_use = values[valid_prof]
    lon_key = np.round(lon_use, 6)
    unique_lon = np.sort(np.unique(lon_key))
    mean_values = np.full(unique_lon.shape, np.nan, dtype=float)
    for ii, lo in enumerate(unique_lon):
        m = lon_key == lo
        vv = values_use[m]
        ll = lat_use[m]
        good = np.isfinite(vv) & np.isfinite(ll)
        vv = vv[good]
        ll = ll[good]
        if vv.size == 0:
            continue
        if use_cos_weight:
            ww = np.cos(np.deg2rad(ll))
            sw = np.sum(ww)
            if sw > 0:
                mean_values[ii] = np.sum(vv * ww) / sw
        else:
            mean_values[ii] = np.mean(vv)
    return (unique_lon, mean_values)
lon_out_mean, out_lon_mean = longitude_mean_from_nodes(lon_pair, lat_pair, out_pair)
lon_in_mean, in_lon_mean = longitude_mean_from_nodes(lon_pair, lat_pair, in_pair)
lon_rossby_mean, rossby_lon_mean = longitude_mean_from_nodes(lon_pair, lat_pair, rossby_pair)
if not (np.array_equal(lon_out_mean, lon_in_mean) and np.array_equal(lon_out_mean, lon_rossby_mean)):
    raise ValueError('Out/In/Rossby 的经度平均网格不一致，请检查节点经度。')
lon_mean = lon_out_mean.copy()
valid_lon_mean = np.isfinite(out_lon_mean) & np.isfinite(in_lon_mean) & np.isfinite(rossby_lon_mean)
lon_mean = lon_mean[valid_lon_mean]
out_lon_mean = out_lon_mean[valid_lon_mean]
in_lon_mean = in_lon_mean[valid_lon_mean]
rossby_lon_mean = rossby_lon_mean[valid_lon_mean]
degree_lon_mean = out_lon_mean + in_lon_mean
print('\n==============================')
print('Longitude-mean samples')
print('==============================')
print(f'Latitude band = {PROFILE_LAT_MIN:g} to {PROFILE_LAT_MAX:g} N')
print('Cos-latitude weighted =', PROFILE_USE_COSLAT_WEIGHT)
print('Longitude-bin N =', len(lon_mean))
pdf_rossby_pos_threshold = np.nanpercentile(rossby_lon_mean, 100.0 - PDF_ROSSBY_POS_PERCENT)
pdf_rossby_pos_mask = rossby_lon_mean >= pdf_rossby_pos_threshold
pdf_rossby_neg_threshold = np.nanpercentile(rossby_lon_mean, PDF_ROSSBY_NEG_PERCENT)
pdf_rossby_neg_mask = rossby_lon_mean <= pdf_rossby_neg_threshold
pdf_degree_threshold = np.nanpercentile(degree_lon_mean, 100.0 - PDF_DEGREE_TOP_PERCENT)
pdf_degree_high_mask = degree_lon_mean >= pdf_degree_threshold
print('\n==============================')
print('MAP thresholds')
print('==============================')
print(f'a positive Rossby top {MAP_ROSSBY_POS_PERCENT:g}% =', np.sum(map_rossby_pos_mask))
print(f'c negative Rossby bottom {MAP_ROSSBY_NEG_PERCENT:g}% =', np.sum(map_rossby_neg_mask))
print(f'e out-degree top {MAP_DEGREE_TOP_PERCENT:g}% =', np.sum(map_out_high_mask))
print(f'e in-degree top {MAP_DEGREE_TOP_PERCENT:g}% =', np.sum(map_in_high_mask))
print('\n==============================')
print('PDF thresholds: longitude-mean samples')
print('==============================')
print(f'b positive Rossby longitude-mean top {PDF_ROSSBY_POS_PERCENT:g}% =', np.sum(pdf_rossby_pos_mask))
print(f'd negative Rossby longitude-mean bottom {PDF_ROSSBY_NEG_PERCENT:g}% =', np.sum(pdf_rossby_neg_mask))
print(f'f total-degree longitude-mean top {PDF_DEGREE_TOP_PERCENT:g}% =', np.sum(pdf_degree_high_mask))
out_all = out_lon_mean
out_pdf_selected = out_lon_mean[pdf_rossby_pos_mask]
in_all = in_lon_mean
in_pdf_selected = in_lon_mean[pdf_rossby_neg_mask]
rossby_all = rossby_lon_mean
rossby_pdf_degree = rossby_lon_mean[pdf_degree_high_mask]
U_out, p_out = mannwhitneyu(out_lon_mean[pdf_rossby_pos_mask], out_lon_mean[~pdf_rossby_pos_mask], alternative='greater')
U_in, p_in = mannwhitneyu(in_lon_mean[pdf_rossby_neg_mask], in_lon_mean[~pdf_rossby_neg_mask], alternative='greater')
U_wave_degree, p_wave_degree = mannwhitneyu(rossby_lon_mean[pdf_degree_high_mask], rossby_lon_mean[~pdf_degree_high_mask], alternative='two-sided')
print('\n==============================')
print('Statistical tests: longitude-mean samples')
print('==============================')
print('b p =', p_out)
print('d p =', p_in)
print('f high-degree p =', p_wave_degree)

def get_kde(all_data, selected_data, bw_all=KDE_BW_ALL, bw_selected=KDE_BW_SELECTED):
    all_data = np.asarray(all_data, dtype=float)
    selected_data = np.asarray(selected_data, dtype=float)
    all_data = all_data[np.isfinite(all_data)]
    selected_data = selected_data[np.isfinite(selected_data)]
    xmin = np.nanpercentile(all_data, PDF_XMIN_PERCENTILE)
    xmax = np.nanpercentile(all_data, PDF_XMAX_PERCENTILE)
    x = np.linspace(xmin, xmax, 600)
    kde_all = gaussian_kde(all_data, bw_method=bw_all)
    kde_selected = gaussian_kde(selected_data, bw_method=bw_selected)
    return (x, kde_all(x), kde_selected(x))
x_out, pdf_out_all, pdf_out_selected = get_kde(out_all, out_pdf_selected)
x_in, pdf_in_all, pdf_in_selected = get_kde(in_all, in_pdf_selected)
wave_xmin = np.nanpercentile(rossby_all, PDF_XMIN_PERCENTILE)
wave_xmax = np.nanpercentile(rossby_all, PDF_XMAX_PERCENTILE)
x_wave = np.linspace(wave_xmin, wave_xmax, 600)
pdf_wave_all = gaussian_kde(rossby_all, bw_method=KDE_BW_ALL)(x_wave)
pdf_wave_degree = gaussian_kde(rossby_pdf_degree, bw_method=KDE_BW_SELECTED)(x_wave)

def interpolate_degree_map(lon, lat, values):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    values = np.asarray(values, dtype=float)
    lon_ext = np.concatenate([lon - 360.0, lon, lon + 360.0])
    lat_ext = np.concatenate([lat, lat, lat])
    values_ext = np.concatenate([values, values, values])
    grid_lon = np.arange(-180.0, 180.0 + MAP_GRID_RESOLUTION, MAP_GRID_RESOLUTION)
    grid_lat = np.arange(LAT_MIN, LAT_MAX + MAP_GRID_RESOLUTION, MAP_GRID_RESOLUTION)
    lon2d, lat2d = np.meshgrid(grid_lon, grid_lat)
    field = griddata((lon_ext, lat_ext), values_ext, (lon2d, lat2d), method=DEGREE_INTERP_METHOD)
    missing = ~np.isfinite(field)
    if np.any(missing):
        nearest = griddata((lon_ext, lat_ext), values_ext, (lon2d, lat2d), method='nearest')
        field[missing] = nearest[missing]
    if DEGREE_SMOOTH_SIGMA > 0:
        field = gaussian_filter(field, sigma=DEGREE_SMOOTH_SIGMA)
    return (grid_lon, grid_lat, lon2d, lat2d, field)
degree_grid_lon, degree_grid_lat, degree_lon2d, degree_lat2d, out_field = interpolate_degree_map(lon_pair, lat_pair, out_pair)
_, _, _, _, in_field = interpolate_degree_map(lon_pair, lat_pair, in_pair)
out_vmin = np.nanpercentile(out_pair, DEGREE_VMIN_PERCENTILE)
out_vmax = np.nanpercentile(out_pair, DEGREE_VMAX_PERCENTILE)
out_levels = np.linspace(out_vmin, out_vmax, DEGREE_N_LEVELS)
in_vmin = np.nanpercentile(in_pair, DEGREE_VMIN_PERCENTILE)
in_vmax = np.nanpercentile(in_pair, DEGREE_VMAX_PERCENTILE)
in_levels = np.linspace(in_vmin, in_vmax, DEGREE_N_LEVELS)
if ROSSBY_ABS_LIMIT is None:
    rossby_lim = np.nanpercentile(np.abs(vplot.values), ROSSBY_ABS_PERCENTILE)
else:
    rossby_lim = ROSSBY_ABS_LIMIT
rossby_levels = np.linspace(-rossby_lim, rossby_lim, ROSSBY_N_LEVELS)

def fix_geoaxes(ax):
    if not hasattr(ax, '_autoscaleXon'):
        ax._autoscaleXon = True
    if not hasattr(ax, '_autoscaleYon'):
        ax._autoscaleYon = True
projection = ccrs.PlateCarree()

def setup_map(ax):
    fix_geoaxes(ax)
    ax.set_extent(MAP_EXTENT, crs=projection)
    ax.coastlines(resolution='110m', linewidth=COASTLINE_WIDTH, color=COASTLINE_COLOR, zorder=30)
    ax.add_feature(cfeature.BORDERS, linewidth=BORDER_WIDTH, edgecolor=BORDER_COLOR, zorder=29)
    ax.set_xticks(MAP_XTICKS, crs=projection)
    ax.set_yticks(MAP_YTICKS, crs=projection)
    ax.set_xticklabels(MAP_XTICKLABELS)
    ax.set_yticklabels(MAP_YTICKLABELS)
    ax.tick_params(axis='both', labelsize=FS_TICK, pad=1.5)

def setup_pdf(ax):
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_linewidth(0.55)
    ax.spines['bottom'].set_linewidth(0.55)
    ax.tick_params(axis='both', labelsize=FS_TICK, pad=1.5)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=PDF_X_NBINS))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=PDF_Y_NBINS))
    ax.grid(False)

def add_panel_label(ax, text, is_map=True):
    if is_map:
        x0, y0 = (PANEL_MAP_X, PANEL_MAP_Y)
    else:
        x0, y0 = (PANEL_PDF_X, PANEL_PDF_Y)
    ax.text(x0, y0, text, transform=ax.transAxes, fontsize=FS_PANEL, fontweight='bold', ha='left', va='top', clip_on=False, zorder=100)
fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT), dpi=FIG_DPI, facecolor='white')
ax_a = fig.add_axes(RECT_A, projection=projection)
fix_geoaxes(ax_a)
im_a = ax_a.contourf(degree_lon2d, degree_lat2d, out_field, levels=out_levels, cmap=OUT_CMAP, extend='both', transform=projection, zorder=1)
ax_a.scatter(lon_pair[map_rossby_pos_mask], lat_pair[map_rossby_pos_mask], s=ROSSBY_NODE_SIZE, marker=SLASH_MARKER, color=MAP_POS_COLOR, linewidths=ROSSBY_NODE_LINEWIDTH, transform=projection, label=f'Positive Rossby top {MAP_ROSSBY_POS_PERCENT:g}%', zorder=40)
setup_map(ax_a)
ax_a.set_title(TITLE_A, fontsize=FS_MAP_TITLE, loc='left', pad=1.5)
add_panel_label(ax_a, 'a', True)
cax_a = fig.add_axes(CBAR_A)
cbar_a = fig.colorbar(im_a, cax=cax_a, orientation='vertical')
cbar_a.ax.tick_params(labelsize=FS_CBAR_TICK, width=0.45, length=2.0, pad=1.5)
cbar_a.outline.set_linewidth(0.45)
cbar_a.locator = MaxNLocator(nbins=3)
cbar_a.update_ticks()
ax_b = fig.add_axes(RECT_B)
ax_b.plot(x_out, pdf_out_selected, color=OUT_COLOR, linewidth=PDF_LINEWIDTH, label=f'Wave-7 top 15%', zorder=3)
ax_b.plot(x_out, pdf_out_all, color=ALL_COLOR, linewidth=PDF_LINEWIDTH, label='All longitudes', zorder=2)
ax_b.set_xlabel('Mean out-degree', fontsize=FS_AXIS_LABEL, labelpad=2.0)
ax_b.set_ylabel('PDF', fontsize=FS_AXIS_LABEL, labelpad=2.5)
setup_pdf(ax_b)
ymax_b = max(np.nanmax(pdf_out_selected), np.nanmax(pdf_out_all))
ax_b.set_ylim(0, ymax_b * PDF_Y_MARGIN)
add_panel_label(ax_b, 'b', False)
ax_b.legend(loc=LEGEND_LOC, frameon=False, fontsize=FS_LEGEND, handlelength=LEGEND_HANDLE_LENGTH, handletextpad=LEGEND_HANDLE_TEXTPAD, labelspacing=LEGEND_LABEL_SPACING, borderaxespad=LEGEND_BORDERAXESPAD)
ax_c = fig.add_axes(RECT_C, projection=projection)
fix_geoaxes(ax_c)
im_c = ax_c.contourf(degree_lon2d, degree_lat2d, in_field, levels=in_levels, cmap=IN_CMAP, extend='both', transform=projection, zorder=1)
ax_c.scatter(lon_pair[map_rossby_neg_mask], lat_pair[map_rossby_neg_mask], s=ROSSBY_NODE_SIZE, marker=SLASH_MARKER, color=MAP_NEG_COLOR, linewidths=ROSSBY_NODE_LINEWIDTH, transform=projection, label=f'Wave-7 bottom 5%', zorder=40)
setup_map(ax_c)
ax_c.set_title(TITLE_C, fontsize=FS_MAP_TITLE, loc='left', pad=1.5)
add_panel_label(ax_c, 'c', True)
cax_c = fig.add_axes(CBAR_C)
cbar_c = fig.colorbar(im_c, cax=cax_c, orientation='vertical')
cbar_c.ax.tick_params(labelsize=FS_CBAR_TICK, width=0.45, length=2.0, pad=1.5)
cbar_c.outline.set_linewidth(0.45)
cbar_c.locator = MaxNLocator(nbins=3)
cbar_c.update_ticks()
ax_d = fig.add_axes(RECT_D)
ax_d.plot(x_in, pdf_in_selected, color=IN_COLOR, linewidth=PDF_LINEWIDTH, label=f'Wave-7 bottom 15%', zorder=3)
ax_d.plot(x_in, pdf_in_all, color=ALL_COLOR, linewidth=PDF_LINEWIDTH, label='All longitudes', zorder=2)
ax_d.set_xlabel('Mean in-degree', fontsize=FS_AXIS_LABEL, labelpad=2.0)
ax_d.set_ylabel('PDF', fontsize=FS_AXIS_LABEL, labelpad=2.5)
setup_pdf(ax_d)
ymax_d = max(np.nanmax(pdf_in_selected), np.nanmax(pdf_in_all))
ax_d.set_ylim(0, ymax_d * PDF_Y_MARGIN)
add_panel_label(ax_d, 'd', False)
ax_d.legend(loc=LEGEND_LOC, frameon=False, fontsize=FS_LEGEND, handlelength=LEGEND_HANDLE_LENGTH, handletextpad=LEGEND_HANDLE_TEXTPAD, labelspacing=LEGEND_LABEL_SPACING, borderaxespad=LEGEND_BORDERAXESPAD)
ax_e = fig.add_axes(RECT_E, projection=projection)
fix_geoaxes(ax_e)
im_e = ax_e.contourf(vplot.lon.values, vplot.lat.values, vplot.values, levels=rossby_levels, cmap=ROSSBY_CMAP, extend='both', transform=projection, zorder=1)
ax_e.contour(vplot.lon.values, vplot.lat.values, vplot.values, levels=[0], colors='#444444', linewidths=0.4, transform=projection, zorder=5)
ax_e.scatter(lon_pair[map_out_high_mask], lat_pair[map_out_high_mask], s=HIGH_DEGREE_SIZE, marker=SLASH_MARKER, color=MAP_HIGH_OUT_COLOR, linewidths=HIGH_DEGREE_LINEWIDTH, transform=projection, label=f'Top {MAP_DEGREE_TOP_PERCENT:g}% out-degree', zorder=40)
ax_e.scatter(lon_pair[map_in_high_mask], lat_pair[map_in_high_mask], s=HIGH_DEGREE_SIZE, marker=SLASH_MARKER, color=MAP_HIGH_IN_COLOR, linewidths=HIGH_DEGREE_LINEWIDTH, transform=projection, label=f'Top {MAP_DEGREE_TOP_PERCENT:g}% in-degree', zorder=41)
setup_map(ax_e)
ax_e.set_title(TITLE_E, fontsize=FS_MAP_TITLE, loc='left', pad=1.5)
add_panel_label(ax_e, 'e', True)
cax_e = fig.add_axes(CBAR_E)
cbar_e = fig.colorbar(im_e, cax=cax_e, orientation='vertical')
cbar_e.ax.tick_params(labelsize=FS_CBAR_TICK, width=0.45, length=2.0, pad=1.5)
cbar_e.outline.set_linewidth(0.45)
cbar_e.locator = MaxNLocator(nbins=4)
cbar_e.update_ticks()
ax_f = fig.add_axes(RECT_F)
ax_f.plot(x_wave, pdf_wave_degree, color=DEGREE_COLOR, linewidth=PDF_LINEWIDTH, label=f'Top 15% degree', zorder=3)
ax_f.plot(x_wave, pdf_wave_all, color=ALL_COLOR, linewidth=PDF_LINEWIDTH, label='All longitudes', zorder=2)
ax_f.set_xlabel('Mean meridional wind anomaly', fontsize=FS_AXIS_LABEL, labelpad=2.0)
ax_f.set_ylabel('PDF', fontsize=FS_AXIS_LABEL, labelpad=2.5)
setup_pdf(ax_f)
ymax_f = max(np.nanmax(pdf_wave_degree), np.nanmax(pdf_wave_all))
ax_f.set_ylim(0, ymax_f * PDF_Y_MARGIN)
add_panel_label(ax_f, 'f', False)
ax_f.legend(loc=LEGEND_LOC, frameon=False, fontsize=FS_LEGEND, handlelength=LEGEND_HANDLE_LENGTH, handletextpad=LEGEND_HANDLE_TEXTPAD, labelspacing=LEGEND_LABEL_SPACING, borderaxespad=LEGEND_BORDERAXESPAD)
for ax in [ax_b, ax_d, ax_f]:
    ax.set_facecolor('white')
fig.patch.set_facecolor('white')
if SAVE_FIG:
    plt.savefig(SAVE_PATH, dpi=600, facecolor='white')
plt.show()
print('\n\n========================================')
print('FINAL SUMMARY')
print('========================================')
print('Valid nodes =', len(rossby_pair))
print('\nMAP:')
print(f'in top 15% wave-7 component', np.sum(map_rossby_pos_mask))
print(f'c negative Rossby bottom {MAP_ROSSBY_NEG_PERCENT:g}% =', np.sum(map_rossby_neg_mask))
print(f'e out-degree top {MAP_DEGREE_TOP_PERCENT:g}% =', np.sum(map_out_high_mask))
print(f'e in-degree top {MAP_DEGREE_TOP_PERCENT:g}% =', np.sum(map_in_high_mask))
print('\nPDF: longitude-mean samples')
print(f'b positive Rossby longitude-mean top {PDF_ROSSBY_POS_PERCENT:g}% =', len(out_pdf_selected))
print(f'd negative Rossby longitude-mean bottom {PDF_ROSSBY_NEG_PERCENT:g}% =', len(in_pdf_selected))
print(f'f total-degree longitude-mean top {PDF_DEGREE_TOP_PERCENT:g}% =', len(rossby_pdf_degree))
print('\nStatistical tests:')
print(f'b: positive Rossby longitude mean -> mean Out-degree, p = {p_out:.6g}')
print(f'd: negative Rossby longitude mean -> mean In-degree, p = {p_in:.6g}')
print(f'f: high mean total-degree longitudes vs remaining longitudes, p = {p_wave_degree:.6g}')
