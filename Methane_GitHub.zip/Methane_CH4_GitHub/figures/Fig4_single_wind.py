"""
Created on Sat Sep  5 13:45:42 2026

@author: yuping
"""
'\nCreated on Sat Sep  5 09:56:40 2026\n\n@author: yuping\n'
'\nComposite methane-network figure\n\n布局：\n- 左侧一列：a/b/c 三个 1000 条 HYSPLIT 随机轨迹密度图 + network pathway\n- 右上：g 北极视角地形 / 850 hPa 风场 / 三条 network pathway / particle trajectory\n- 右下：d/e/f 三个 path-level null PDF 显著性检验图\n\n运行前提：\n1. 当前 Python / Notebook 环境中最好已有 dg, lons, lats。\n2. 如果没有 lons/lats，本程序会尝试从 node_longitudes.npy / node_latitudes.npy 读取北半球节点坐标。\n3. 如果没有 dg，但当前环境有 ConstructDG 函数，本程序会尝试自动运行 dg = ConstructDG(True, 1000)。\n4. 所有路径和画图参数都集中在前面的参数区，可直接修改。\n'
import os
from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.patheffects as pe
import matplotlib.colors as mcolors
import matplotlib.path as mpath
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, Patch
from matplotlib.markers import MarkerStyle
from matplotlib.transforms import Affine2D
from matplotlib.path import Path as MplPath
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.util import add_cyclic_point
import networkx as nx
from scipy.ndimage import gaussian_filter
from scipy.stats import gaussian_kde
from pyproj import CRS, Transformer, Geod
from shapely.geometry import LineString
from shapely.ops import transform as shapely_transform
SAVE_FIG = True
SHOW_FIG = True
OUT_FIG = 'outputs/figures/figure_007.jpg'
OUT_FIG_PDF = 'outputs/figures/figure_008.pdf'
SAVE_DPI = 400
FIG_DPI = 300
FIG_WIDTH = 12.0
FIG_HEIGHT = 7.2
RECT_A = [0.01, 0.735, 0.36, 0.2]
RECT_B = [0.042, 0.412, 0.295, 0.207]
RECT_C = [0.01, 0.087, 0.36, 0.2]
CBAR_A = [0.0635, 0.674, 0.245, 0.015]
CBAR_B = [0.06, 0.366, 0.245, 0.015]
CBAR_C = [0.0638, 0.024, 0.245, 0.0165]
RECT_D_POLAR = [0.35, 0.36, 0.47, 0.58]
CBAR_D_POLAR = [0.82, 0.388, 0.015, 0.25]
RECT_E = [0.395, 0.077, 0.155, 0.188]
RECT_F = [0.597, 0.077, 0.155, 0.188]
RECT_G = [0.8, 0.077, 0.155, 0.188]
FONT_FAMILY = 'Arial'
FONT_SCALE = 1.18
FONT_SCALE1 = 1.2
FS_BASE = 15 * FONT_SCALE
FS_PANEL_MAIN = 21 * FONT_SCALE1
mpl.rcParams.update({'font.family': FONT_FAMILY, 'font.size': FS_BASE, 'axes.unicode_minus': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white', 'xtick.direction': 'out', 'ytick.direction': 'out'})
AUTO_BUILD_DG = True
CONSTRUCT_DG_USE_WEIGHT = True
CONSTRUCT_DG_TAU = 1000
NODE_LON_FILE = 'data/node_longitudes.npy'
NODE_LAT_FILE = 'data/node_latitudes.npy'
NODE_LAT_MIN = -5
NODE_LAT_MAX = 90
PRINT_DEBUG = True
SHOW_RANDOM_TRAJ_LINES = False
SHOW_TRAJ_START = True
SHOW_NETWORK_ENDPOINTS = True
SHOW_NETWORK_ARROWS = True
SHOW_ABC_COLORBAR = True
FS_ABC_TICK = 15 * FONT_SCALE
FS_ABC_CBAR_LABEL = 15 * FONT_SCALE
FS_ABC_CBAR_TICK = 15 * FONT_SCALE
FS_ABC_PANEL = 21 * FONT_SCALE1
LW_ABC_AXIS = 0.7
LW_ABC_COAST = 0.42
LW_ABC_BORDER = 0.22
LW_ABC_GRID = 0.28
SHOW_ABC_BORDER = False
CORRIDOR_HALF_WIDTH_KM = 600.0
CORRIDOR_WIDTH_KM = 2.0 * CORRIDOR_HALF_WIDTH_KM
CORRIDOR_DENSIFY_KM = 80.0
LW_CORRIDOR_BOUNDARY = 1.5
ALPHA_CORRIDOR = 0.42
GEOD = Geod(ellps='WGS84')
LW_NETWORK = 2.0
LW_CORRIDOR = 22.0
LW_NETWORK_WHITE = 5.4
NETWORK_ARROW_N = 6
NETWORK_ARROW_MS = 17.0
LW_NETWORK_ARROW = 3.2
LW_NETWORK_ARROW_WHITE = 5.0
NETWORK_ARROW_FRAC = 0.62
TRAJ_START_SIZE = 0
NETWORK_START_SIZE = 120
NETWORK_END_SIZE = 170
MARKER_EDGE_LW = 1.05
MARKER_WHITE_LW = 2.0
DENSITY_SIGMA = 1.0
DENSITY_MASK_THRESHOLD = 0.001
DENSITY_VMIN = 0.0
DENSITY_VMAX = 0.025
DENSITY_TICKS = [0, 0.01, 0.02]
DENSITY_TICKLABELS = ['0', '0.01', '0.02']
COLOR_OCEAN = '#FBFCFD'
COLOR_LAND = '#FBFCFD'
COLOR_COAST = '#4F5B66'
COLOR_BORDER = '#A7AEB6'
COLOR_GRID = '#C9CFD5'
COLOR_RANDOM_TRAJ = '#2166AC'
COLOR_TRAJ_START = '#2166AC'
DENSITY_COLORS_A = ['#FFFFFF', '#F0F6FB', '#D9E8F3', '#B9D5E9', '#87B6D7', '#5793BE', '#4080AE', '#3674A4']
DENSITY_COLORS_B = ['#FFFFFF', '#FEF6F3', '#FAE4DD', '#F4C9BA', '#E7A088', '#D57659', '#BC4D32', '#A83D2B']
DENSITY_COLORS_C = ['#FFFFFF', '#F1EBF6', '#DFD2EA', '#C4ACD6', '#9F79BB', '#7C51A5', '#6A3D9A', '#5B2F86']
CMAP_DENSITY_A = mpl.colors.LinearSegmentedColormap.from_list('density_blue_reference', DENSITY_COLORS_A, N=256)
CMAP_DENSITY_B = mpl.colors.LinearSegmentedColormap.from_list('density_coral_reference', DENSITY_COLORS_B, N=256)
CMAP_DENSITY_C = mpl.colors.LinearSegmentedColormap.from_list('density_purple_reference', DENSITY_COLORS_C, N=256)
CMAP_DENSITY_A.set_bad((1, 1, 1, 0))
CMAP_DENSITY_B.set_bad((1, 1, 1, 0))
CMAP_DENSITY_C.set_bad((1, 1, 1, 0))
COLOR_NETWORK_MAIN = '#ED6E69'
COLOR_CORRIDOR_FILL = '#D3D3D3'
COLOR_CORRIDOR_EDGE = 'k'
COLOR_NETWORK = COLOR_NETWORK_MAIN
COLOR_CORRIDOR = COLOR_CORRIDOR_FILL
COLOR_NETWORK_MARKER_FACE = '#FFF8E7'
COLOR_NETWORK_MARKER_EDGE = COLOR_NETWORK
PANELS = [{'label': 'a', 'name': 'Europe to China', 'root_dir': Path('outputs/trajectory_tests/route_a'), 'lon_min': 0, 'lon_max': 160, 'lat_min': 20, 'lat_max': 85, 'dlon': 1.0, 'dlat': 1.0, 'lon_mode': '0_360', 'plot_center_lon': 80, 'map_projection': ccrs.PlateCarree(central_longitude=100), 'data_projection': ccrs.PlateCarree(), 'density_cmap': CMAP_DENSITY_A, 'path_begin': 1342, 'path_end': 1663, 'flip_path': True, 'arrow_n': 5, 'panel_label_x': -0.075, 'panel_label_y': 1.2}, {'label': 'b', 'name': 'China to North America', 'root_dir': Path('outputs/trajectory_tests/route_b'), 'lon_min': 90, 'lon_max': 300, 'lat_min': 10, 'lat_max': 85, 'dlon': 1.0, 'dlat': 1.0, 'lon_mode': '0_360', 'plot_center_lon': 195, 'map_projection': ccrs.PlateCarree(central_longitude=180), 'data_projection': ccrs.PlateCarree(), 'density_cmap': CMAP_DENSITY_B, 'path_begin': 1259, 'path_end': 1195, 'flip_path': True, 'arrow_n': 8, 'panel_label_x': -0.075, 'panel_label_y': 1.2}, {'label': 'c', 'name': 'North America to Europe', 'root_dir': Path('outputs/trajectory_tests/route_c'), 'lon_min': -120, 'lon_max': 90, 'lat_min': 0, 'lat_max': 85, 'dlon': 1.0, 'dlat': 1.0, 'lon_mode': 'minus180_180', 'plot_center_lon': -15, 'map_projection': ccrs.PlateCarree(central_longitude=-30), 'data_projection': ccrs.PlateCarree(), 'density_cmap': CMAP_DENSITY_C, 'path_begin': 1740, 'path_end': 1406, 'flip_path': True, 'arrow_n': 6, 'panel_label_x': -0.075, 'panel_label_y': 1.2}]
ETOPO_FILE = 'data/topography.nc'
U_FILE = 'data/meteorology/zonal_wind_monthly.nc'
V_FILE = 'data/meteorology/meridional_wind_monthly.nc'
TRAJ_FILE_EUROPE_TO_CHINA = 'data/trajectories/trajectory_route_a.npz'
TRAJ_FILE_CHINA_TO_US = 'data/trajectories/trajectory_route_b.npz'
TRAJ_FILE_US_TO_EUROPE = 'data/trajectories/trajectory_route_c.npz'
POLAR_CENTRAL_LONGITUDE = 180
MAP_MIN_LAT = 25
MAP_MAX_LAT = 90
TERRAIN_STEP = 5
ELEV_VMIN = -6.0
ELEV_VMAX = 6.5
TERRAIN_ALPHA = 1.0
WIND_LEVEL = 850
WIND_TIME_START = '2010-01-01'
WIND_TIME_END = '2020-12-31'
WIND_SKIP = 4
WIND_SCALE = 80
WIND_WIDTH = 0.0038
WIND_HEADWIDTH = 7
WIND_HEADLENGTH = 4.5
WIND_HEADAXISLENGTH = 4.0
WIND_ALPHA = 1.0
WIND_SPEED_CMAP = mpl.colors.LinearSegmentedColormap.from_list('YlGnBu_r_cut', plt.get_cmap('YlGnBu_r')(np.linspace(0.0, 0.82, 256)))
WIND_SPEED_ALPHA = 1.0
WIND_SPEED_PERCENTILE_MAX = 98
WIND_SPEED_VMIN = 0.0
SHOW_QUIVER_KEY = True
QUIVER_KEY_U = 10
QUIVER_KEY_LABEL = '10 m s$^{-1}$'
QUIVER_KEY_X = 0.78
QUIVER_KEY_Y = 0.392
BUFFER_KM = 600.0
SHOW_POLAR_START_END_MARKERS = True
SHOW_POLAR_PANEL_LABEL = True
POLAR_PANEL_LABEL = 'd'
FS_POLAR_CBAR_LABEL = 15 * FONT_SCALE
FS_POLAR_CBAR_TICK = 15 * FONT_SCALE
FS_POLAR_QUIVER_KEY = 15 * FONT_SCALE
FS_POLAR_LEGEND = 14.2 * FONT_SCALE
FS_POLAR_PANEL = 21 * FONT_SCALE1
LW_POLAR_COAST = 0.62
LW_POLAR_GRID = 0.28
NETWORK_BUFFER_ALPHA = 0.42
NETWORK_ARROW_LW = 1.6
NETWORK_ARROW_MS = 16
NETWORK_ARROW_ALPHA = 0.86
NETWORK_ARROW_STROKE_LW = 3.2
TRAJ_LINE_LW = 1.7
TRAJ_LINE_STROKE_LW = 4.2
TRAJ_ARROW_LW = 3
TRAJ_ARROW_MS = 20
TRAJ_ARROW_STROKE_LW = 3.2
START_MARKER_SIZE = 120
END_MARKER_SIZE = 250
POLAR_MARKER_EDGE_LW = 0.8
POLAR_MARKER_STROKE_LW = 1.8
LEGEND_LINE_WIDTH = 2.2
LEGEND_PATCH_ALPHA = 0.45
COLOR_NETWORK_BUFFER_POLAR = '#EA8379'
COLOR_NETWORK_ARROW_POLAR = '#C9352B'
COLOR_TRAJ_POLAR = '#B291B5'
COLOR_POLAR_MARKER_FACE = '#E0E0E0'
COLOR_POLAR_MARKER_EDGE = 'black'
COLOR_POLAR_COAST = 'black'
COLOR_POLAR_GRID = 'gray'
COLOR_WIND = 'white'
USE_ROUTE_SPECIFIC_COLORS = False
ROUTE_COLORS = {'Europe to China': {'network_buffer': '#EA8379', 'network_arrow': '#C9352B', 'trajectory': '#66529F'}, 'China to North America': {'network_buffer': '#EA8379', 'network_arrow': '#C9352B', 'trajectory': '#66529F'}, 'North America to Europe': {'network_buffer': '#EA8379', 'network_arrow': '#C9352B', 'trajectory': '#66529F'}}
ROUTES = [{'name': 'Europe to China', 'start_node': 1342, 'end_node': 1663, 'traj_file': TRAJ_FILE_EUROPE_TO_CHINA, 'center_lon_for_buffer': 110, 'n_traj_arrows': 4, 'n_network_arrows': 5}, {'name': 'China to North America', 'start_node': 1259, 'end_node': 1195, 'traj_file': TRAJ_FILE_CHINA_TO_US, 'center_lon_for_buffer': 190, 'n_traj_arrows': 6, 'n_network_arrows': 6}, {'name': 'North America to Europe', 'start_node': 1740, 'end_node': 1406, 'traj_file': TRAJ_FILE_US_TO_EUROPE, 'center_lon_for_buffer': 1, 'n_traj_arrows': 6, 'n_network_arrows': 6}]
PDF_DIR_E = Path('outputs/trajectory_tests/route_a')
PDF_DIR_F = Path('outputs/trajectory_tests/route_b')
PDF_DIR_G = Path('outputs/trajectory_tests/route_c')
PDF_REAL_FILE_E = PDF_DIR_E / 'observed_overlap_a.csv'
PDF_NULL_FILE_E = PDF_DIR_E / 'surrogate_overlap.csv'
PDF_REAL_FILE_F = PDF_DIR_F / 'trajectory_overlap_a.csv'
PDF_NULL_FILE_F = PDF_DIR_F / 'surrogate_overlap.csv'
PDF_REAL_FILE_G = PDF_DIR_G / 'trajectory_overlap_b.csv'
PDF_NULL_FILE_G = PDF_DIR_G / 'surrogate_overlap.csv'
PDF_XLIM_E = (0.3, 0.55)
PDF_XLIM_F = (0.2, 0.7)
PDF_XLIM_G = (0.2, 0.55)
PDF_THRESHOLD_E = 90
PDF_THRESHOLD_F = 89
PDF_THRESHOLD_G = 90
PDF_BW_E = 0.6
PDF_BW_F = 0.55
PDF_BW_G = 0.62
FS_PDF_LABEL = 15 * FONT_SCALE
FS_PDF_TICK = 15 * FONT_SCALE
FS_PDF_LEGEND = 10 * FONT_SCALE
FS_PDF_LINE_TEXT = 13 * FONT_SCALE
FS_PDF_PANEL = 21 * FONT_SCALE1
LW_PDF_CURVE = 1.8
LW_PDF_VLINE = 1.05
COLOR_PDF_NULL = '#2f3e46'
COLOR_PDF_FILL = '#8a9496'
COLOR_PDF_REAL = '#E53528'
COLOR_PDF_THRESHOLD = '#193E8F'
COLOR_PDF_MEAN = '#7A7A7A'
PDF_FILL_ALPHA = 0.23
PDF_TAIL_ALPHA = 0.16
SHOW_EFG_SHARED_LEGEND = True
EFG_LEGEND_X = 0.65
EFG_LEGEND_Y = -0.07
EFG_LEGEND_NCOL = 3
FS_EFG_LEGEND = 14.5 * FONT_SCALE
EFG_LEGEND_HANDLELENGTH = 1.6
EFG_LEGEND_COLUMN_SPACING = 0.9

def normalize_lon(lon, lon_mode):
    lon = np.asarray(lon, dtype=float)
    if lon_mode == '0_360':
        lon = np.where(lon < 0, lon + 360, lon)
    elif lon_mode == 'minus180_180':
        lon = np.where(lon > 180, lon - 360, lon)
    return lon

def wrap_lon_to_center(lon, center):
    lon = np.asarray(lon, dtype=float)
    return center + ((lon - center + 180) % 360 - 180)

def wrap_lon_to_panel(lon, panel_cfg):
    lon = normalize_lon(lon, panel_cfg['lon_mode'])
    lon = wrap_lon_to_center(lon, panel_cfg['plot_center_lon'])
    return lon

def is_inside_extent(lon, lat, panel_cfg, margin=3.0):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    return np.isfinite(lon) & np.isfinite(lat) & (lon >= panel_cfg['lon_min'] - margin) & (lon <= panel_cfg['lon_max'] + margin) & (lat >= panel_cfg['lat_min'] - margin) & (lat <= panel_cfg['lat_max'] + margin)

def haversine_km(lon1, lat1, lon2, lat2):
    R = 6371.0
    lon1 = np.asarray(lon1, dtype=float)
    lat1 = np.asarray(lat1, dtype=float)
    lon2 = np.asarray(lon2, dtype=float)
    lat2 = np.asarray(lat2, dtype=float)
    dlon = lon2 - lon1
    dlon = (dlon + 180) % 360 - 180
    lon1_rad = np.radians(lon1)
    lat1_rad = np.radians(lat1)
    dlon_rad = np.radians(dlon)
    dlat_rad = np.radians(lat2 - lat1)
    a = np.sin(dlat_rad / 2.0) ** 2 + np.cos(lat1_rad) * np.cos(np.radians(lat2)) * np.sin(dlon_rad / 2.0) ** 2
    return R * 2 * np.arcsin(np.sqrt(a))

def split_path_by_jump(lon, lat, max_jump=120):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    valid = np.isfinite(lon) & np.isfinite(lat)
    lon = lon[valid]
    lat = lat[valid]
    if len(lon) < 2:
        return []
    jumps = np.where(np.abs(np.diff(lon)) > max_jump)[0]
    segments = []
    start = 0
    for j in jumps:
        end = j + 1
        if end - start >= 2:
            segments.append((lon[start:end], lat[start:end]))
        start = end
    if len(lon) - start >= 2:
        segments.append((lon[start:], lat[start:]))
    return segments

def get_network_graph():
    g = globals()
    if 'dg' in g:
        DG = g['dg']
    elif AUTO_BUILD_DG and 'ConstructDG' in g:
        print(f'当前环境没有 dg，自动运行：dg = ConstructDG({CONSTRUCT_DG_USE_WEIGHT}, {CONSTRUCT_DG_TAU})')
        DG = g['ConstructDG'](CONSTRUCT_DG_USE_WEIGHT, CONSTRUCT_DG_TAU)
        globals()['dg'] = DG
    else:
        raise RuntimeError('当前环境没有 dg，也没有 ConstructDG 函数。\n请先运行你原来的气候网络构建代码，确保已有 dg。')
    print('\n已读取 dg')
    print('dg 节点数:', DG.number_of_nodes())
    print('dg 边数:', DG.number_of_edges())
    return DG

def get_node_lons_lats():
    g = globals()
    if 'lons' in g and 'lats' in g:
        node_lons = np.asarray(g['lons'], dtype=float).reshape(-1)
        node_lats = np.asarray(g['lats'], dtype=float).reshape(-1)
        print('已使用当前环境中的 lons/lats。')
        return (node_lons, node_lats)
    if os.path.exists(NODE_LON_FILE) and os.path.exists(NODE_LAT_FILE):
        lons_all = np.load(NODE_LON_FILE)
        lats_all = np.load(NODE_LAT_FILE)
        mask = (lats_all >= NODE_LAT_MIN) & (lats_all <= NODE_LAT_MAX)
        node_lons = lons_all[mask]
        node_lats = lats_all[mask]
        globals()['lons'] = node_lons
        globals()['lats'] = node_lats
        print('当前环境没有 lons/lats，已从 node-longitude/node-latitude 文件读取北半球节点。')
        print('北半球节点数:', len(node_lons))
        return (node_lons, node_lats)
    raise RuntimeError('当前环境没有 lons/lats，且无法从 NODE_LON_FILE / NODE_LAT_FILE 读取。\n请先运行你原来的节点经纬度读取代码。')

def read_hysplit_tdump_robust(file_path, lon_mode):
    numeric_rows = []
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                vals = [float(x) for x in parts]
            except ValueError:
                continue
            numeric_rows.append(vals)
    if len(numeric_rows) == 0:
        return []
    candidate_pairs = [(9, 10), (8, 9), (10, 11)]
    best_pair = None
    best_count = 0
    for lat_idx, lon_idx in candidate_pairs:
        count = 0
        for vals in numeric_rows:
            if len(vals) <= max(lat_idx, lon_idx):
                continue
            lat = vals[lat_idx]
            lon = vals[lon_idx]
            if -90 <= lat <= 90 and -360 <= lon <= 360:
                count += 1
        if count > best_count:
            best_count = count
            best_pair = (lat_idx, lon_idx)
    if best_pair is None or best_count < 2:
        return []
    lat_idx, lon_idx = best_pair
    traj_dict = {}
    for vals in numeric_rows:
        if len(vals) <= max(lat_idx, lon_idx):
            continue
        lat = vals[lat_idx]
        lon = vals[lon_idx]
        if not (-90 <= lat <= 90 and -360 <= lon <= 360):
            continue
        lon = normalize_lon(lon, lon_mode)
        try:
            traj_id = int(vals[0])
        except Exception:
            traj_id = 1
        traj_dict.setdefault(traj_id, {'lon': [], 'lat': []})
        traj_dict[traj_id]['lon'].append(lon)
        traj_dict[traj_id]['lat'].append(lat)
    trajectories = []
    for _, d in traj_dict.items():
        traj_lon = np.asarray(d['lon'], dtype=float)
        traj_lat = np.asarray(d['lat'], dtype=float)
        if len(traj_lon) > 1:
            trajectories.append((traj_lon, traj_lat))
    return trajectories

def compute_passage_probability(panel_cfg):
    root_dir = panel_cfg['root_dir']
    lon_mode = panel_cfg['lon_mode']
    lon_min = panel_cfg['lon_min']
    lon_max = panel_cfg['lon_max']
    lat_min = panel_cfg['lat_min']
    lat_max = panel_cfg['lat_max']
    dlon = panel_cfg['dlon']
    dlat = panel_cfg['dlat']
    tdump_files = sorted([p for p in root_dir.rglob('tdump_fwd*') if p.is_file()])
    print('\n====================================================')
    print(f"[{panel_cfg['label']}] {panel_cfg['name']}")
    print(f'root_dir = {root_dir}')
    print(f'找到 tdump 文件数: {len(tdump_files)}')
    print('====================================================')
    if len(tdump_files) == 0:
        raise FileNotFoundError(f"[{panel_cfg['label']}] 没有找到 tdump_fwd* 文件，请检查路径：{root_dir}")
    all_trajs = []
    for i, fp in enumerate(tdump_files):
        if PRINT_DEBUG and i % 100 == 0:
            print(f"[{panel_cfg['label']}] 读取文件 {i}/{len(tdump_files)}: {fp.name}")
        all_trajs.extend(read_hysplit_tdump_robust(fp, lon_mode=lon_mode))
    print(f"[{panel_cfg['label']}] 成功解析轨迹数: {len(all_trajs)}")
    if len(all_trajs) == 0:
        raise ValueError(f"[{panel_cfg['label']}] 没有解析到有效轨迹，请检查 tdump 列结构。")
    lon_edges = np.arange(lon_min, lon_max + dlon, dlon)
    lat_edges = np.arange(lat_min, lat_max + dlat, dlat)
    nlon = len(lon_edges) - 1
    nlat = len(lat_edges) - 1
    visit_count = np.zeros((nlon, nlat), dtype=float)
    for traj_lon, traj_lat in all_trajs:
        traj_lon = normalize_lon(traj_lon, lon_mode)
        traj_lat = np.asarray(traj_lat, dtype=float)
        valid = np.isfinite(traj_lon) & np.isfinite(traj_lat) & (traj_lon >= lon_edges[0]) & (traj_lon <= lon_edges[-1]) & (traj_lat >= lat_edges[0]) & (traj_lat <= lat_edges[-1])
        lon_v = traj_lon[valid]
        lat_v = traj_lat[valid]
        if len(lon_v) == 0:
            continue
        lon_idx = np.digitize(lon_v, lon_edges) - 1
        lat_idx = np.digitize(lat_v, lat_edges) - 1
        good = (lon_idx >= 0) & (lon_idx < nlon) & (lat_idx >= 0) & (lat_idx < nlat)
        unique_cells = set(zip(lon_idx[good], lat_idx[good]))
        for ii, jj in unique_cells:
            visit_count[ii, jj] += 1
    P = visit_count / len(all_trajs)
    P_smooth = gaussian_filter(P, sigma=DENSITY_SIGMA)
    P_plot = np.ma.masked_where(P_smooth.T <= DENSITY_MASK_THRESHOLD, P_smooth.T)
    Lon, Lat = np.meshgrid(lon_edges, lat_edges)
    print(f"[{panel_cfg['label']}] 最大轨迹通过概率: {np.nanmax(P_smooth):.6f}")
    return {'all_trajs': all_trajs, 'Lon': Lon, 'Lat': Lat, 'P_plot': P_plot, 'P_smooth': P_smooth}

def add_coord_candidate(candidates, name, node_lons, node_lats, max_node):
    try:
        node_lons = np.asarray(node_lons, dtype=float).reshape(-1)
        node_lats = np.asarray(node_lats, dtype=float).reshape(-1)
    except Exception:
        return
    if len(node_lons) <= max_node or len(node_lats) <= max_node:
        return
    if np.sum(np.isfinite(node_lons)) <= max_node or np.sum(np.isfinite(node_lats)) <= max_node:
        return
    candidates.append({'name': name, 'lons': node_lons, 'lats': node_lats})

def evaluate_coord_candidate(candidate, DG):
    node_lons = candidate['lons']
    node_lats = candidate['lats']
    total_visible = 0
    min_visible = 10 ** 9
    panel_info = []
    for cfg in PANELS:
        try:
            path_in = nx.dijkstra_path(DG, cfg['path_begin'], cfg['path_end'])
        except Exception:
            panel_info.append({'label': cfg['label'], 'visible': 0, 'n': 0, 'lon_min': np.nan, 'lon_max': np.nan, 'lat_min': np.nan, 'lat_max': np.nan})
            min_visible = 0
            continue
        lon0 = np.asarray([node_lons[k] for k in path_in], dtype=float)
        lat0 = np.asarray([node_lats[k] for k in path_in], dtype=float)
        lon0 = wrap_lon_to_panel(lon0, cfg)
        inside = is_inside_extent(lon0, lat0, cfg, margin=5.0)
        visible = int(np.sum(inside))
        total_visible += visible
        min_visible = min(min_visible, visible)
        panel_info.append({'label': cfg['label'], 'visible': visible, 'n': len(path_in), 'lon_min': np.nanmin(lon0), 'lon_max': np.nanmax(lon0), 'lat_min': np.nanmin(lat0), 'lat_max': np.nanmax(lat0)})
    return {'name': candidate['name'], 'score': total_visible, 'min_visible': min_visible, 'panel_info': panel_info}

def choose_best_node_coordinates(DG, base_lons=None, base_lats=None):
    g = globals()
    max_node = max((max(cfg['path_begin'], cfg['path_end']) for cfg in PANELS))
    candidates = []
    if base_lons is not None and base_lats is not None:
        add_coord_candidate(candidates, 'base lons/lats', base_lons, base_lats, max_node)
    if 'lons' in g and 'lats' in g:
        add_coord_candidate(candidates, 'global lons/lats', g['lons'], g['lats'], max_node)
    if 'lattic' in g:
        lattic_arr = np.asarray(g['lattic'], dtype=float)
        if lattic_arr.ndim == 2 and lattic_arr.shape[1] >= 2:
            add_coord_candidate(candidates, 'lattic[:,1]=lon, lattic[:,0]=lat', lattic_arr[:, 1], lattic_arr[:, 0], max_node)
            add_coord_candidate(candidates, 'lattic[:,0]=lon, lattic[:,1]=lat', lattic_arr[:, 0], lattic_arr[:, 1], max_node)
    if len(candidates) == 0:
        raise RuntimeError('没有找到可用的 network 节点经纬度坐标。')
    evals = []
    print('\n================ 坐标源自动检测 ================')
    for cand in candidates:
        ev = evaluate_coord_candidate(cand, DG)
        evals.append((ev, cand))
        print(f"\n候选坐标源: {ev['name']}")
        print('总可见路径点数:', ev['score'])
        print('三个 panel 中最少可见路径点数:', ev['min_visible'])
        for info in ev['panel_info']:
            print(f"  [{info['label']}] visible {info['visible']}/{info['n']} | lon=({info['lon_min']:.2f}, {info['lon_max']:.2f}) | lat=({info['lat_min']:.2f}, {info['lat_max']:.2f})")
    evals_sorted = sorted(evals, key=lambda x: (x[0]['min_visible'], x[0]['score']), reverse=True)
    best_eval, best_cand = evals_sorted[0]
    print('\n最终选择坐标源:', best_eval['name'])
    print('最终总可见路径点数:', best_eval['score'])
    print('================================================\n')
    if best_eval['min_visible'] < 2:
        raise RuntimeError('自动检测后，至少有一条路径几乎不在对应 panel 范围内。请检查 lons/lats 或 lattic。')
    return (np.asarray(best_cand['lons'], dtype=float), np.asarray(best_cand['lats'], dtype=float), best_eval['name'])

def get_network_path_for_panel(panel_cfg, DG, node_lons, node_lats):
    begining_point = panel_cfg['path_begin']
    ending_point = panel_cfg['path_end']
    path_in = nx.dijkstra_path(DG, begining_point, ending_point)
    lon_path_orig = np.asarray([node_lons[k] for k in path_in], dtype=float)
    lat_path_orig = np.asarray([node_lats[k] for k in path_in], dtype=float)
    if panel_cfg.get('flip_path', True):
        lon_path = np.flip(lon_path_orig)
        lat_path = np.flip(lat_path_orig)
    else:
        lon_path = lon_path_orig
        lat_path = lat_path_orig
    lon_path = wrap_lon_to_panel(lon_path, panel_cfg)
    valid = np.isfinite(lon_path) & np.isfinite(lat_path)
    lon_path = lon_path[valid]
    lat_path = lat_path[valid]
    if PRINT_DEBUG:
        inside = is_inside_extent(lon_path, lat_path, panel_cfg, margin=5.0)
        print('\n----------------------------------------')
        print(f"[{panel_cfg['label']}] {panel_cfg['name']}")
        print('Dijkstra:', begining_point, '->', ending_point)
        print('path node number:', len(path_in))
        print('lon range after wrapping:', np.nanmin(lon_path), np.nanmax(lon_path))
        print('lat range:', np.nanmin(lat_path), np.nanmax(lat_path))
        print('visible path points:', int(np.sum(inside)), '/', len(lon_path))
        print('----------------------------------------\n')
    return (lon_path, lat_path, path_in)

def lon_to_pm180(lon):
    lon = np.asarray(lon, dtype=float)
    return (lon + 180.0) % 360.0 - 180.0

def densify_geodesic_path(lon, lat, max_step_km=80.0):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    valid = np.isfinite(lon) & np.isfinite(lat)
    lon = lon[valid]
    lat = lat[valid]
    if len(lon) < 2:
        return (lon, lat)
    lon_geo = lon_to_pm180(lon)
    out_lon = [float(lon_geo[0])]
    out_lat = [float(lat[0])]
    max_step_m = float(max_step_km) * 1000.0
    for i in range(len(lon_geo) - 1):
        lon1 = float(lon_geo[i])
        lat1 = float(lat[i])
        lon2 = float(lon_geo[i + 1])
        lat2 = float(lat[i + 1])
        _, _, dist_m = GEOD.inv(lon1, lat1, lon2, lat2)
        if not np.isfinite(dist_m) or dist_m <= 0:
            continue
        n_seg = max(1, int(np.ceil(dist_m / max_step_m)))
        n_insert = max(0, n_seg - 1)
        if n_insert > 0:
            for x, y in GEOD.npts(lon1, lat1, lon2, lat2, n_insert):
                out_lon.append(float(x))
                out_lat.append(float(y))
        out_lon.append(lon2)
        out_lat.append(lat2)
    return (np.asarray(out_lon), np.asarray(out_lat))

def circular_mean_azimuth_deg(az1, az2):
    a1 = np.radians(float(az1))
    a2 = np.radians(float(az2))
    x = np.sin(a1) + np.sin(a2)
    y = np.cos(a1) + np.cos(a2)
    if np.hypot(x, y) < 1e-12:
        return float(az2)
    return float(np.degrees(np.arctan2(x, y)))

def get_path_tangent_azimuths(lon, lat):
    lon = lon_to_pm180(lon)
    lat = np.asarray(lat, dtype=float)
    n = len(lon)
    if n < 2:
        return np.asarray([], dtype=float)
    tangents = np.empty(n, dtype=float)
    seg_az = np.empty(n - 1, dtype=float)
    for i in range(n - 1):
        az12, _, _ = GEOD.inv(float(lon[i]), float(lat[i]), float(lon[i + 1]), float(lat[i + 1]))
        seg_az[i] = az12
    tangents[0] = seg_az[0]
    tangents[-1] = seg_az[-1]
    for i in range(1, n - 1):
        tangents[i] = circular_mean_azimuth_deg(seg_az[i - 1], seg_az[i])
    return tangents

def make_round_geodesic_cap(lon0, lat0, az_start, az_end, radius_km, n=24):
    az_start = float(az_start)
    az_end = float(az_end)
    while az_end <= az_start:
        az_end += 360.0
    azimuths = np.linspace(az_start, az_end, int(n))
    cap_lon = []
    cap_lat = []
    for az in azimuths:
        x, y, _ = GEOD.fwd(float(lon0), float(lat0), float(az), float(radius_km) * 1000.0)
        cap_lon.append(x)
        cap_lat.append(y)
    return (np.asarray(cap_lon), np.asarray(cap_lat))

def build_abc_geodesic_corridor_polygon(seg_lon, seg_lat, panel_cfg, total_width_km=1200.0, densify_km=80.0):
    seg_lon = np.asarray(seg_lon, dtype=float)
    seg_lat = np.asarray(seg_lat, dtype=float)
    valid = np.isfinite(seg_lon) & np.isfinite(seg_lat)
    seg_lon = seg_lon[valid]
    seg_lat = seg_lat[valid]
    if len(seg_lon) < 2:
        return None
    dense_lon, dense_lat = densify_geodesic_path(seg_lon, seg_lat, max_step_km=densify_km)
    if len(dense_lon) < 2:
        return None
    dense_lon_geo = lon_to_pm180(dense_lon)
    tangent_az = get_path_tangent_azimuths(dense_lon_geo, dense_lat)
    half_width_km = float(total_width_km) / 2.0
    half_width_m = half_width_km * 1000.0
    left_lon, left_lat = ([], [])
    right_lon, right_lat = ([], [])
    for x, y, az in zip(dense_lon_geo, dense_lat, tangent_az):
        xl, yl, _ = GEOD.fwd(float(x), float(y), float(az - 90.0), half_width_m)
        xr, yr, _ = GEOD.fwd(float(x), float(y), float(az + 90.0), half_width_m)
        left_lon.append(xl)
        left_lat.append(yl)
        right_lon.append(xr)
        right_lat.append(yr)
    left_lon = np.asarray(left_lon)
    left_lat = np.asarray(left_lat)
    right_lon = np.asarray(right_lon)
    right_lat = np.asarray(right_lat)
    end_cap_lon, end_cap_lat = make_round_geodesic_cap(dense_lon_geo[-1], dense_lat[-1], tangent_az[-1] - 90.0, tangent_az[-1] + 90.0, half_width_km, n=26)
    start_cap_lon, start_cap_lat = make_round_geodesic_cap(dense_lon_geo[0], dense_lat[0], tangent_az[0] + 90.0, tangent_az[0] + 270.0, half_width_km, n=26)
    poly_lon = np.concatenate([left_lon, end_cap_lon[1:-1], right_lon[::-1], start_cap_lon[1:-1]])
    poly_lat = np.concatenate([left_lat, end_cap_lat[1:-1], right_lat[::-1], start_cap_lat[1:-1]])
    poly_lon = wrap_lon_to_panel(poly_lon, panel_cfg)
    return {'poly_lon': poly_lon, 'poly_lat': poly_lat}

def add_abc_network_arrows(ax, seg_lon, seg_lat, data_proj, n_arrows=7):
    seg_lon = np.asarray(seg_lon, dtype=float)
    seg_lat = np.asarray(seg_lat, dtype=float)
    if len(seg_lon) < 2:
        return
    d = haversine_km(seg_lon[:-1], seg_lat[:-1], seg_lon[1:], seg_lat[1:])
    d = np.where(np.isfinite(d), d, 0.0)
    total_len = np.sum(d)
    if total_len <= 0:
        return
    auto_n = int(np.clip(total_len / 1200.0, 4, 10))
    n_arrows = max(n_arrows, auto_n)
    cumdist = np.concatenate([[0], np.cumsum(d)])
    target_dist = np.linspace(total_len * 0.1, total_len * 0.9, n_arrows)
    for td in target_dist:
        idx = np.searchsorted(cumdist, td) - 1
        idx = np.clip(idx, 0, len(seg_lon) - 2)
        x0 = seg_lon[idx]
        y0 = seg_lat[idx]
        x1 = seg_lon[idx + 1]
        y1 = seg_lat[idx + 1]
        if not np.all(np.isfinite([x0, y0, x1, y1])):
            continue
        dx = x1 - x0
        dx = (dx + 180) % 360 - 180
        dy = y1 - y0
        angle = np.degrees(np.arctan2(dy, dx))
        chevron_path = MplPath([[-0.55, -0.75], [0.45, 0.0], [-0.55, 0.75]], [MplPath.MOVETO, MplPath.LINETO, MplPath.LINETO])
        marker = MarkerStyle(chevron_path).transformed(Affine2D().rotate_deg(angle))
        ax.scatter(x0, y0, s=50, marker=marker, facecolors='none', edgecolors='white', linewidths=6, transform=data_proj, zorder=25.8, clip_on=True)
        ax.scatter(x0, y0, s=50, marker=marker, facecolors='none', edgecolors=COLOR_NETWORK, linewidths=3, transform=data_proj, zorder=26, clip_on=True)

def draw_abc_network_path(ax, lon_path, lat_path, panel_cfg):
    data_proj = panel_cfg['data_projection']
    lon_path = np.asarray(lon_path, dtype=float)
    lat_path = np.asarray(lat_path, dtype=float)
    valid = np.isfinite(lon_path) & np.isfinite(lat_path)
    lon_path = lon_path[valid]
    lat_path = lat_path[valid]
    if len(lon_path) < 2:
        return
    segments = split_path_by_jump(lon_path, lat_path, max_jump=120)
    for seg_lon, seg_lat in segments:
        if len(seg_lon) < 2:
            continue
        corridor = build_abc_geodesic_corridor_polygon(seg_lon, seg_lat, panel_cfg=panel_cfg, total_width_km=CORRIDOR_WIDTH_KM, densify_km=CORRIDOR_DENSIFY_KM)
        if corridor is None:
            continue
        corridor_patch = ax.fill(corridor['poly_lon'], corridor['poly_lat'], transform=data_proj, facecolor=COLOR_CORRIDOR, edgecolor='k', linewidth=LW_CORRIDOR_BOUNDARY, alpha=ALPHA_CORRIDOR, zorder=20, clip_on=True)
        for patch in corridor_patch:
            patch.set_clip_path(ax.patch)
        center_line, = ax.plot(seg_lon, seg_lat, transform=data_proj, linewidth=LW_NETWORK, color=COLOR_NETWORK, alpha=1.0, linestyle='-', solid_capstyle='round', solid_joinstyle='round', zorder=24, clip_on=True)
        center_line.set_clip_path(ax.patch)
        if SHOW_NETWORK_ARROWS:
            add_abc_network_arrows(ax, seg_lon, seg_lat, data_proj=data_proj, n_arrows=panel_cfg.get('arrow_n', NETWORK_ARROW_N))

def setup_abc_base_map(ax, panel_cfg):
    data_proj = panel_cfg['data_projection']
    ax.set_extent([panel_cfg['lon_min'], panel_cfg['lon_max'], panel_cfg['lat_min'], panel_cfg['lat_max']], crs=data_proj)
    ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
    ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
    ax.add_feature(cfeature.OCEAN.with_scale('50m'), facecolor=COLOR_OCEAN, edgecolor='none', zorder=0)
    ax.add_feature(cfeature.LAND.with_scale('50m'), facecolor=COLOR_LAND, edgecolor='none', zorder=1)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), linewidth=LW_ABC_COAST, edgecolor=COLOR_COAST, zorder=5)
    if SHOW_ABC_BORDER:
        ax.add_feature(cfeature.BORDERS.with_scale('50m'), linewidth=LW_ABC_BORDER, edgecolor=COLOR_BORDER, zorder=5)
    gl = ax.gridlines(crs=data_proj, draw_labels=True, linewidth=LW_ABC_GRID, color=COLOR_GRID, alpha=0.42, linestyle='--', zorder=1.5)
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': FS_ABC_TICK, 'color': 'black'}
    gl.ylabel_style = {'size': FS_ABC_TICK, 'color': 'black'}
    gl.ylocator = mticker.FixedLocator(np.arange(-90, 91, 20))
    gl.xlocator = mticker.FixedLocator(np.arange(-180, 361, 30))
    ax.spines['geo'].set_linewidth(LW_ABC_AXIS)
    ax.spines['geo'].set_edgecolor('#4D4D4D')

def draw_abc_panel(ax, panel_cfg, density_result, DG, node_lons, node_lats):
    data_proj = panel_cfg['data_projection']
    setup_abc_base_map(ax, panel_cfg)
    P_masked = np.ma.masked_where(density_result['P_plot'] <= 0, density_result['P_plot'])
    pcm = ax.pcolormesh(density_result['Lon'], density_result['Lat'], P_masked, cmap=panel_cfg['density_cmap'], shading='auto', vmin=DENSITY_VMIN, vmax=DENSITY_VMAX, transform=data_proj, zorder=2, rasterized=True)
    if SHOW_RANDOM_TRAJ_LINES:
        for traj_lon, traj_lat in density_result['all_trajs']:
            traj_lon = wrap_lon_to_panel(traj_lon, panel_cfg)
            ax.plot(traj_lon, traj_lat, color=COLOR_RANDOM_TRAJ, linewidth=0.32, alpha=0.05, transform=data_proj, zorder=3)
    if SHOW_TRAJ_START and len(density_result['all_trajs']) > 0 and (TRAJ_START_SIZE > 0):
        start_lon = density_result['all_trajs'][0][0][0]
        start_lat = density_result['all_trajs'][0][1][0]
        start_lon = wrap_lon_to_panel(start_lon, panel_cfg)
        source_sc = ax.scatter(start_lon, start_lat, marker='*', s=TRAJ_START_SIZE, facecolor=COLOR_TRAJ_START, edgecolor='white', linewidth=0.8, transform=data_proj, zorder=18)
        source_sc.set_path_effects([pe.Stroke(linewidth=1.7, foreground='white', alpha=1.0), pe.Normal()])
    lon_path, lat_path, _ = get_network_path_for_panel(panel_cfg, DG, node_lons, node_lats)
    draw_abc_network_path(ax, lon_path, lat_path, panel_cfg)
    if SHOW_NETWORK_ENDPOINTS and len(lon_path) > 1:
        sc_start = ax.scatter(lon_path[0], lat_path[0], s=NETWORK_START_SIZE, marker='o', facecolor=COLOR_NETWORK_MARKER_FACE, edgecolor=COLOR_NETWORK_MARKER_EDGE, linewidth=MARKER_EDGE_LW, transform=data_proj, zorder=28)
        sc_end = ax.scatter(lon_path[-1], lat_path[-1], s=NETWORK_END_SIZE, marker='*', facecolor=COLOR_NETWORK_MARKER_FACE, edgecolor=COLOR_NETWORK_MARKER_EDGE, linewidth=MARKER_EDGE_LW, transform=data_proj, zorder=28)
        for sc in [sc_start, sc_end]:
            sc.set_path_effects([pe.Stroke(linewidth=MARKER_WHITE_LW, foreground='white', alpha=1.0), pe.Normal()])
    panel_text = ax.text(panel_cfg['panel_label_x'], panel_cfg['panel_label_y'], panel_cfg['label'], transform=ax.transAxes, fontsize=FS_ABC_PANEL, fontweight='bold', va='top', ha='left', color='black', zorder=30)
    panel_text.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white', alpha=1.0), pe.Normal()])
    return pcm

def draw_left_abc(fig, DG, node_lons, node_lats):
    density_results = [compute_passage_probability(cfg) for cfg in PANELS]
    rects = [RECT_A, RECT_B, RECT_C]
    cbar_rects = [CBAR_A, CBAR_B, CBAR_C]
    for i, cfg in enumerate(PANELS):
        ax = fig.add_axes(rects[i], projection=cfg['map_projection'])
        pcm = draw_abc_panel(ax, cfg, density_results[i], DG, node_lons, node_lats)
        if SHOW_ABC_COLORBAR:
            cax = fig.add_axes(cbar_rects[i])
            cbar = fig.colorbar(pcm, cax=cax, orientation='horizontal', extend='both')
            if cfg['label'] == 'c':
                cbar.set_label('Trajectory density', fontsize=FS_ABC_CBAR_LABEL, labelpad=3)
            else:
                cbar.set_label('')
            cbar.ax.tick_params(labelsize=FS_ABC_CBAR_LABEL, length=2.2, width=0.6, direction='out')
            cbar.outline.set_linewidth(0.55)
            try:
                cbar.set_ticks(DENSITY_TICKS)
                cbar.set_ticklabels(DENSITY_TICKLABELS)
            except:
                pass

def create_super_smooth_stepped_cmap():
    colors = [(0.0, '#123f8a'), (0.2, '#1d91c0'), (0.3, '#36a7ba'), (0.4, '#41b6c4'), (0.45, '#7fcdbb'), (0.48, '#a1dab4'), (0.49, '#c1e7c1'), (0.5, '#addd8e'), (0.51, '#92d17d'), (0.52, '#78c679'), (0.53, '#5cb56b'), (0.54, '#41ab5d'), (0.55, '#4ea95a'), (0.56, '#63b457'), (0.57, '#79be57'), (0.58, '#8fc758'), (0.59, '#a4ce5b'), (0.6, '#b7d35f'), (0.61, '#c9d865'), (0.62, '#d8db6c'), (0.63, '#e5dd72'), (0.64, '#efde75'), (0.65, '#f8de77'), (0.7, '#fed976'), (0.75, '#feb24c'), (0.8, '#fd8d3c'), (0.85, '#f03b20'), (0.9, '#bd0026'), (0.95, '#800026'), (1.0, '#ffffff')]
    return mcolors.LinearSegmentedColormap.from_list('stepped_smooth', colors, N=2048)

def read_etopo_terrain(nc_path, step=5):
    ds = xr.open_dataset(nc_path)
    print('ETOPO dataset variables:', list(ds.data_vars))
    print('ETOPO dataset coords:', list(ds.coords))
    prefer_vars = ['elevation', 'z', 'topo', 'dem', 'band1', 'bed', 'ice', 'surface']
    var_name = None
    for p in prefer_vars:
        for v in ds.data_vars:
            if v.lower() == p or p in v.lower():
                var_name = v
                break
        if var_name is not None:
            break
    if var_name is None:
        for v in ds.data_vars:
            if ds[v].ndim >= 2:
                var_name = v
                break
    if var_name is None:
        raise ValueError('无法自动识别 ETOPO 高程变量。')
    da = ds[var_name]
    lat_name = None
    lon_name = None
    for c in da.coords:
        cl = c.lower()
        if cl in ['lat', 'latitude', 'y']:
            lat_name = c
        if cl in ['lon', 'longitude', 'x']:
            lon_name = c
    if lat_name is None:
        for d in da.dims:
            if d.lower() in ['lat', 'latitude', 'y']:
                lat_name = d
                break
    if lon_name is None:
        for d in da.dims:
            if d.lower() in ['lon', 'longitude', 'x']:
                lon_name = d
                break
    if lat_name is None or lon_name is None:
        raise ValueError(f'无法识别 ETOPO 经纬度坐标名：dims={da.dims}, coords={list(da.coords)}')
    if lat_name != 'lat' or lon_name != 'lon':
        da = da.rename({lat_name: 'lat', lon_name: 'lon'})
    if float(da['lon'].max()) > 180:
        lon_new = (da['lon'] + 180) % 360 - 180
        da = da.assign_coords(lon=lon_new).sortby('lon')
    lat_values = da['lat'].values
    if lat_values[0] < lat_values[-1]:
        da_nh = da.sel(lat=slice(MAP_MIN_LAT, MAP_MAX_LAT))
    else:
        da_nh = da.sel(lat=slice(MAP_MAX_LAT, MAP_MIN_LAT))
    if step is not None and step > 1:
        da_nh = da_nh.isel(lat=slice(None, None, step), lon=slice(None, None, step))
    da_nh = da_nh.where(np.isfinite(da_nh))
    terrain_lon = da_nh['lon'].values
    terrain_lat = da_nh['lat'].values
    terrain_data_m = da_nh.values
    terrain_data_km = np.clip(terrain_data_m / 1000.0, ELEV_VMIN, ELEV_VMAX)
    data_cyc, lon_cyc = add_cyclic_point(terrain_data_km, coord=terrain_lon)
    lon2d, lat2d = np.meshgrid(lon_cyc, terrain_lat)
    return (lon2d, lat2d, data_cyc)

def read_mean_wind_field(u_file, v_file):
    ds_u = xr.open_dataset(u_file)
    ds_v = xr.open_dataset(v_file)
    u = ds_u['uwnd'].sel(level=WIND_LEVEL, time=slice(WIND_TIME_START, WIND_TIME_END))
    v = ds_v['vwnd'].sel(level=WIND_LEVEL, time=slice(WIND_TIME_START, WIND_TIME_END))
    u_mean = u.mean(dim='time')
    v_mean = v.mean(dim='time')
    wind_lat = u_mean['lat'].values
    wind_lon = u_mean['lon'].values
    u_plot = u_mean.values
    v_plot = v_mean.values
    if np.nanmax(wind_lon) > 180:
        wind_lon_new = (wind_lon + 180) % 360 - 180
        sort_idx = np.argsort(wind_lon_new)
        wind_lon = wind_lon_new[sort_idx]
        u_plot = u_plot[:, sort_idx]
        v_plot = v_plot[:, sort_idx]
    lat_mask = (wind_lat >= MAP_MIN_LAT) & (wind_lat <= MAP_MAX_LAT)
    wind_lat = wind_lat[lat_mask]
    u_plot = u_plot[lat_mask, :]
    v_plot = v_plot[lat_mask, :]
    u_cyc, wind_lon_cyc = add_cyclic_point(u_plot, coord=wind_lon)
    v_cyc, _ = add_cyclic_point(v_plot, coord=wind_lon)
    wind_lon2d, wind_lat2d = np.meshgrid(wind_lon_cyc, wind_lat)
    return (wind_lon2d, wind_lat2d, u_cyc, v_cyc)

def make_600km_corridor(lon_path, lat_path, center_lon, buffer_km=600.0):
    lon_path_buffer = wrap_lon_to_center(lon_path, center=center_lon)
    lat_path_buffer = np.asarray(lat_path, dtype=float)
    valid = np.isfinite(lon_path_buffer) & np.isfinite(lat_path_buffer)
    lon_path_buffer = lon_path_buffer[valid]
    lat_path_buffer = lat_path_buffer[valid]
    if len(lon_path_buffer) < 2:
        raise ValueError('路径点数量不足，无法计算 buffer。')
    lon0 = np.nanmean(lon_path_buffer)
    lat0 = np.nanmean(lat_path_buffer)
    geo_crs = CRS.from_epsg(4326)
    aeqd_crs = CRS.from_proj4(f'+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs')
    to_m = Transformer.from_crs(geo_crs, aeqd_crs, always_xy=True).transform
    to_lonlat = Transformer.from_crs(aeqd_crs, geo_crs, always_xy=True).transform
    line_geo = LineString(list(zip(lon_path_buffer, lat_path_buffer)))
    line_m = shapely_transform(to_m, line_geo)
    corridor_geo = shapely_transform(to_lonlat, line_m.buffer(buffer_km * 1000.0))

    def recenter_geometry_lon(x, y, z=None):
        x = np.asarray(x, dtype=float)
        x = wrap_lon_to_center(x, center=center_lon)
        if z is None:
            return (x, y)
        return (x, y, z)
    corridor_geo = shapely_transform(recenter_geometry_lon, corridor_geo)
    return corridor_geo

def add_directional_arrows(ax, lon_data, lat_data, n_arrows=4, color='#66529F', lw=2.5, ms=15, zo=16, stroke_lw=5.0, alpha=1.0):
    lon_data = np.asarray(lon_data, dtype=float)
    lat_data = np.asarray(lat_data, dtype=float)
    valid = np.isfinite(lon_data) & np.isfinite(lat_data)
    lon_data = lon_data[valid]
    lat_data = lat_data[valid]
    if len(lon_data) < 2:
        return
    seg_dist = [haversine_km(lon_data[i - 1], lat_data[i - 1], lon_data[i], lat_data[i]) for i in range(1, len(lon_data))]
    cum_dist = np.concatenate(([0.0], np.cumsum(seg_dist)))
    total_dist = cum_dist[-1]
    if total_dist <= 0:
        return
    arrow_positions = np.linspace(0.15 * total_dist, 0.85 * total_dist, n_arrows)
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for s in arrow_positions:
        idx = np.clip(np.searchsorted(cum_dist, s) - 1, 0, len(lon_data) - 2)
        x0, y0 = (lon_data[idx], lat_data[idx])
        x1, y1 = (lon_data[idx + 1], lat_data[idx + 1])
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='-|>', color=color, lw=lw, mutation_scale=ms, shrinkA=0, shrinkB=0, alpha=alpha), zorder=zo)
        ann.arrow_patch.set_path_effects([pe.Stroke(linewidth=stroke_lw, foreground='white', alpha=1.0), pe.Normal()])

def add_network_segment_arrows(ax, lon_path, lat_path, color='#C9352B', lw=2.6, ms=24, alpha=0.86, stroke_lw=5.4, zo=13):
    pc = ccrs.PlateCarree()
    xytr = pc._as_mpl_transform(ax)
    for i in range(len(lon_path) - 1):
        x0, y0 = (lon_path[i], lat_path[i])
        x1, y1 = (lon_path[i + 1], lat_path[i + 1])
        if not np.all(np.isfinite([x0, y0, x1, y1])):
            continue
        x1 = x0 + ((x1 - x0 + 180) % 360 - 180)
        ann_net = ax.annotate('', xy=(x1, y1), xytext=(x0, y0), xycoords=xytr, textcoords=xytr, arrowprops=dict(arrowstyle='->', color=color, lw=lw, mutation_scale=ms, shrinkA=12, shrinkB=12, alpha=alpha), zorder=zo)
        ann_net.arrow_patch.set_path_effects([pe.Stroke(linewidth=stroke_lw, foreground='white', alpha=0.95), pe.Normal()])

def preprocess_polar_route(route, DG, node_lons, node_lats):
    route_name = route['name']
    start_node = route['start_node']
    end_node = route['end_node']
    traj_file = route['traj_file']
    center_lon = route['center_lon_for_buffer']
    print('\n===================================================')
    print('Processing polar route:', route_name)
    print('start_node:', start_node, 'end_node:', end_node)
    print('trajectory:', traj_file)
    print('===================================================')
    path_in = nx.dijkstra_path(DG, start_node, end_node)
    lon_path_orig = np.asarray([node_lons[k] for k in path_in], dtype=float)
    lat_path_orig = np.asarray([node_lats[k] for k in path_in], dtype=float)
    lon_path = np.flip(lon_path_orig)
    lat_path = np.flip(lat_path_orig)
    lon_path = wrap_lon_to_center(lon_path, center=center_lon)
    traj_data = np.load(traj_file)
    traj_lon = np.asarray(traj_data['traj_lon'], dtype=float)
    traj_lat = np.asarray(traj_data['traj_lat'], dtype=float)
    traj_lon = wrap_lon_to_center(traj_lon, center=center_lon)
    route_out = dict(route)
    route_out['path_nodes'] = path_in
    route_out['lon_path'] = lon_path
    route_out['lat_path'] = lat_path
    route_out['traj_lon'] = traj_lon
    route_out['traj_lat'] = traj_lat
    print('network path nodes:', len(path_in))
    print('HYSPLIT points:', len(traj_lon))
    return route_out

def draw_polar_panel(fig, DG, node_lons, node_lats):
    wind_lon2d, wind_lat2d, u_cyc, v_cyc = read_mean_wind_field(U_FILE, V_FILE)
    wind_speed_cyc = np.sqrt(u_cyc ** 2 + v_cyc ** 2)
    wind_speed_vmax = np.nanpercentile(wind_speed_cyc, WIND_SPEED_PERCENTILE_MAX)
    if not np.isfinite(wind_speed_vmax) or wind_speed_vmax <= WIND_SPEED_VMIN:
        wind_speed_vmax = np.nanmax(wind_speed_cyc)
    if not np.isfinite(wind_speed_vmax) or wind_speed_vmax <= WIND_SPEED_VMIN:
        wind_speed_vmax = 1.0
    processed_routes = [preprocess_polar_route(route, DG, node_lons, node_lats) for route in ROUTES]
    proj = ccrs.NorthPolarStereo(central_longitude=POLAR_CENTRAL_LONGITUDE)
    data_crs = ccrs.PlateCarree()
    ax = fig.add_axes(RECT_D_POLAR, projection=proj)
    ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
    ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
    ax.set_extent([-180, 180, MAP_MIN_LAT, MAP_MAX_LAT], crs=data_crs)
    theta = np.linspace(0, 2 * np.pi, 400)
    center = np.array([0.5, 0.5])
    radius = 0.5
    verts = np.vstack([np.sin(theta), np.cos(theta)]).T
    circle = mpath.Path(verts * radius + center)
    ax.set_boundary(circle, transform=ax.transAxes)
    mesh = ax.pcolormesh(wind_lon2d, wind_lat2d, wind_speed_cyc, transform=data_crs, cmap=WIND_SPEED_CMAP, shading='auto', vmin=WIND_SPEED_VMIN, vmax=wind_speed_vmax, rasterized=True, alpha=WIND_SPEED_ALPHA, zorder=1)
    ax.coastlines(resolution='50m', linewidth=LW_POLAR_COAST, color=COLOR_POLAR_COAST, zorder=5)
    ax.gridlines(crs=data_crs, draw_labels=False, linewidth=LW_POLAR_GRID, color=COLOR_POLAR_GRID, alpha=0.15, linestyle='--', zorder=2)
    q = ax.quiver(wind_lon2d[::WIND_SKIP, ::WIND_SKIP], wind_lat2d[::WIND_SKIP, ::WIND_SKIP], u_cyc[::WIND_SKIP, ::WIND_SKIP], v_cyc[::WIND_SKIP, ::WIND_SKIP], transform=data_crs, color=COLOR_WIND, scale=WIND_SCALE, width=WIND_WIDTH, headwidth=WIND_HEADWIDTH, headlength=WIND_HEADLENGTH, headaxislength=WIND_HEADAXISLENGTH, alpha=WIND_ALPHA, zorder=6)
    if SHOW_QUIVER_KEY:
        ax.quiverkey(q, X=1.125, Y=0.923, U=QUIVER_KEY_U, label=QUIVER_KEY_LABEL, labelpos='E', coordinates='axes', fontproperties={'size': FS_POLAR_QUIVER_KEY}, color='black', labelsep=0.08)
    for route in processed_routes:
        route_name = route['name']
        lon_path = route['lon_path']
        lat_path = route['lat_path']
        traj_lon = route['traj_lon']
        traj_lat = route['traj_lat']
        if USE_ROUTE_SPECIFIC_COLORS:
            c_net_arrow = ROUTE_COLORS[route_name]['network_arrow']
            c_traj = ROUTE_COLORS[route_name]['trajectory']
        else:
            c_net_arrow = COLOR_NETWORK_ARROW_POLAR
            c_traj = COLOR_TRAJ_POLAR
        network_line, = ax.plot(lon_path, lat_path, transform=data_crs, linewidth=TRAJ_LINE_LW, color=c_net_arrow, zorder=12)
        network_line.set_path_effects([pe.Stroke(linewidth=TRAJ_LINE_STROKE_LW, foreground='white', alpha=0.75), pe.Normal()])
        add_directional_arrows(ax=ax, lon_data=lon_path, lat_data=lat_path, n_arrows=route['n_network_arrows'], color=c_net_arrow, lw=TRAJ_ARROW_LW, ms=TRAJ_ARROW_MS, zo=13, stroke_lw=TRAJ_ARROW_STROKE_LW, alpha=1.0)
        traj_line, = ax.plot(traj_lon, traj_lat, transform=data_crs, linewidth=TRAJ_LINE_LW, color=c_traj, zorder=16)
        traj_line.set_path_effects([pe.Stroke(linewidth=TRAJ_LINE_STROKE_LW, foreground='white', alpha=0.75), pe.Normal()])
        add_directional_arrows(ax=ax, lon_data=traj_lon, lat_data=traj_lat, n_arrows=route['n_traj_arrows'], color=c_traj, lw=TRAJ_ARROW_LW, ms=TRAJ_ARROW_MS, zo=17, stroke_lw=TRAJ_ARROW_STROKE_LW, alpha=1.0)
        if SHOW_POLAR_START_END_MARKERS:
            start_sc = ax.scatter(lon_path[0], lat_path[0], s=START_MARKER_SIZE, marker='o', color=COLOR_POLAR_MARKER_FACE, edgecolors=COLOR_POLAR_MARKER_EDGE, linewidth=POLAR_MARKER_EDGE_LW, transform=data_crs, zorder=28)
            end_sc = ax.scatter(lon_path[-1], lat_path[-1], s=END_MARKER_SIZE, marker='*', color=COLOR_POLAR_MARKER_FACE, edgecolors=COLOR_POLAR_MARKER_EDGE, linewidth=POLAR_MARKER_EDGE_LW, transform=data_crs, zorder=28)
            for sc in [start_sc, end_sc]:
                sc.set_path_effects([pe.Stroke(linewidth=POLAR_MARKER_STROKE_LW, foreground='white', alpha=1.0), pe.Normal()])
    cax = fig.add_axes(CBAR_D_POLAR)
    cbar = fig.colorbar(mesh, cax=cax, orientation='vertical')
    cbar.set_label('Wind speed (m s$^{-1}$)', fontsize=FS_POLAR_CBAR_LABEL)
    cbar.ax.tick_params(labelsize=FS_POLAR_CBAR_TICK, width=0.7, length=3.0)
    cbar.outline.set_linewidth(0.65)
    legend_elements = [Line2D([0, 1], [0, 0], color=COLOR_TRAJ_POLAR, lw=LEGEND_LINE_WIDTH, marker='>', markersize=7, markerfacecolor=COLOR_TRAJ_POLAR, markeredgecolor=COLOR_TRAJ_POLAR, markevery=[1], label='Particle Trajectory'), Line2D([0, 1], [0, 0], color=COLOR_NETWORK_ARROW_POLAR, lw=LEGEND_LINE_WIDTH, marker='>', markersize=7, markerfacecolor=COLOR_NETWORK_ARROW_POLAR, markeredgecolor=COLOR_NETWORK_ARROW_POLAR, markevery=[1], alpha=0.9, label='Network Pathway'), Line2D([0], [0], marker='o', linestyle='None', markerfacecolor=COLOR_POLAR_MARKER_FACE, markeredgecolor=COLOR_POLAR_MARKER_EDGE, markersize=10, label='Start'), Line2D([0], [0], marker='*', linestyle='None', markerfacecolor=COLOR_POLAR_MARKER_FACE, markeredgecolor=COLOR_POLAR_MARKER_EDGE, markersize=15, label='End')]
    leg = ax.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.67, 0.92), ncol=1, fontsize=FS_POLAR_LEGEND, labelspacing=0.8, framealpha=0, fancybox=False, facecolor='white', edgecolor='#bcbcbc')
    leg.get_frame().set_linewidth(0.8)
    if SHOW_POLAR_PANEL_LABEL:
        txt = ax.text(-0.093, 1.035, POLAR_PANEL_LABEL, transform=ax.transAxes, ha='left', va='top', fontsize=FS_POLAR_PANEL, fontweight='bold', fontfamily=FONT_FAMILY, color='black', zorder=40)
        txt.set_path_effects([pe.Stroke(linewidth=3.0, foreground='white'), pe.Normal()])
    return ax

def read_csv_auto(file_path):
    try:
        return pd.read_csv(file_path, encoding='utf-8-sig')
    except UnicodeDecodeError:
        return pd.read_csv(file_path, encoding='gbk')

def load_overlap_data(real_file, null_file):
    df_real = read_csv_auto(real_file)
    print(f'\n读取真实路径文件：{real_file}')
    print('真实路径文件列名：', df_real.columns.tolist())
    if 'fraction_inside' not in df_real.columns:
        raise KeyError(f'{real_file} 中没有找到列：fraction_inside')
    df_null = read_csv_auto(null_file)
    print(f'读取随机路径文件：{null_file}')
    print('随机路径文件列名：', df_null.columns.tolist())
    if 'null_id' not in df_null.columns:
        raise KeyError(f'{null_file} 中没有找到列：null_id')
    if 'fraction_inside' not in df_null.columns:
        raise KeyError(f'{null_file} 中没有找到列：fraction_inside')
    df_null = df_null[np.isfinite(df_null['fraction_inside'])].copy()
    return (df_real, df_null)

def pathway_significance_aligned(df_real, df_null):
    if 'fraction_inside' not in df_real.columns:
        raise KeyError('df_real 中缺少 fraction_inside 列。')
    if 'fraction_inside' not in df_null.columns:
        raise KeyError('df_null 中缺少 fraction_inside 列。')
    if 'null_id' not in df_null.columns:
        raise KeyError('df_null 中缺少 null_id 列。')
    if 'traj_id' in df_real.columns and 'traj_id' in df_null.columns:
        df_real_use = df_real[['traj_id', 'fraction_inside']].copy().rename(columns={'fraction_inside': 'F_obs'})
        df_real_use = df_real_use[np.isfinite(df_real_use['F_obs'])]
        if df_real_use.empty:
            raise ValueError('df_real 中没有有效的 fraction_inside。')
        S_obs = df_real_use['F_obs'].mean()
        S_null_list = []
        valid_null_ids = []
        for nid in sorted(df_null['null_id'].unique()):
            df_one = df_null.loc[df_null['null_id'] == nid, ['traj_id', 'fraction_inside']].copy().rename(columns={'fraction_inside': 'F_null'})
            df_merge = pd.merge(df_real_use, df_one, on='traj_id', how='inner')
            df_merge = df_merge[np.isfinite(df_merge['F_obs']) & np.isfinite(df_merge['F_null'])]
            if len(df_merge) == 0:
                continue
            S_null_list.append(df_merge['F_null'].mean())
            valid_null_ids.append(nid)
    else:
        F_obs = df_real['fraction_inside'].to_numpy(dtype=float)
        F_obs = F_obs[np.isfinite(F_obs)]
        if len(F_obs) == 0:
            raise ValueError('df_real 中没有有效的 fraction_inside。')
        S_obs = np.mean(F_obs)
        S_null_list = []
        valid_null_ids = []
        for nid in sorted(df_null['null_id'].unique()):
            F_null_one = df_null.loc[df_null['null_id'] == nid, 'fraction_inside'].to_numpy(dtype=float)
            F_null_one = F_null_one[np.isfinite(F_null_one)]
            if len(F_null_one) == 0:
                continue
            S_null_list.append(np.mean(F_null_one))
            valid_null_ids.append(nid)
    S_null = np.asarray(S_null_list, dtype=float)
    if len(S_null) == 0:
        raise ValueError('没有有效的 null path 数据，无法计算显著性。')
    p_value = (1 + np.sum(S_null >= S_obs)) / (len(S_null) + 1)
    S_null_mean = np.mean(S_null)
    S_null_std = np.std(S_null, ddof=1)
    z_score = (S_obs - S_null_mean) / S_null_std if S_null_std > 0 else np.nan
    percentile = 100 * np.mean(S_null < S_obs)
    return {'S_obs': S_obs, 'S_null_mean': S_null_mean, 'S_null_std': S_null_std, 'p_value': p_value, 'z_score': z_score, 'percentile': percentile, 'n_null_paths': len(S_null), 'valid_null_ids': valid_null_ids, 'S_null': S_null}

def plot_path_level_null_pdf_on_ax(ax, sig_result, xlim, threshold_percentile, panel_label, bw_method, xlabel='$S_r(P)$', ylabel='PDF', show_legend=False):
    S_null = np.asarray(sig_result['S_null'], dtype=float)
    S_null = S_null[np.isfinite(S_null)]
    S_obs = float(sig_result['S_obs'])
    S_null_mean = float(sig_result['S_null_mean'])
    S_null_std = float(sig_result['S_null_std'])
    p_value = float(sig_result['p_value'])
    z_score = float(sig_result['z_score'])
    if len(S_null) < 3 or np.std(S_null) < 1e-08:
        raise ValueError('S_null 样本过少或方差过小，无法绘制 KDE-PDF。')
    q_threshold = np.percentile(S_null, threshold_percentile)
    x_left, x_right = xlim
    x_grid = np.linspace(x_left, x_right, 600)[1:-1]
    kde_null = gaussian_kde(S_null, bw_method=bw_method)
    y_null = kde_null(x_grid)
    x_plot = np.concatenate([[x_left], x_grid, [x_right]])
    y_plot = np.concatenate([[0], y_null, [0]])
    ax.plot(x_plot, y_plot, color=COLOR_PDF_NULL, linewidth=LW_PDF_CURVE, alpha=0.95, zorder=3, label='Null model')
    ax.fill_between(x_plot, y_plot, 0, color=COLOR_PDF_FILL, alpha=PDF_FILL_ALPHA, linewidth=0, zorder=1)
    tail_mask = x_plot >= q_threshold
    ax.fill_between(x_plot[tail_mask], y_plot[tail_mask], 0, color=COLOR_PDF_THRESHOLD, alpha=PDF_TAIL_ALPHA, linewidth=0, zorder=2)
    threshold_label = f'{threshold_percentile:g}% null threshold'
    ax.axvline(q_threshold, color=COLOR_PDF_THRESHOLD, linewidth=LW_PDF_VLINE, linestyle='--', alpha=0.95, zorder=4, label=threshold_label)
    ax.axvline(S_obs, color=COLOR_PDF_REAL, linewidth=LW_PDF_VLINE, alpha=0.98, zorder=5, label='Real path')
    y_top = np.max(y_plot) * 1.3
    ax.set_xlim(x_left, x_right)
    ax.set_ylim(-0.02 * y_top, y_top)
    ax.set_xlabel(xlabel, fontsize=FS_PDF_LABEL, labelpad=1.2)
    ax.set_ylabel(ylabel, fontsize=FS_PDF_LABEL, labelpad=0.2)
    ax.text(-0.13, 1.08, panel_label, transform=ax.transAxes, fontsize=FS_PDF_PANEL, fontweight='bold', ha='left', va='bottom')
    ax.text(S_obs + 0.0025, y_top * 1, f'{S_obs:.2f}', color=COLOR_PDF_REAL, ha='left', va='top', fontsize=FS_PDF_LINE_TEXT, rotation=90)
    ax.text(q_threshold - 0.0015, y_top * 1, f'{q_threshold:.2f}', color=COLOR_PDF_THRESHOLD, ha='right', va='top', fontsize=FS_PDF_LINE_TEXT, rotation=90)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_linewidth(0.65)
    ax.spines['bottom'].set_linewidth(0.65)
    ax.tick_params(axis='both', labelsize=FS_PDF_TICK, width=0.65, length=2.4)
    ax.set_xticks(np.linspace(x_left, x_right, 3))
    ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%.2f'))
    if show_legend:
        handles, labels = ax.get_legend_handles_labels()
        order_names = ['Null model', threshold_label, 'Real path']
        order = [labels.index(name) for name in order_names if name in labels]
        ax.legend([handles[i] for i in order], [labels[i] for i in order], frameon=False, fontsize=FS_PDF_LEGEND, loc='upper left', handlelength=1.4, borderaxespad=0.05, labelspacing=0.16)
    print(f'[{panel_label}] Null mean overlap: {S_null_mean:.4f} ± {S_null_std:.4f}')
    print(f'[{panel_label}] Observed mean overlap: {S_obs:.4f}')
    print(f'[{panel_label}] {threshold_percentile:g}% null threshold: {q_threshold:.4f}')
    print(f'[{panel_label}] p-value: {p_value:.6f}')
    print(f'[{panel_label}] z-score: {z_score:.3f}')
    return {'S_obs': S_obs, 'S_null_mean': S_null_mean, 'S_null_std': S_null_std, 'q_threshold': q_threshold, 'p_value': p_value, 'z_score': z_score}

def draw_bottom_pdfs(fig):
    df_real_e, df_null_e = load_overlap_data(PDF_REAL_FILE_E, PDF_NULL_FILE_E)
    sig_e = pathway_significance_aligned(df_real_e, df_null_e)
    df_real_f, df_null_f = load_overlap_data(PDF_REAL_FILE_F, PDF_NULL_FILE_F)
    sig_f = pathway_significance_aligned(df_real_f, df_null_f)
    df_real_g, df_null_g = load_overlap_data(PDF_REAL_FILE_G, PDF_NULL_FILE_G)
    sig_g = pathway_significance_aligned(df_real_g, df_null_g)
    ax_e = fig.add_axes(RECT_E)
    ax_f = fig.add_axes(RECT_F)
    ax_g = fig.add_axes(RECT_G)
    plot_path_level_null_pdf_on_ax(ax_e, sig_e, PDF_XLIM_E, PDF_THRESHOLD_E, 'e', PDF_BW_E, ylabel='PDF', show_legend=False)
    plot_path_level_null_pdf_on_ax(ax_f, sig_f, PDF_XLIM_F, PDF_THRESHOLD_F, 'f', PDF_BW_F, ylabel='', show_legend=False)
    plot_path_level_null_pdf_on_ax(ax_g, sig_g, PDF_XLIM_G, PDF_THRESHOLD_G, 'g', PDF_BW_G, ylabel='', show_legend=False)
    ax_e.set_title('Eurasian', fontsize=FS_PDF_LABEL, fontweight='bold', color='#3674A4', pad=11)
    ax_f.set_title('Trans-Pacific', fontsize=FS_PDF_LABEL, fontweight='bold', color='#A83D2B', pad=11)
    ax_g.set_title('Trans-Atlantic', fontsize=FS_PDF_LABEL, fontweight='bold', color='#5B2F86', pad=11)
    if SHOW_EFG_SHARED_LEGEND:
        from matplotlib.lines import Line2D
        null_pdf_color = '#2f3e46'
        real_color = '#C85D4D'
        threshold_color = '#1E469B'
        legend_handles = [Line2D([0], [0], color=null_pdf_color, linewidth=1.6, label='Null model'), Line2D([0], [0], color=threshold_color, linewidth=1.4, linestyle='--', label='Null threshold'), Line2D([0], [0], color=real_color, linewidth=1.6, label='Real path')]
        fig.legend(handles=legend_handles, loc='lower center', bbox_to_anchor=(EFG_LEGEND_X, EFG_LEGEND_Y), ncol=EFG_LEGEND_NCOL, frameon=False, fontsize=FS_EFG_LEGEND, handlelength=EFG_LEGEND_HANDLELENGTH, columnspacing=EFG_LEGEND_COLUMN_SPACING, handletextpad=0.5, borderaxespad=0.0)

def main():
    plt.close('all')
    DG = get_network_graph()
    base_lons, base_lats = get_node_lons_lats()
    base_lons = (np.asarray(base_lons, dtype=float) + 180) % 360 - 180
    base_lats = np.asarray(base_lats, dtype=float)
    globals()['lons'] = base_lons
    globals()['lats'] = base_lats
    node_lons, node_lats, coord_source = choose_best_node_coordinates(DG, base_lons=base_lons, base_lats=base_lats)
    print('本次绘图使用的 network 坐标源:', coord_source)
    fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT), dpi=FIG_DPI, facecolor='white')
    draw_left_abc(fig, DG, node_lons, node_lats)
    draw_polar_panel(fig, DG, node_lons, node_lats)
    draw_bottom_pdfs(fig)
    if SAVE_FIG:
        out_dir = os.path.dirname(OUT_FIG)
        if out_dir != '':
            os.makedirs(out_dir, exist_ok=True)
        plt.savefig(OUT_FIG, dpi=SAVE_DPI, bbox_inches='tight', pad_inches=0.02)
        plt.savefig(OUT_FIG_PDF, bbox_inches='tight', pad_inches=0.02)
        print('\n保存完成：')
        print(OUT_FIG)
        print(OUT_FIG_PDF)
    if SHOW_FIG:
        plt.show()
    else:
        plt.close(fig)
if __name__ == '__main__':
    main()
