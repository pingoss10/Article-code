import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.path as mpath
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.ticker import MaxNLocator, AutoMinorLocator
from matplotlib.colors import to_rgba, LinearSegmentedColormap
from scipy.stats import gaussian_kde
FONT_SCALE = 1.0
FIG_WIDTH = 7.2
FIG_HEIGHT = 5.6
FIG_DPI = 300
FS_PANEL = 14 * FONT_SCALE
FS_PANEL1 = 14.1 * FONT_SCALE
FS_LON_LABEL = 10 * FONT_SCALE
FS_CBAR_LABEL = 10 * FONT_SCALE
FS_CBAR_TICK = 10 * FONT_SCALE
FS_C_XTICK = 10 * FONT_SCALE
FS_C_YTICK = 10 * FONT_SCALE
FS_C_LABEL = 10 * FONT_SCALE
FS_C_TEXT = 10 * FONT_SCALE
LW_COAST = 0.35
LW_GRID = 0.35
LW_BOX = 1.8
LW_AXIS_C = 0.85
SAVE_FIG = True
OUT_FIG = 'outputs/figures/figure_001.jpg'
OUT_FIG_PDF = 'outputs/figures/figure_002.pdf'
RECT_A = [0.08, 0.435, 0.365, 0.43]
RECT_B = [0.52, 0.435, 0.365, 0.43]
RECT_C = [0.11, 0.06, 0.72, 0.21]
CBAR_A = [0.105, 0.36, 0.315, 0.022]
CBAR_B = [0.58, 0.36, 0.315, 0.022]
mpl.rcParams.update({'font.family': 'Arial', 'axes.linewidth': LW_AXIS_C, 'hatch.color': 'k', 'hatch.linewidth': 0.45, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})
required_vars = ['mean_map_sorted', 'slope_sorted', 'lon2d', 'lat2d', 'df_plot']
missing_vars = [v for v in required_vars if v not in globals()]
if len(missing_vars) > 0:
    raise NameError('当前环境缺少以下变量，请先运行前面的数据计算程序：\n' + '\n'.join(missing_vars))
box_colors = {'China': '#E64B35FF', 'Europe': '#00A087FF', 'America': '#4DBBD5FF', 'India': '#692F7C'}

def add_box(ax, lon_min, lon_max, lat_min, lat_max, color, lw=LW_BOX, ls='-'):
    rect = mpatches.Rectangle((lon_min, lat_min), lon_max - lon_min, lat_max - lat_min, fill=False, edgecolor=color, linewidth=lw, linestyle=ls, transform=ccrs.PlateCarree(), zorder=6)
    ax.add_patch(rect)

def add_region_boxes(ax):
    add_box(ax, 95, 130, 20, 50, box_colors['China'])
    add_box(ax, 20, 80, 48, 67, box_colors['Europe'])
    add_box(ax, -110, -70, 25, 55, box_colors['America'])
    add_box(ax, 68, 90, 8, 36, box_colors['India'])

def setup_polar_ax(fig, rect):
    proj = ccrs.NorthPolarStereo(central_longitude=180)
    ax = fig.add_axes(rect, projection=proj)
    ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
    ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
    ax.set_extent([-180, 180, -5, 90], crs=ccrs.PlateCarree())
    theta = np.linspace(0, 2 * np.pi, 300)
    center, radius = ([0.5, 0.5], 0.5)
    verts = np.vstack([np.sin(theta), np.cos(theta)]).T
    circle = mpath.Path(verts * radius + center)
    ax.set_boundary(circle, transform=ax.transAxes)
    ax.add_feature(cfeature.LAND, facecolor='#F2F2F2', zorder=0)
    ax.add_feature(cfeature.COASTLINE, linewidth=LW_COAST, edgecolor='black', zorder=3)
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=False, linewidth=LW_GRID, color='gray', alpha=0.8, linestyle='--')
    gl.xlocator = mticker.FixedLocator(np.arange(-180, 181, 30))
    label_style = dict(fontsize=FS_LON_LABEL, color='k', ha='center', va='center')
    for lon, txt in [(0, '0°'), (30, '30°E'), (60, '60°E'), (90, '90°E'), (120, '120°E'), (150, '150°'), (180, '180°'), (-150, '150°W'), (-120, '120°W'), (-90, '90°W'), (-60, '60°W'), (-30, '30°W')]:
        ax.text(lon, -13.5, txt, transform=ccrs.PlateCarree(), **label_style)
    return ax

def add_panel_label(ax, label, x=-0.02, y=1.08):
    ax.text(x, y, label, transform=ax.transAxes, fontsize=FS_PANEL, fontweight='bold', va='top', ha='left', color='black', zorder=20)
cmap_a = mpl.colors.LinearSegmentedColormap.from_list('custom_OrRd', [(0.0, '#ffffff'), (0.06, '#fffaf8'), (0.16, '#fff0e8'), (0.3, '#fddcc8'), (0.46, '#fcb98f'), (0.62, '#fc8d59'), (0.8, '#e34a33'), (1.0, '#b30000')])
cmap_b = mpl.colors.LinearSegmentedColormap.from_list('custom_GnBu_refined', [(0.0, '#ffffff'), (0.1, '#ffffff'), (0.18, '#f6fcfb'), (0.28, '#eaf7f5'), (0.4, '#d4ece8'), (0.52, '#b4ddd8'), (0.64, '#86c8c8'), (0.76, '#56aeb9'), (0.87, '#2e8fa6'), (1.0, '#116b88')])
fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT), dpi=FIG_DPI, facecolor='white')
plate = ccrs.PlateCarree()
ax_a = setup_polar_ax(fig, RECT_A)
vmin_a = np.nanpercentile(mean_map_sorted, 2)
vmax_a = np.nanpercentile(mean_map_sorted, 98)
im_a = ax_a.pcolormesh(lon2d, lat2d, mean_map_sorted, transform=plate, shading='auto', vmin=vmin_a, vmax=vmax_a, cmap=cmap_a, zorder=1)
add_region_boxes(ax_a)
thr_a = np.nanpercentile(mean_map_sorted, 90)
top10_a = (mean_map_sorted >= thr_a).astype(int)
ax_a.contourf(lon2d, lat2d, top10_a, levels=[0.5, 1.5], colors='none', hatches=['ooo'], transform=plate, zorder=5)
add_panel_label(ax_a, 'a', x=-0.02, y=1.08)
cax_a = fig.add_axes(CBAR_A)
cbar_a = fig.colorbar(im_a, cax=cax_a, orientation='horizontal', extend='both')
cbar_a.set_label('Concentration (ppb)', fontsize=FS_CBAR_LABEL, labelpad=1.5)
cbar_a.locator = MaxNLocator(nbins=6)
cbar_a.update_ticks()
cbar_a.ax.tick_params(labelsize=FS_CBAR_TICK, length=2, width=0.7, pad=1.5)
cbar_a.outline.set_linewidth(0.55)
ax_b = setup_polar_ax(fig, RECT_B)
vmin_b, vmax_b = (6, 10)
im_b = ax_b.pcolormesh(lon2d, lat2d, slope_sorted, transform=plate, shading='auto', vmin=vmin_b, vmax=vmax_b, cmap=cmap_b, zorder=1)
add_region_boxes(ax_b)
thr_hi_b = np.nanpercentile(slope_sorted, 93)
thr_lo_b = np.nanpercentile(slope_sorted, 6)
top10_b = (slope_sorted >= thr_hi_b).astype(int)
bottom10_b = (slope_sorted <= thr_lo_b).astype(int)
mpl.rcParams['hatch.color'] = 'k'
mpl.rcParams['hatch.linewidth'] = 0.55
ax_b.contourf(lon2d, lat2d, top10_b, levels=[0.5, 1.5], colors='none', hatches=['ooo'], transform=plate, zorder=5)
ax_b.contourf(lon2d, lat2d, bottom10_b, levels=[0.5, 1.5], colors='none', hatches=['++'], transform=plate, zorder=5)
add_panel_label(ax_b, 'b', x=-0.02, y=1.06)
cax_b = fig.add_axes(CBAR_B)
cbar_b = fig.colorbar(im_b, cax=cax_b, orientation='horizontal', extend='both')
cbar_b.set_label('Trend (ppb/yr)', fontsize=FS_CBAR_LABEL, labelpad=1.5)
cbar_b.locator = MaxNLocator(nbins=6)
cbar_b.update_ticks()
cbar_b.ax.tick_params(labelsize=FS_CBAR_TICK, length=2, width=0.7, pad=1.5)
cbar_b.outline.set_linewidth(0.55)
ax_c = fig.add_axes(RECT_C)
region_keys = ['NH', 'Europe', 'America', 'India', 'China']
display_labels = ['NH', 'Europe', 'America', 'India', 'China']
palette = {'NH': '#E07E35', 'China': '#e3716e', 'Europe': '#68BAAA', 'America': '#85b1cf', 'India': '#ad7e98'}
data_list = []
valid_keys = []
valid_labels = []
for key, label in zip(region_keys, display_labels):
    arr = df_plot.loc[df_plot['Region'] == key, 'Growth_Rate'].dropna().values
    if len(arr) > 0:
        data_list.append(arr)
        valid_keys.append(key)
        valid_labels.append(label)
    else:
        print(f'Warning: {key} has no valid data and was skipped.')
if len(data_list) == 0:
    raise ValueError('df_plot 中没有可用于绘制子图 c 的有效数据。')
positions = np.arange(1, len(valid_keys) + 1)
ax_c.set_xlim(0.45, len(valid_keys) + 0.85)
parts = ax_c.boxplot(data_list, positions=positions, widths=0.42, patch_artist=True, showfliers=False, whis=1.5, showmeans=True, meanline=True)
for i, box in enumerate(parts['boxes']):
    key = valid_keys[i]
    alpha_val = 0.25
    lw_val = 1.05
    if key == 'NH':
        alpha_val = 0.2
        lw_val = 1.25
    box.set_facecolor(to_rgba(palette[key], alpha_val))
    box.set_edgecolor(to_rgba(palette[key], 1))
    box.set_linewidth(lw_val)
    box.set_zorder(4)
for whisker in parts['whiskers']:
    whisker.set_color('#1F1F1F')
    whisker.set_linewidth(0.8)
for cap in parts['caps']:
    cap.set_color('#1F1F1F')
    cap.set_linewidth(0.8)
for median in parts['medians']:
    median.set_visible(False)
for mean_line in parts['means']:
    mean_line.set_color('#1F1F1F')
    mean_line.set_linewidth(1.05)
    mean_line.set_linestyle('-')
    mean_line.set_zorder(5)
rng = np.random.default_rng(42)
for i, key in enumerate(valid_keys):
    y = df_plot.loc[df_plot['Region'] == key, 'Growth_Rate'].dropna().values
    x = rng.normal(loc=positions[i], scale=0.055, size=len(y))
    if len(y) > 2:
        xy = np.vstack([x, y])
        try:
            z = gaussian_kde(xy)(xy)
            idx = z.argsort()
            x, y, z = (x[idx], y[idx], z[idx])
        except Exception:
            z = np.ones_like(x)
    else:
        z = np.ones_like(x)
    c_rgb = mcolors.to_rgb(palette[key])
    cmap_density = LinearSegmentedColormap.from_list(f'density_{key}', [(c_rgb[0], c_rgb[1], c_rgb[2], 0.1), (c_rgb[0], c_rgb[1], c_rgb[2], 1.0)])
    ax_c.scatter(x, y, s=7.5, c=z, cmap=cmap_density, edgecolors='none', zorder=1)
    q1, med, q3 = np.percentile(y, [25, 50, 75])
    iqr = q3 - q1
    mean_val = np.mean(y)
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    y_lower = y[y >= lower_bound]
    y_upper = y[y <= upper_bound]
    lower_whisker = np.min(y_lower) if len(y_lower) > 0 else np.min(y)
    upper_whisker = np.max(y_upper) if len(y_upper) > 0 else np.max(y)
    ax_c.scatter(positions[i], mean_val, s=33, marker='o', color='white', edgecolors='#1F1F1F', linewidths=0.9, zorder=10)
    text_x = positions[i] + 0.08
    if i == 0:
        text_y = upper_whisker + 1.2
        text_label = f'{mean_val:.2f} ppb yr$^{{-1}}$'
    else:
        text_y = upper_whisker + 0.13
        text_label = f'{mean_val:.2f}'
    ax_c.text(text_x, text_y, text_label, ha='left', va='bottom', fontsize=FS_C_TEXT, fontweight='bold', color=palette[key], zorder=8)
ax_c.set_xticks(positions)
ax_c.set_xticklabels(valid_labels, fontsize=FS_C_XTICK)
ax_c.tick_params(axis='x', length=0, pad=1.5)
ax_c.set_xlabel('')
ax_c.set_ylabel('Growth Rate', fontsize=FS_C_LABEL)
ax_c.yaxis.set_label_position('right')
ax_c.yaxis.tick_right()
ax_c.tick_params(axis='y', which='major', left=False, labelleft=False, right=True, labelright=True, labelsize=FS_C_YTICK, width=0.75, length=3.2, pad=2)
ax_c.yaxis.set_minor_locator(AutoMinorLocator(5))
ax_c.tick_params(axis='y', which='minor', left=False, right=True, width=0.55, length=1.8)
for spine in ax_c.spines.values():
    spine.set_alpha(0.9)
    spine.set_linewidth(0.75)
ax_c.grid(False)
ax_c.text(-0.0285, 1.2, 'c', transform=ax_c.transAxes, fontsize=FS_PANEL1, fontweight='bold', ha='left', va='top', zorder=20)
x0, x1 = ax_c.get_xlim()
y0, y1 = ax_c.get_ylim()
ax_c.set_facecolor('none')
ax_c.patch.set_alpha(0)
grad = np.tile(np.linspace(0, 1, 2048), (2, 1))
bg_cmap = LinearSegmentedColormap.from_list('bg_grad', ['#fbf7f9', '#fdf7f3', '#f5faf7', '#f4f8fc'])
ax_c.imshow(grad, extent=[x0, x1, y0, y1], origin='lower', aspect='auto', cmap=bg_cmap, alpha=1.0, zorder=-100, interpolation='bicubic')
ax_c.set_aspect('auto')
if SAVE_FIG:
    out_dir = os.path.dirname(OUT_FIG)
    if out_dir != '':
        os.makedirs(out_dir, exist_ok=True)
    fig.savefig(OUT_FIG, dpi=600, bbox_inches='tight', pad_inches=0.02)
    fig.savefig(OUT_FIG_PDF, bbox_inches='tight', pad_inches=0.02)
    print('Figure saved:')
    print(OUT_FIG)
    print(OUT_FIG_PDF)
plt.show()
