"""
Created on Fri Sep  4 14:10:54 2026

@author: yuping
"""
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from scipy.interpolate import Rbf
from matplotlib.patches import Ellipse
FONT_SCALE = 1.0
FIG_WIDTH = 7.2
FIG_HEIGHT = 5.9
FIG_DPI = 300
FS_PANEL = 15.5 * FONT_SCALE
FS_AXIS_LABEL = 11 * FONT_SCALE
FS_TICK = 11 * FONT_SCALE
FS_LEGEND = 9 * FONT_SCALE
FS_LEGEND1 = 10 * FONT_SCALE
FS_MAP_TITLE = 11 * FONT_SCALE
FS_MAP_TICK = 11 * FONT_SCALE
FS_CBAR_TICK = 11 * FONT_SCALE
FS_ANNOT = 11 * FONT_SCALE
LW_MAIN = 1.35
LW_FIT = 1.25
LW_AXIS = 0.75
LW_COAST = 0.25
LW_GRID = 0.32
LW_ELLIPSE = 0.9
S_SCATTER = 9
S_SCATTER_HIGHLIGHT = 12
SAVE_FIG = True
OUT_FIG = 'outputs/figures/figure_003.jpg'
OUT_FIG_PDF = 'outputs/figures/figure_004.pdf'
USE_EXISTING_INTERP = False
RECT_A = [0.075, 0.618, 0.255, 0.285]
RECT_B = [0.075, 0.26, 0.255, 0.285]
RECT_C = [0.41, 0.722, 0.5, 0.175]
RECT_D = [0.41, 0.482, 0.5, 0.175]
RECT_E = [0.41, 0.232, 0.5, 0.175]
CBAR_WIDTH = 0.012
CBAR_PAD = 0.01
CBAR_HEIGHT_RATIO = 0.9
N_LON_GRID = 200
N_LAT_GRID = 150
DIST_BREAK_KM = 4260.0
USE_ORIGINAL_BREAK_POINT_INDEX = True
BREAK_POINT_INDEX = 10
B_SCATTER_SIZE = 20
B_SCATTER_STEP = 2
B_SCATTER_COLOR = '#4C5963'
B_SCATTER_ALPHA = 0.55
B_XMIN_KM = 1000.0
B_XMAX_FACTOR = 1.5
B_COLOR_PRE_FIT = '#E67E22'
B_COLOR_POST_FIT = '#8E44AD'
B_COLOR_BREAK = '#43978F'
B_BREAK_MARKER_SIZE = 10
B_BREAK_MARKER_EDGEWIDTH = 1.7
mpl.rcParams.update({'font.family': 'Arial', 'font.size': FS_TICK, 'axes.linewidth': LW_AXIS, 'xtick.major.width': LW_AXIS, 'ytick.major.width': LW_AXIS, 'xtick.direction': 'in', 'ytick.direction': 'in', 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})
required_vars = ['dx', 'dy', 'phdx', 'phdy', 'W_pos_95', 'bin_centers', 'smoothed_counts', 'x_to_fit_1', 'y_to_fit_1', 'slope', 'x_line_1', 'y_line_1', 'x_to_fit_2', 'y_to_fit_2', 'slope_2', 'x_line_2', 'y_line_2', 'y_min_data', 'y_max_data', 'v250_wave5_composite']
if USE_EXISTING_INTERP:
    required_vars += ['lon2d', 'lat2d', 'out_interp', 'in_interp']
else:
    required_vars += ['lons', 'lats', 'out_degree', 'in_degree']
missing_vars = [v for v in required_vars if v not in globals()]
if len(missing_vars) > 0:
    raise NameError('当前环境缺少以下变量，请先运行对应子图的数据计算程序：\n' + '\n'.join(missing_vars))
if USE_EXISTING_INTERP:
    lon_grid = lon2d[0, :]
    lat_grid = lat2d[:, 0]
else:
    lon_grid = np.linspace(np.min(lons) - 2, np.max(lons) + 2, N_LON_GRID)
    lat_grid = np.linspace(-5, 90, N_LAT_GRID)
    lon2d, lat2d = np.meshgrid(lon_grid, lat_grid)
    print('RBF interpolation for existing out_degree...')
    rbf_out = Rbf(lons, lats, out_degree, function='multiquadric', smooth=2)
    out_interp = rbf_out(lon2d, lat2d)
    print('RBF interpolation for existing in_degree...')
    rbf_in = Rbf(lons, lats, in_degree, function='multiquadric', smooth=2)
    in_interp = rbf_in(lon2d, lat2d)
vplot = v250_wave5_composite.copy()
if vplot.lon.max() > 180:
    vplot = vplot.assign_coords(lon=(vplot.lon + 180) % 360 - 180).sortby('lon')
else:
    vplot = vplot.sortby('lon')
lat_values = vplot.lat.values
if lat_values[0] > lat_values[-1]:
    vplot = vplot.sel(lat=slice(90, -5))
else:
    vplot = vplot.sel(lat=slice(-5, 90))
lon_e = vplot.lon.values
lat_e = vplot.lat.values
region_boxes = {'China': {'lon_min': 95, 'lon_max': 130, 'lat_min': 20, 'lat_max': 50}, 'India': {'lon_min': 68, 'lon_max': 97, 'lat_min': 8, 'lat_max': 37}, 'America': {'lon_min': -110, 'lon_max': -70, 'lat_min': 25, 'lat_max': 55}, 'Europe': {'lon_min': 20, 'lon_max': 80, 'lat_min': 48, 'lat_max': 67}}

def add_region_ellipses(ax):
    for name, box in region_boxes.items():
        lon_c = (box['lon_min'] + box['lon_max']) / 2
        lat_c = (box['lat_min'] + box['lat_max']) / 2
        width = (box['lon_max'] - box['lon_min']) * 1.12
        height = (box['lat_max'] - box['lat_min']) * 1.25
        ellipse = Ellipse((lon_c, lat_c), width=width, height=height, angle=0, fill=False, edgecolor='#343434', linewidth=LW_ELLIPSE, linestyle='--', alpha=0.95, transform=ccrs.PlateCarree(), zorder=6)
        ax.add_patch(ellipse)

def add_panel_label(ax, label, x=-0.13, y=1.07):
    ax.text(x, y, label, transform=ax.transAxes, fontsize=FS_PANEL, fontweight='bold', va='top', ha='left', color='black')

def setup_map_ax(fig, rect):
    proj = ccrs.PlateCarree()
    ax = fig.add_axes(rect, projection=proj)
    ax._autoscaleXon = getattr(ax, '_autoscaleXon', True)
    ax._autoscaleYon = getattr(ax, '_autoscaleYon', True)
    ax.set_extent([np.nanmin(lon_grid), np.nanmax(lon_grid), -5, 90], crs=proj)
    ax.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=LW_COAST)
    ax.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
    gl = ax.gridlines(draw_labels=True, linestyle='--', linewidth=LW_GRID, alpha=0.5)
    import matplotlib.ticker as mticker
    gl.ylocator = mticker.FixedLocator([0, 35, 70])
    gl.xlocator = mticker.FixedLocator([-120, -60, 0, 60, 120])
    gl.top_labels = False
    gl.right_labels = False
    gl.xlabel_style = {'size': FS_MAP_TICK}
    gl.ylabel_style = {'size': FS_MAP_TICK}
    return ax

def add_compact_colorbar(fig, cf, rect, hide_every_other=False):
    cbar_height = rect[3] * CBAR_HEIGHT_RATIO
    cbar_bottom = rect[1] + (rect[3] - cbar_height) / 2
    cbar_left = rect[0] + rect[2] + CBAR_PAD
    cax = fig.add_axes([cbar_left, cbar_bottom, CBAR_WIDTH, cbar_height])
    cbar = fig.colorbar(cf, cax=cax, orientation='vertical')
    cbar.ax.tick_params(labelsize=FS_CBAR_TICK, width=0.7, length=2.5)
    cbar.outline.set_linewidth(0.35)
    all_ticks = cbar.get_ticks()
    if len(all_ticks) > 2:
        cbar.set_ticks(all_ticks[::2])
    if hide_every_other:
        for i, tick in enumerate(cbar.ax.yaxis.get_major_ticks()):
            if i % 2 == 1:
                tick.label1.set_visible(False)
                tick.tick1line.set_visible(False)
                tick.tick2line.set_visible(False)
        for i, label in enumerate(cbar.ax.get_yticklabels()):
            if i % 2 == 1:
                label.set_visible(False)
    return cbar
fig = plt.figure(figsize=(FIG_WIDTH, FIG_HEIGHT), dpi=FIG_DPI, facecolor='white')
proj = ccrs.PlateCarree()
ax_a = fig.add_axes(RECT_A)
ax_a.plot(dx, dy, color='#C24976', linewidth=LW_MAIN, label='Original data', alpha=0.95)
ax_a.plot(phdx, phdy, color='#828D93', linewidth=LW_MAIN, label='Shuffle data', alpha=0.95)
ax_a.plot(phdx, phdy, color='#7F8C8D', linewidth=0.75, alpha=0.95, zorder=2)
ax_a.axvline(x=W_pos_95, color='#F1A93B', linestyle='--', linewidth=1.1, alpha=0.85, label=f'99.5% percentile: {W_pos_95:.0f}')
ax_a.set_yscale('log')
ax_a.set_xlabel('$W$', fontsize=FS_AXIS_LABEL)
ax_a.set_ylabel('PDF', fontsize=FS_AXIS_LABEL)
ax_a.legend(loc='upper right', frameon=False, fontsize=FS_LEGEND, handletextpad=0.4, labelspacing=0.2, borderpad=0.0)
ax_a.tick_params(axis='both', which='major', labelsize=FS_TICK, pad=2.2, length=2.8, width=LW_AXIS)
ax_a.minorticks_off()
ax_a.grid(False)
ax_a.spines['top'].set_visible(False)
ax_a.spines['right'].set_visible(False)
ax_a.spines['left'].set_linewidth(LW_AXIS)
ax_a.spines['bottom'].set_linewidth(LW_AXIS)
add_panel_label(ax_a, 'a', x=-0.12, y=1.06)
ax_b = fig.add_axes(RECT_B)
if USE_ORIGINAL_BREAK_POINT_INDEX and len(bin_centers) > BREAK_POINT_INDEX:
    x_break = bin_centers[BREAK_POINT_INDEX]
    y_break = smoothed_counts[BREAK_POINT_INDEX]
else:
    x_break = DIST_BREAK_KM
    y_break = np.interp(x_break, bin_centers, smoothed_counts, left=np.nan, right=np.nan)
    if not np.isfinite(y_break):
        idx_break = np.nanargmin(np.abs(bin_centers - x_break))
        y_break = smoothed_counts[idx_break]
print(f'Break point = {x_break:.1f} km')
ax_b.scatter(bin_centers[::B_SCATTER_STEP], smoothed_counts[::B_SCATTER_STEP], color=B_SCATTER_COLOR, s=B_SCATTER_SIZE, alpha=B_SCATTER_ALPHA, edgecolor='none', zorder=2)
if slope is not None:
    ax_b.plot(x_line_1, y_line_1, color=B_COLOR_PRE_FIT, linewidth=LW_FIT, label=f'Power-law Fit ($k$={slope:.2f})', zorder=6)
if slope_2 is not None:
    x_line_2_plot = np.logspace(np.log10(x_line_2.min() * 0.8), np.log10(x_line_2.max() * 1.2), 200)
    log_intercept_2 = np.log10(y_line_2[0]) - slope_2 * np.log10(x_line_2[0])
    y_line_2_plot = 10 ** (slope_2 * np.log10(x_line_2_plot) + log_intercept_2)
    ax_b.plot(x_line_2_plot, y_line_2_plot, color=B_COLOR_POST_FIT, linewidth=LW_FIT, linestyle='-', zorder=6)
ax_b.axvline(x=x_break, color=B_COLOR_BREAK, linestyle='--', linewidth=1.05, alpha=0.7, zorder=1)
ax_b.plot(x_break, y_break, marker='o', markersize=B_BREAK_MARKER_SIZE, markerfacecolor='none', markeredgecolor=B_COLOR_BREAK, markeredgewidth=B_BREAK_MARKER_EDGEWIDTH, linestyle='none', zorder=8)
ax_b.text(x_break * 1.13, y_break * 1.38, f'{x_break:.0f} km', color=B_COLOR_BREAK, fontsize=FS_ANNOT, fontweight='bold', bbox=dict(facecolor='white', alpha=0.75, edgecolor='none', pad=0.7), zorder=9)
ax_b.set_xscale('log')
ax_b.set_yscale('log')
right_limit = np.nanmax(bin_centers) * B_XMAX_FACTOR
ax_b.set_xlim(B_XMIN_KM, right_limit)
ax_b.set_ylim(y_min_data * 0.3, y_max_data * 3)
ax_b.set_xlabel('Distance (km)', fontsize=FS_AXIS_LABEL)
ax_b.set_ylabel('PDF', fontsize=FS_AXIS_LABEL)
ax_b.tick_params(axis='both', which='major', labelsize=FS_TICK, length=3.0, width=LW_AXIS, pad=2.2)
ax_b.tick_params(axis='both', which='minor', length=1.8, width=0.55, color='#bdc3c7')
if slope is not None:
    ax_b.legend(loc='lower left', frameon=False, fontsize=FS_LEGEND1, handletextpad=0.45, labelspacing=0.3, borderpad=0.15)
ax_b.grid(False, which='both')
ax_b.spines['top'].set_visible(False)
ax_b.spines['right'].set_visible(False)
ax_b.spines['left'].set_linewidth(LW_AXIS)
ax_b.spines['bottom'].set_linewidth(LW_AXIS)
add_panel_label(ax_b, 'b', x=-0.12, y=1.06)
ax_c = setup_map_ax(fig, RECT_C)
vmin_c, vmax_c = (20, 180)
levels_c = np.linspace(vmin_c, vmax_c, 17)
cf_c = ax_c.contourf(lon2d, lat2d, out_interp, levels=levels_c, cmap='Purples', extend='both', alpha=0.85, transform=proj)
add_region_ellipses(ax_c)
add_panel_label(ax_c, 'c', x=-0.07, y=1.2)
ax_c.text(0.01, 1.15, 'Out degree', transform=ax_c.transAxes, fontsize=FS_MAP_TITLE, va='top', ha='left')
add_compact_colorbar(fig, cf_c, RECT_C)
ax_d = setup_map_ax(fig, RECT_D)
vmin_d, vmax_d = (20, 140)
levels_d = np.linspace(vmin_d, vmax_d, 13)
cf_d = ax_d.contourf(lon2d, lat2d, in_interp, levels=levels_d, cmap='Oranges', extend='both', alpha=0.85, transform=proj)
add_region_ellipses(ax_d)
add_panel_label(ax_d, 'd', x=-0.07, y=1.2)
ax_d.text(0.01, 1.15, 'In degree', transform=ax_d.transAxes, fontsize=FS_MAP_TITLE, va='top', ha='left')
add_compact_colorbar(fig, cf_d, RECT_D)
ax_e = fig.add_axes(RECT_E, projection=proj)
ax_e._autoscaleXon = getattr(ax_e, '_autoscaleXon', True)
ax_e._autoscaleYon = getattr(ax_e, '_autoscaleYon', True)
ax_e.set_extent([lon_e.min(), lon_e.max(), np.nanmin(lat_e), np.nanmax(lat_e)], crs=proj)
ax_e.add_feature(cfeature.COASTLINE.with_scale('50m'), lw=LW_COAST)
ax_e.add_feature(cfeature.LAND, facecolor='whitesmoke', alpha=0.8)
gl_e = ax_e.gridlines(draw_labels=True, linestyle='--', linewidth=LW_GRID, alpha=0.5)
import matplotlib.ticker as mticker
gl_e.ylocator = mticker.FixedLocator([0, 35, 70])
gl_e.xlocator = mticker.FixedLocator([-120, -60, 0, 60, 120])
gl_e.top_labels = False
gl_e.right_labels = False
gl_e.xlabel_style = {'size': FS_MAP_TICK}
gl_e.ylabel_style = {'size': FS_MAP_TICK}
vmax_e = 0.6
levels_e = np.linspace(-vmax_e, vmax_e, 13)
cf_e = ax_e.contourf(lon_e, lat_e, vplot.values, levels=levels_e, cmap='PuOr', extend='both', transform=proj)
add_panel_label(ax_e, 'e', x=-0.07, y=1.2)
ax_e.text(0.01, 1.15, '250 hPa meridional wind (wave-7)', transform=ax_e.transAxes, fontsize=FS_MAP_TITLE, va='top', ha='left')
add_compact_colorbar(fig, cf_e, RECT_E, hide_every_other=True)
if SAVE_FIG:
    out_dir = os.path.dirname(OUT_FIG)
    if out_dir != '':
        os.makedirs(out_dir, exist_ok=True)
    fig.savefig(OUT_FIG, dpi=600, bbox_inches='tight', pad_inches=0.02)
    fig.savefig(OUT_FIG_PDF, bbox_inches='tight', pad_inches=0.02)
    print('\nFigure saved:')
    print(OUT_FIG)
    print(OUT_FIG_PDF)
plt.show()
