import numpy as np
from figure3_core import spatial_seed_mask, regional_outgoing_incoming, spherical_kde_significance

def directional_degree(adjacency, tau):
    n = len(adjacency)
    out = np.zeros(n, dtype=int)
    incoming = np.zeros(n, dtype=int)
    for i, j in zip(*np.triu_indices(n, 1)):
        if adjacency[i, j]:
            source, target = (i, j) if tau[i, j] > 0 else (j, i)
        elif adjacency[j, i]:
            source, target = (j, i) if tau[j, i] > 0 else (i, j)
        else:
            continue
        if tau[i, j] == 0 and tau[j, i] == 0:
            continue
        out[source] += 1
        incoming[target] += 1
    return (out, incoming)

def regional_significant_fields(adjacency, tau, distance, lat, lon, region_lon, region_lat, direction='out', realizations=100, alpha=0.001):
    seed = spatial_seed_mask(lon, lat, region_lon, region_lat)
    fields = regional_outgoing_incoming(adjacency, tau, distance, seed)
    prefix = 'out' if direction == 'out' else 'in'
    near, far = (fields[prefix + '_near'], fields[prefix + '_far'])
    endpoints_near = np.repeat(np.arange(len(near)), near)
    endpoints_far = np.repeat(np.arange(len(far)), far)
    near_sig, near_density, near_threshold = spherical_kde_significance(endpoints_near, lat, lon, realizations, alpha, seed=1)
    far_sig, far_density, far_threshold = spherical_kde_significance(endpoints_far, lat, lon, realizations, alpha, seed=2)
    return {'near': near * near_sig, 'far': far * far_sig, 'near_density': near_density, 'far_density': far_density, 'near_threshold': near_threshold, 'far_threshold': far_threshold}
