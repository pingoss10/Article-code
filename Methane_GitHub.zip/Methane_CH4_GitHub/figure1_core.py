import numpy as np
from scipy.stats import linregress

def mean_and_growth_maps(ch4, years):
    data = np.asarray(ch4, dtype=float)
    t = np.asarray(years, dtype=float)
    if data.shape[0] != t.size:
        raise ValueError('First axis must match the time vector')
    mean = np.nanmean(data, axis=0)
    flat = data.reshape(data.shape[0], -1)
    slopes = np.full(flat.shape[1], np.nan)
    for i in range(flat.shape[1]):
        ok = np.isfinite(flat[:, i]) & np.isfinite(t)
        if ok.sum() >= 2:
            slopes[i] = linregress(t[ok], flat[ok, i]).slope
    return (mean, slopes.reshape(data.shape[1:]))

def geographic_region_series(ch4, lat, lon, lat_bounds, lon_bounds):
    lons = np.mod(np.asarray(lon), 360)
    west, east = np.mod(lon_bounds, 360)
    lat_select = (np.asarray(lat) >= lat_bounds[0]) & (np.asarray(lat) <= lat_bounds[1])
    lon_select = (lons >= west) & (lons <= east) if west <= east else (lons >= west) | (lons <= east)
    if not np.any(lat_select) or not np.any(lon_select):
        raise ValueError('Region does not overlap the input grid')
    return np.nanmean(np.asarray(ch4)[:, lat_select, :][:, :, lon_select], axis=(1, 2))

def regional_growth_statistics(slopes, masks):
    return {name: np.asarray(slopes)[mask][np.isfinite(np.asarray(slopes)[mask])] for name, mask in masks.items()}
