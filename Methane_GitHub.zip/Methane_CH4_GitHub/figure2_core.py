import numpy as np
from scipy.interpolate import Rbf
from lagged_network import significant_links, surrogate_weight_threshold

def degree_fields(weights, tau, surrogate_weights):
    threshold = surrogate_weight_threshold(surrogate_weights)
    links = significant_links(weights, threshold, tau)
    n = len(weights)
    out_degree = np.zeros(n, dtype=int)
    in_degree = np.zeros(n, dtype=int)
    for i, j in zip(*np.triu_indices(n, 1)):
        if links[i, j]:
            source, target = (i, j) if tau[i, j] > 0 else (j, i)
        elif links[j, i]:
            source, target = (j, i) if tau[j, i] > 0 else (i, j)
        else:
            continue
        out_degree[source] += 1
        in_degree[target] += 1
    return (out_degree, in_degree, threshold)

def interpolate_degree(lon, lat, degree, target_lon, target_lat):
    rbf = Rbf(np.asarray(lon), np.asarray(lat), np.asarray(degree), function='multiquadric', smooth=2)
    return rbf(target_lon, target_lat)

def edge_weight_distributions(real_weights, surrogate_weights, bins=100):
    indices = np.triu_indices(real_weights.shape[0], k=1)
    real = np.asarray(real_weights)[indices]
    null = np.asarray(surrogate_weights)
    null = null.mean(axis=0)[indices] if null.ndim == 3 else null[indices]
    edges = np.histogram_bin_edges(np.r_[real[np.isfinite(real)], null[np.isfinite(null)]], bins=bins)
    return (edges, np.histogram(real, edges, density=True)[0], np.histogram(null, edges, density=True)[0])
