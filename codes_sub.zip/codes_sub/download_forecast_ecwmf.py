#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 11:33:00 2024

@author: meng
"""

from ecmwfapi import ECMWFDataServer

server = ECMWFDataServer()

def t2m_download_fc():
    for years in range(2007,2025):
        server.retrieve({
            "class": "ti",
            "dataset": "tigge",
            "date": ""+str(years)+"-01-01/to/"+str(years)+"-12-31",
            "expver": "prod",
            "grid": "2.5/2.5",
            "levtype": "sfc",
            "origin": "ecmf",
            "param": "167",
            "step": "360",
            "time": "00:00:00",
            "type": "fc",
            "target": "/home/meng/awpsd/data/origin/t2m_forecast15d_ecwmf_"+str(years)+""
        })
        
    
    
def t850_download_fc():
    #!/usr/bin/env python
    from ecmwfapi import ECMWFDataServer
    
    server = ECMWFDataServer()
    for years in range(2013,2025):
        server.retrieve({
            "class": "ti",
            "dataset": "tigge",
            "date": ""+str(years)+"-01-01/to/"+str(years)+"-12-31",
            "expver": "prod",
            "grid": "2.5/2.5",
            "levelist": "850",
            "levtype": "pl",
            "origin": "ecmf",
            "param": "130",
            "step": "120",
            "time": "00:00:00",
            "type": "cf",
            "target": "/home/meng/awpsd/data/origin/t850_forecast5d_ecwmf_"+str(years)+""
        })     


def t2m_download_cf():

#!/usr/bin/env python
    from ecmwfapi import ECMWFDataServer
    
    server = ECMWFDataServer()
    for years in range(2015,2025):    
        server.retrieve({
            "class": "ti",
            "dataset": "tigge",
            "date": ""+str(years)+"-01-01/to/"+str(years)+"-12-31",
            "expver": "prod",
            "grid": "2.5/2.5",
            "levtype": "sfc",
            "origin": "ecmf",
            "param": "167",
            "step": "360",
            "time": "00:00:00",
            "type": "cf",
            "target": "/home/meng/awpsd/data/origin/t2m_cf15d_ecwmf_"+str(years)+""
        })

