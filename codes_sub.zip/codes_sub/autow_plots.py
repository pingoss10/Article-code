#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  3 14:03:38 2023

@author: meng
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 23:02:34 2023

@author: meng
"""



import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
from numpy import pi, e


def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,tau+1):
        x1=x[tau:l+tau]
        x2=x[tau+t:l+t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    w=(1-np.mean(z))/np.std(z)
    return z,w


def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def autowc(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)*1/np.sqrt(2*tau)
    return a


def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def hurst_rs(price_series):
    """
    Calculates the Hurst Exponent using the Rescaled Range (R/S) analysis method.
    """
    # Compute log returns
    log_returns = np.diff(np.log(price_series))
    
    # Create an array of lag values
    lags = range(2, 100)
    
    # Calculate the array of the variances of the lagged differences
    tau = [np.sqrt(np.std(np.subtract(log_returns[lag:], log_returns[:-lag]))) for lag in lags]
    
    # Use a linear fit to estimate the Hurst Exponent
    poly = np.polyfit(np.log(lags), np.log(tau), 1)
    
    # The Hurst exponent is the slope of the linear fit
    hurst_exponent = poly[0]*2.0
    
    # The fractal dimension is related to the Hurst exponent
    fractal_dimension = 2 - hurst_exponent
    
    return hurst_exponent, fractal_dimension
def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def phasex(x,c):
    fx=np.fft.fft(x)
    phx=np.angle(fx)
    mag=np.abs(fx)
    mag1=list(mag[:c])+list(mag[c:-c]*math.exp(-10))+list(mag[-c:])
    mag2=list(mag[:c]*math.exp(-10))+list(mag[c:-c])+list(mag[-c:]*math.exp(-10))
    fy1=mag1*e**(1j*phx)
    fy2=mag2*e**(1j*phx)
    fz1=np.fft.ifft(fy1)
    fz2=np.fft.ifft(fy2)
    z1=np.real(fz1)
    z2=np.real(fz2)
    return z1,z2
    



import numpy as np
from scipy.stats import linregress

def dfa(x, min_window=4, max_window=None, window_step=1, order=1):
    """
    简单的 Detrended Fluctuation Analysis (DFA) 实现。
    
    参数:
    x : array_like
        时间序列数据。
    min_window : int
        最小窗口大小（默认 4）。
    max_window : int, 可选
        最大窗口大小（默认 len(x)//4）。
    window_step : int
        窗口大小步长（默认 1）。
    order : int
        去趋势多项式阶数（默认 1，即线性）。
    
    返回:
    windows : array
        窗口大小数组。
    fluctuations : array
        对应波动 F(s) 数组。
    alpha : float
        DFA 指数（log-log 拟合斜率）。
    """
    x = np.asarray(x)
    if max_window is None:
        max_window = len(x) // 4
    
    # 步骤 1: 计算累积和（积分序列）
    y = np.cumsum(x - np.mean(x))
    
    # 生成窗口大小序列
    windows = np.arange(min_window, max_window + 1, window_step)
    fluctuations = []
    
    for s in windows:
        # 步骤 2: 分箱
        n_boxes = len(y) // s
        rms_list = []
        
        for i in range(n_boxes):
            start = i * s
            end = start + s
            box = y[start:end]
            
            # 步骤 3: 多项式拟合去趋势
            t = np.arange(len(box))
            coeffs = np.polyfit(t, box, order)
            fit = np.polyval(coeffs, t)
            
            # 步骤 4: 计算 RMS 波动
            detrended = box - fit
            rms_list.append(np.sqrt(np.mean(detrended**2)))
        
        # 步骤 5: 平均 RMS
        avg_rms = np.mean(rms_list)
        fluctuations.append(avg_rms)
    
    # 步骤 6: log-log 拟合求 alpha
    exponents = np.log10(windows)
    log_fluc = np.log10(fluctuations)
    slope, _, _, _, _ = linregress(exponents, log_fluc)
    
    return windows, np.array(fluctuations), slope

# 示例用法：白噪声测试（alpha 应接近 0.5）
np.random.seed(42)
x_white = np.random.randn(1000)  # 生成白噪声
windows, fluc, alpha = dfa(x_white)
print(f"白噪声 DFA alpha: {alpha:.3f}")  # 输出约 0.521

# 示例：粉噪声（1/f 噪声，alpha 应接近 1.0）
# 你可以用 sim_powerlaw 或其他生成
x_pink = np.cumsum(np.random.randn(1000)) / np.arange(1, 1001)  # 简单近似
windows, fluc, alpha_pink = dfa(x_pink)
print(f"粉噪声 DFA alpha: {alpha_pink:.3f}")


def white_noise():
    N=2000
    po=1
    tau=100
    l=1000
    z=np.random.uniform(-1,1,N)
    z1,z2=phasex(z,20)
    trendx=100*pow(np.arange(N)/N,po)
    z3=np.array(z2)+np.array(trendx)
    c1,w1=autoca(z1,tau,l)
    c2,w2=autoca(z,tau,l)
    c3,w3=autoca(z3,tau,l)
    plt.plot(c1)
    plt.plot(c2)
    plt.plot(c3)
    print(w1/np.sqrt(2*tau),w2/np.sqrt(2*tau),w3/np.sqrt(2*tau),c1[tau+1],c2[tau+1],c3[tau+1])
    
def plotfig1a():    
 
    import matplotlib.pyplot as plt
    import numpy as np
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes  # 新增导入   
    from matplotlib.patches import Rectangle  # 新增导入：用于矩形框
    # 生成示例数据
    x = np.linspace(0, 2000, 2000)  # x 轴数据（0 到 10，100 个点）
    plt.rcParams['font.family'] = 'Times New Roman'    
    fig, axs = plt.subplots(3, 1, figsize=(8, 10), sharex=True, constrained_layout=True)

# 进一步压缩垂直间隙（可选，如果 constrained_layout 不够紧）
    plt.subplots_adjust(hspace=0)  # hspace=0 让子图紧贴    
    # 绘制第一张图



    axs[0].plot(x, z, color='#5e4c5f', linewidth=2)
    axs[0].set_ylabel('White Noise',fontsize=28)
    axs[0].set_xlim(800, 1400)
    axs[0].set_ylim(-1.5, 3.5)

    axs[0].xaxis.set_major_locator(MultipleLocator(200))
    axs[0].xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[0].xaxis.set_minor_locator(MultipleLocator(100))
    axs[0].yaxis.set_major_locator(MultipleLocator(1))
    axs[0].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[0].yaxis.set_minor_locator(MultipleLocator(0.2))
    axs[0].tick_params(which='both', width=1.2, labelsize=32)
    axs[0].tick_params(which='major', length=10)
    axs[0].tick_params(which='minor', length=5)
  #  axs[0].grid(True)

    x_start, x_end = 1000, 1100
    y_max,y_min=-1.2,1.2

    width = x_end - x_start
    height = y_max - y_min
    rect = Rectangle((x_start, y_min), width, height, 
                     fill=False, edgecolor='k', linestyle='--', linewidth=2, zorder=3)
    axs[0].add_patch(rect)

    axins = fig.add_axes([0.6, 0.88, 0.3, 0.1])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x, z, color='#5e4c5f', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(-1.5, 1.5)
    axins.set_xlabel('Steps',fontsize=22)
    #axins.set_ylabel('White Noise',fontsize=24)

    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(1))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.5))
    axins.tick_params(which='both', width=1.2, labelsize=22)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    
    
    # 第二张图
    axs[1].plot(x, z1, color='#999999', linewidth=2)
    axs[1].set_ylabel('Low Pass Filter',fontsize=28)
    axs[1].set_ylim(-0.25, 0.25)  # 可选：一致范围

    axs[1].yaxis.set_major_locator(MultipleLocator(0.1))
    axs[1].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[1].yaxis.set_minor_locator(MultipleLocator(0.05))
    axs[1].tick_params(which='both', width=1.2, labelsize=32)
    axs[1].tick_params(which='major', length=10)
    axs[1].tick_params(which='minor', length=5)

    x_start, x_end = 1000, 1100
    y_min, y_max = -0.1, 0.12# 修复：全高
    width = x_end - x_start
    height = y_max - y_min
    rect = Rectangle((x_start, y_min), width, height, 
                     fill=False, edgecolor='k', linestyle='--', linewidth=2, zorder=3)
    axs[1].add_patch(rect)
    

    
    # 第三张图
    axs[2].plot(x, z3, color='#ffbb6f', linewidth=2)
    axs[2].set_ylabel('Strong Linear Trend',fontsize=28)
    axs[2].set_xlabel('Steps',fontsize=28)
  #  axs[2].set_ylim(0, max(z3) * 1.1)  # 调整为趋势范围
    axs[2].set_ylim(15, 80)  # 调整为趋势范围

    axs[2].xaxis.set_major_locator(MultipleLocator(200))
    axs[2].xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[2].xaxis.set_minor_locator(MultipleLocator(100))
    axs[2].yaxis.set_major_locator(MultipleLocator(10))
    axs[2].yaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[2].yaxis.set_minor_locator(MultipleLocator(5))
    axs[2].tick_params(which='both', width=1.2, labelsize=32)
    axs[2].tick_params(which='major', length=10)
    axs[2].tick_params(which='minor', length=5)


    x_start, x_end = 1000, 1100
    y_min, y_max = 45, 60 # 修复：全高
    width = x_end - x_start
    height = y_max - y_min
    rect = Rectangle((x_start, y_min), width, height, 
                     fill=False, edgecolor='k', linestyle='--', linewidth=2, zorder=3)
    axs[2].add_patch(rect)
    
    axins = fig.add_axes([0.6, 0.07, 0.3, 0.1])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x, z3, color='#ffbb6f', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(49, 56)
    axins.set_xlabel('Steps',fontsize=28)    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(5))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.yaxis.set_minor_locator(MultipleLocator(1))
    axins.tick_params(which='both', width=1.2, labelsize=32)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    
    
    # plt.annotate('h', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=64,weight='bold',
    #                              xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
    #                              ha='left', va='bottom')    
   
    plt.subplots_adjust(top = 0.99, bottom = 0.05, right = 0.95, left = 0.1, 
                hspace = 0., wspace = 0.15)   
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(14, 24)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    #plt.savefig("/home/meng/paper/figs/example6.pdf",dpi=300) 
    plt.savefig("/home/meng/awpsd/fig/fig1a.png",dpi=300) 



def plotfig1b():    
   


    import matplotlib.pyplot as plt
    import numpy as np
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes  # 新增导入   
    from matplotlib.patches import Rectangle  # 新增导入：用于矩形框
    # 生成示例数据
    x = np.linspace(-100,100, 201)  # x 轴数据（0 到 10，100 个点）
    
    fig, axs = plt.subplots(3, 1, figsize=(8, 10), sharex=True, constrained_layout=True)

# 进一步压缩垂直间隙（可选，如果 constrained_layout 不够紧）
    plt.subplots_adjust(hspace=0)  # hspace=0 让子图紧贴    
    # 绘制第一张图



    axs[0].plot(x, c2, color='#5e4c5f', linewidth=2)
    axs[0].set_ylabel('C',fontsize=28,rotation=0,labelpad=20)
    axs[0].set_xlim(-100, 100)
    axs[0].set_ylim(-0.1, 1.1)

    axs[0].xaxis.set_major_locator(MultipleLocator(20))
    axs[0].xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[0].xaxis.set_minor_locator(MultipleLocator(10))
    axs[0].yaxis.set_major_locator(MultipleLocator(0.2))
    axs[0].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[0].yaxis.set_minor_locator(MultipleLocator(0.1))
    axs[0].tick_params(which='both', width=1.2, labelsize=32)
    axs[0].tick_params(which='major', length=10)
    axs[0].tick_params(which='minor', length=5)
  #  axs[0].grid(True)

    
    # 第二张图
    axs[1].plot(x, c1, color='#999999', linewidth=2)
    axs[1].set_ylabel(r'C',fontsize=28,rotation=-90)
    axs[1].set_ylim(-0.1, 1.1)  # 可选：一致范围

    axs[1].yaxis.set_major_locator(MultipleLocator(0.2))
    axs[1].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[1].yaxis.set_minor_locator(MultipleLocator(0.1))
    axs[1].tick_params(which='both', width=1.2, labelsize=32)
    axs[1].tick_params(which='major', length=10)
    axs[1].tick_params(which='minor', length=5)

   

    
    # 第三张图
    axs[2].plot(x, c3, color='#ffbb6f', linewidth=2)
    axs[2].set_ylabel(r'C',fontsize=28)
    axs[2].set_xlabel(r'$\tau$',fontsize=28)
  #  axs[2].set_ylim(0, max(z3) * 1.1)  # 调整为趋势范围
    axs[2].set_ylim(-0.1, 1.1)  # 调整为趋势范围

    axs[2].xaxis.set_major_locator(MultipleLocator(50))
    axs[2].xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[2].xaxis.set_minor_locator(MultipleLocator(25))
    axs[2].yaxis.set_major_locator(MultipleLocator(0.2))
    axs[2].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[2].yaxis.set_minor_locator(MultipleLocator(0.1))
    axs[2].tick_params(which='both', width=1.2, labelsize=32)
    axs[2].tick_params(which='major', length=10)
    axs[2].tick_params(which='minor', length=5)


    x_start, x_end = -20, 20
    y_min, y_max = 0.95, 1.05 # 修复：全高
    width = x_end - x_start
    height = y_max - y_min
    rect = Rectangle((x_start, y_min), width, height, 
                     fill=False, edgecolor='k', linestyle='--', linewidth=2, zorder=3)
    axs[2].add_patch(rect)
    
    axins = fig.add_axes([0.55, 0.1, 0.35, 0.15])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x, c3, color='#ffbb6f', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(-30, 30)
    axins.set_ylim(0.998, 1.0002)
    axins.set_xlabel(r'$\tau$',fontsize=28)    
    axins.set_ylabel(r'C',fontsize=28, rotation=45)  
    axins.xaxis.set_major_locator(MultipleLocator(12))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(6))
    axins.yaxis.set_major_locator(MultipleLocator(0.002))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.001))
    axins.tick_params(which='both', width=1.2, labelsize=32)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    
 
   
    plt.subplots_adjust(top = 0.99, bottom = 0.03, right = 0.95, left = 0.15, 
                hspace = 0., wspace = 0.15)   
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(10, 24)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    #plt.savefig("/home/meng/paper/figs/example6.pdf",dpi=300) 
    plt.savefig("/home/meng/awpsd/fig/fig1b.png",dpi=300) 

def plotfig1ab():    
 
    import matplotlib.pyplot as plt
    import numpy as np
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes  # 新增导入   
    from matplotlib.patches import Rectangle  # 新增导入：用于矩形框
    # 生成示例数据
    x = np.linspace(-100,100,201)  # x 轴数据（0 到 10，100 个点）
    x0=np.linspace(0,2000,2000)
    
    fig, axs = plt.subplots(3, 1, figsize=(8, 10), sharex=True, constrained_layout=True)

# 进一步压缩垂直间隙（可选，如果 constrained_layout 不够紧）
    plt.subplots_adjust(hspace=0)  # hspace=0 让子图紧贴    
    # 绘制第一张图



    axs[0].plot(x, c2, color='#1a80bb', linewidth=3)
    axs[0].set_ylabel('AutoCorr',fontsize=36,labelpad=50)
    axs[0].set_xlim(-100, 100)
    axs[0].set_ylim(-0.1, 1.1)

    axs[0].xaxis.set_major_locator(MultipleLocator(20))
    axs[0].xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[0].xaxis.set_minor_locator(MultipleLocator(10))
    axs[0].yaxis.set_major_locator(MultipleLocator(0.2))
    axs[0].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[0].yaxis.set_minor_locator(MultipleLocator(0.1))
    axs[0].tick_params(which='both', width=2.5, labelsize=36)
    axs[0].tick_params(which='major', length=10)
    axs[0].tick_params(which='minor', length=5)
    axs[0].tick_params(axis='x', which='both', labelbottom=False)

    axins = fig.add_axes([0.6, 0.85, 0.32, 0.1])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z, color='#1a80bb', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(-1.5, 1.6)
    axins.set_xlabel('Steps',fontsize=30)
    axins.set_title('White Noise',fontsize=36)

    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(1))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.5))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    
    
    
    # 第二张图
    axs[1].plot(x, c1, color='#ea801c', linewidth=3)
    axs[1].set_ylabel('AutoCorr',fontsize=36,labelpad=50)
    axs[1].set_ylim(-0.1, 1.1)  # 可选：一致范围

    axs[1].yaxis.set_major_locator(MultipleLocator(0.2))
    axs[1].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axs[1].yaxis.set_minor_locator(MultipleLocator(0.1))
    axs[1].tick_params(which='both', width=2.5, labelsize=36)
    axs[1].tick_params(which='major', length=10)
    axs[1].tick_params(which='minor', length=5)
    axs[1].tick_params(axis='x', which='both', labelbottom=False)
   

    axins = fig.add_axes([0.68, 0.55, 0.25, 0.1])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z1, color='#ea801c', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(500, 1100)
    axins.set_ylim(-0.2, 0.2)
    axins.set_xlabel('Steps',fontsize=34)    
    axins.set_title('Low Pass Filter',fontsize=36)    
    axins.xaxis.set_major_locator(MultipleLocator(500))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(250))
    axins.yaxis.set_major_locator(MultipleLocator(0.15))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.05))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  

    
    # 第三张图
    axs[2].plot(x, c3, color='#b8b8b8', linewidth=3)
    axs[2].set_ylabel('AutoCorr',fontsize=36,labelpad=10)
    axs[2].set_xlabel(r'$\tau$',fontsize=36)
  #  axs[2].set_ylim(0, max(z3) * 1.1)  # 调整为趋势范围
    axs[2].set_ylim(0.9981, 1.0002)  # 调整为趋势范围

    axs[2].xaxis.set_major_locator(MultipleLocator(50))
    axs[2].xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axs[2].xaxis.set_minor_locator(MultipleLocator(25))
    axs[2].yaxis.set_major_locator(MultipleLocator(0.001))
    axs[2].yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    axs[2].yaxis.set_minor_locator(MultipleLocator(0.0005))
    axs[2].tick_params(which='both', width=2.5, labelsize=36)
    axs[2].tick_params(which='major', length=10)
    axs[2].tick_params(which='minor', length=5)



    
    axins = fig.add_axes([0.6, 0.2, 0.32, 0.1])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z3, color='#b8b8b8', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(49, 56)
    axins.set_xlabel('Steps',fontsize=34)    
    axins.set_title('Strong Linear Trend',fontsize=36)    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(5))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.yaxis.set_minor_locator(MultipleLocator(1))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    
    
    # plt.annotate('h', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=64,weight='bold',
    #                              xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
    #                              ha='left', va='bottom')    
   
    plt.subplots_adjust(top = 0.99, bottom = 0.05, right = 0.95, left = 0.1, 
                hspace = 0., wspace = 0.15)   
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(18, 24)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    #plt.savefig("/home/meng/paper/figs/example6.pdf",dpi=300) 
    plt.savefig("/home/meng/awpsd/fig/fig1ab.pdf",dpi=300,bbox_inches='tight') 


def plotfig1c():
    px=np.arange(0,1,0.01)
    murange=np.arange(3.4,4,0.01)
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix30.dat')
    mixwl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix100.dat')
    mixwl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist30.dat')
    wl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist100.dat')
    wl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]

    fig, axs = plt.subplots(2, 2, figsize=(24, 18), sharey='row')  # 每行共用 y 轴
    
    # 然后用 axs[row][col] 分别替代你之前的 plt.subplot(221)... 等
    pp=np.sqrt(20)
    
    # 第1行第1列：axs[0][0]
    ax1 = axs[0][0]
    # ax1.set_xlim(500, 1100)
    ax1.set_ylim(0, 1)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax1.xaxis.set_major_locator(xmajorLocator)
    ax1.xaxis.set_major_formatter(xmajorFormatter)
    ax1.yaxis.set_major_locator(ymajorLocator)
    ax1.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax1.xaxis.set_minor_locator(xminorLocator)
    ax1.yaxis.set_minor_locator(yminorLocator) 
    ax1.tick_params(which='both', width=3,labelsize=34)
    ax1.tick_params(which='major', length=10)  
    ax1.tick_params(which='minor',length=5)

    
    ax1.set_xlabel('$p$', fontsize=36)
    ax1.set_ylabel('$W_{ACF}$', fontsize=36)

    


    ax1.scatter(px,mixwl30[2]/pp, s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    ax2.scatter(px,mixwl30[1]/pp, s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    ax1.scatter(px,mixwl30[0]/pp, s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    ax1.scatter(px,mixwl30[3]/pp, s=150, label='f=1/500',marker='+',c='#118ab2')
    ax1.scatter(px,mixwl30[4]/pp, s=150, label='f=1/1000',marker='+',c='#073b4c')
    ax1.legend(fontsize=36, loc=1, bbox_to_anchor=(0.95, 0.5))

   # ax1.legend(fontsize=28)
    ax1.set_title('$MIX(p),\ N=30$',fontsize=36)
    # ax1.set_annotate('a', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=28,weight='bold',
    #                      xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
    #                      ha='left', va='bottom')     
    
    # 第1行第2列：axs[0][1]
    ax2 = axs[0][1]

    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax2.xaxis.set_major_locator(xmajorLocator)
    ax2.xaxis.set_major_formatter(xmajorFormatter)
    ax2.yaxis.set_major_locator(ymajorLocator)
    ax2.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax2.xaxis.set_minor_locator(xminorLocator)
    ax2.yaxis.set_minor_locator(yminorLocator) 
    ax2.tick_params(which='both', width=3,labelsize=34)
    ax2.tick_params(which='major', length=10)  
    ax2.tick_params(which='minor',length=5)

    
    ax2.set_xlabel('$p$', fontsize=36)
    #ax1.set_ylabel('$W_{ACF}$', fontsize=28)

   # plt.ylabel('$W_{ACF}$',fontsize=24)
    
   
    ax2.scatter(px,mixwl100[2]/pp, s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    ax2.scatter(px,mixwl100[1]/pp, s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    ax2.scatter(px,mixwl100[0]/pp, s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    ax2.scatter(px,mixwl100[3]/pp, s=150, label='f=1/500',marker='+',c='#118ab2')
    ax2.scatter(px,mixwl100[4]/pp, s=150, label='f=1/1000',marker='+',c='#073b4c')
   

   # plt.legend(fontsize=24)
    ax2.set_title('$MIX(p),\ N=100$',fontsize=36)
    # plt.annotate('b', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=31,weight='bold',
    #                      xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
    #                      ha='left', va='bottom')     
        
    # 第2行第1列：axs[1][0]
    ax6.set_ylim(0,1)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax6.xaxis.set_major_locator(xmajorLocator)
    ax6.xaxis.set_major_formatter(xmajorFormatter)
    ax6.yaxis.set_major_locator(ymajorLocator)
    ax6.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax6.xaxis.set_minor_locator(xminorLocator)
    ax6.yaxis.set_minor_locator(yminorLocator) 
    ax6.tick_params(which='both', width=3,labelsize=34)
    ax6.tick_params(which='major', length=10)  
    ax6.tick_params(which='minor',length=5)

    
    ax6.set_xlabel('$\mu$', fontsize=36)
    ax6.set_ylabel('$W_{ACF}$', fontsize=36)
    

    
   
    ax6.scatter(murange,wl30[2]/pp, s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    ax6.scatter(murange,wl30[1]/pp, s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    ax6.scatter(murange,wl30[0]/pp, s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    ax6.scatter(murange,wl30[3]/pp, s=150, label='f=1/500',marker='+',c='#118ab2')
    ax6.scatter(murange,wl30[4]/pp, s=150, label='f=1/1000',marker='+',c='#073b4c')

   # ax6.legend(fontsize=28)
    ax6.set_title('$Logistic(\mu),\ N=30$',fontsize=36)

    
    # 第2行第2列：axs[1][1]
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax7.xaxis.set_major_locator(xmajorLocator)
    ax7.xaxis.set_major_formatter(xmajorFormatter)
    ax7.yaxis.set_major_locator(ymajorLocator)
    ax7.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax7.xaxis.set_minor_locator(xminorLocator)
    ax7.yaxis.set_minor_locator(yminorLocator) 
    ax7.tick_params(which='both', width=3,labelsize=34)
    ax7.tick_params(which='major', length=10)  
    ax7.tick_params(which='minor',length=5)

    ax7.set_xlabel('$\mu$', fontsize=36)
   # ax6.set_ylabel('$W_{ACF}$', fontsize=28)
    
   
    ax7.scatter(murange,wl100[2]/pp, s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    ax7.scatter(murange,wl100[1]/pp, s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    ax7.scatter(murange,wl100[0]/pp, s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    ax7.scatter(murange,wl100[3]/pp, s=150, label='f=1/500',marker='+',c='#118ab2')
    ax7.scatter(murange,wl100[4]/pp, s=150, label='f=1/1000',marker='+',c='#073b4c')

    ax7.set_title('$Logistic(\mu),\ N=100$',fontsize=36)
    # plt.annotate('d', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=28,weight='bold',
    #                      xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
    #                      ha='left', va='bottom')    
        

    plt.subplots_adjust(top = 0.9, bottom = 0.15, right = 0.95, left = 0.1, 
                hspace = 0.2, wspace = 0.0)   
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(32, 30)


    plt.savefig("/home/meng/awpsd/fig/fig1c.pdf",dpi=300,bbox_inches='tight') 
    
    
def plotfig2():
    path='/home/meng/awpsd/data/'
    wacf=np.loadtxt(path+"t2m_autowc10d_era5_monthly_1980.dat")
    wacfx=np.reshape(wacf,(528,8040))
    ext=np.loadtxt(path+"t2m_ext_era5_ori_monthly1_1980.dat")
    extx=np.reshape(ext[:,1],(528,8040))
    
    
    
    
    
    
    

def figcomb():
    N=2000
    po=1
    tau=100
    l=1000
    z=np.random.uniform(-1,1,N)
    z1,z2=phasex(z,20)
    trendx=100*pow(np.arange(N)/N,po)
    z3=np.array(z2)+np.array(trendx)
    c1,w1=autoca(z1,tau,l)
    c2,w2=autoca(z,tau,l)
    c3,w3=autoca(z3,tau,l)
    plt.plot(c1)
    plt.plot(c2)
    plt.plot(c3)
    print(w1/np.sqrt(2*tau),w2/np.sqrt(2*tau),w3/np.sqrt(2*tau),c1[tau+1],c2[tau+1],c3[tau+1])
    
    fig = plt.figure()
    ax1 = plt.subplot2grid((6, 3), (0, 0), rowspan=2)
    ax2 = plt.subplot2grid((6, 3), (2, 0), rowspan=2,sharex=ax1)
    ax3 = plt.subplot2grid((6, 3), (4, 0), rowspan=2,sharex=ax1)
    ax4 = plt.subplot2grid((6, 3), (0, 1), rowspan=3)
    ax5 = plt.subplot2grid((6, 3), (0, 2), rowspan=3,sharey=ax4)    
    ax6 = plt.subplot2grid((6, 3), (3, 1), rowspan=3)
    ax7 = plt.subplot2grid((6, 3), (3, 2), rowspan=3,sharey=ax6)
    

    
    x = np.linspace(-100,100,201)  # x 轴数据（0 到 10，100 个点）
    x0=np.linspace(0,2000,2000)
    

    ax1.plot(x, c2, color='#4fb9fc', linewidth=3)
    ax1.set_ylabel('AutoCorr',fontsize=36,labelpad=50)
    ax1.set_xlim(-100, 100)
    ax1.set_ylim(-0.2, 2.2)

    ax1.xaxis.set_major_locator(MultipleLocator(20))
    ax1.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    ax1.xaxis.set_minor_locator(MultipleLocator(10))
    ax1.yaxis.set_major_locator(MultipleLocator(0.5))
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax1.yaxis.set_minor_locator(MultipleLocator(0.1))
    ax1.tick_params(which='both', width=2.5, labelsize=36)
    ax1.tick_params(which='major', length=10)
    ax1.tick_params(which='minor', length=5)
    ax1.tick_params(axis='x', which='both', labelbottom=False)

    axins = fig.add_axes([0.13, 0.8, 0.2, 0.08])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z, color='#4fb9fc', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(-1.5, 1.6)
   # axins.set_xlabel('Steps',fontsize=30)
    axins.set_title('White Noise',fontsize=36)
    axins.set_facecolor('#2c425b')
    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(1))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.5))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    axins.tick_params(axis='x', which='both', labelbottom=False)
    
    
    
    # 第二张图
    ax2.plot(x, c1, color='#2581eb', linewidth=3)
    ax2.set_ylabel('AutoCorr',fontsize=36,labelpad=50)
    ax2.set_ylim(-0.01, 2.1)  # 可选：一致范围

    ax2.yaxis.set_major_locator(MultipleLocator(0.5))
    ax2.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax2.yaxis.set_minor_locator(MultipleLocator(0.1))
    ax2.tick_params(which='both', width=2.5, labelsize=36)
    ax2.tick_params(which='major', length=10)
    ax2.tick_params(which='minor', length=5)
    ax2.tick_params(axis='x', which='both', labelbottom=False)
   

    axins = fig.add_axes([0.13, 0.54, 0.2, 0.08])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z1, color='#2581eb', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(500, 1100)
    axins.set_ylim(-0.25, 0.2)
    #axins.set_xlabel('Steps',fontsize=34)    
    axins.set_title('Low Pass Filter',fontsize=36)    
    axins.xaxis.set_major_locator(MultipleLocator(500))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(250))
    axins.yaxis.set_major_locator(MultipleLocator(0.15))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.05))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    axins.tick_params(axis='x', which='both', labelbottom=False)
    axins.set_facecolor('#2c425b')

    
    # 第三张图
    ax3.plot(x, c3, color='#99b5cd', linewidth=3)
    ax3.set_ylabel('AutoCorr',fontsize=36,labelpad=10)
    ax3.set_xlabel(r'$\tau$',fontsize=36)
  #  ax3.set_ylim(0, max(z3) * 1.1)  # 调整为趋势范围
    ax3.set_ylim(0.9981, 1.002)  # 调整为趋势范围

    ax3.xaxis.set_major_locator(MultipleLocator(50))
    ax3.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    ax3.xaxis.set_minor_locator(MultipleLocator(25))
    ax3.yaxis.set_major_locator(MultipleLocator(0.001))
    ax3.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax3.yaxis.set_minor_locator(MultipleLocator(0.0005))
    ax3.tick_params(which='both', width=2.5, labelsize=36)
    ax3.tick_params(which='major', length=10)
    ax3.tick_params(which='minor', length=5)



    
    axins = fig.add_axes([0.13, 0.285, 0.2, 0.08])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z3, color='#99b5cd', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(49, 56)
   # axins.set_xlabel('Steps',fontsize=34)    
    axins.set_title('Strong Linear Trend',fontsize=36)    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(5))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.yaxis.set_minor_locator(MultipleLocator(1))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    axins.tick_params(axis='x', which='both', labelbottom=False)
    axins.set_facecolor('#2c425b')
    



    px=np.arange(0,1,0.01)
    murange=np.arange(3.4,4,0.01)
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix30.dat')
    mixwl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix100.dat')
    mixwl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist30.dat')
    wl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist100.dat')
    wl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]

   
    pp=np.sqrt(20)

    ax4.set_ylim(0, 1)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax4.xaxis.set_major_locator(xmajorLocator)
    ax4.xaxis.set_major_formatter(xmajorFormatter)
    ax4.yaxis.set_major_locator(ymajorLocator)
    ax4.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax4.xaxis.set_minor_locator(xminorLocator)
    ax4.yaxis.set_minor_locator(yminorLocator) 
    ax4.tick_params(which='both', width=3,labelsize=34)
    ax4.tick_params(which='major', length=10)  
    ax4.tick_params(which='minor',length=5)

    
    ax4.set_xlabel('$p$', fontsize=36)
    ax4.set_ylabel('$W_{ACF}$', fontsize=36)

    
    ax4.axhline(y=0.22, color='k', linestyle='--', linewidth=2)
    ax4.axhspan(ymin=ax4.get_ylim()[0], ymax=0.22, color='lightgray', alpha=0.5)


    ax4.scatter(px,mixwl30[2]/pp, s=150, facecolors='none', edgecolors='#c0ced7',label='b=2')
    ax4.scatter(px,mixwl30[1]/pp, s=150, facecolors='none', edgecolors='#4fb9fc',label='b=1')
    ax4.scatter(px,mixwl30[0]/pp, s=150, facecolors='none', edgecolors='#2581eb',label='b=0.5')
    ax4.scatter(px,mixwl30[3]/pp, s=150, label='f=1/500',marker='+',c='#050606')
    ax4.scatter(px,mixwl30[4]/pp, s=150, label='f=1/1000',marker='+',c='#5b5d5e')

   # ax1.legend(fontsize=28)
    ax4.set_title('$MIX(p),\ N=30$',fontsize=36)

  
    
    # 第1行第2列：axs[0][1]
  

    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax5.xaxis.set_major_locator(xmajorLocator)
    ax5.xaxis.set_major_formatter(xmajorFormatter)
    ax5.yaxis.set_major_locator(ymajorLocator)
    ax5.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax5.xaxis.set_minor_locator(xminorLocator)
    ax5.yaxis.set_minor_locator(yminorLocator) 
    ax5.tick_params(which='both', width=3,labelsize=34)
    ax5.tick_params(which='major', length=10)  
    ax5.tick_params(which='minor',length=5)
    ax5.tick_params(axis='y', which='both', labelleft=False)
    
    ax5.set_xlabel('$p$', fontsize=36)
    #ax1.set_ylabel('$W_{ACF}$', fontsize=28)

   # plt.ylabel('$W_{ACF}$',fontsize=24)
    
   
    ax5.scatter(px,mixwl100[2]/pp, s=150, facecolors='none', edgecolors='#c0ced7',label='b=2')
    ax5.scatter(px,mixwl100[1]/pp, s=150, facecolors='none', edgecolors='#4fb9fc',label='b=1')
    ax5.scatter(px,mixwl100[0]/pp, s=150, facecolors='none', edgecolors='#2581eb',label='b=0.5')
    ax5.scatter(px,mixwl100[3]/pp, s=150, label='f=1/500',marker='+',c='#050606')
    ax5.scatter(px,mixwl100[4]/pp, s=150, label='f=1/1000',marker='+',c='#5b5d5e')

    
    ax5.legend(fontsize=36, loc=1, bbox_to_anchor=(0.95, 0.75))

    ax5.axhline(y=0.22, color='k', linestyle='--', linewidth=2)
    ax5.axhspan(ymin=ax5.get_ylim()[0], ymax=0.22, color='lightgray', alpha=0.5)
   # plt.legend(fontsize=24)
    ax5.set_title('$MIX(p),\ N=100$',fontsize=36)
    # plt.annotate('b', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=31,weight='bold',
    #                      xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
    #                      ha='left', va='bottom')     
        
    # 第2行第1列：axs[1][0]
    ax6.set_ylim(0,1)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax6.xaxis.set_major_locator(xmajorLocator)
    ax6.xaxis.set_major_formatter(xmajorFormatter)
    ax6.yaxis.set_major_locator(ymajorLocator)
    ax6.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax6.xaxis.set_minor_locator(xminorLocator)
    ax6.yaxis.set_minor_locator(yminorLocator) 
    ax6.tick_params(which='both', width=3,labelsize=34)
    ax6.tick_params(which='major', length=10)  
    ax6.tick_params(which='minor',length=5)

    
    ax6.set_xlabel('$\mu$', fontsize=36)
    ax6.set_ylabel('$W_{ACF}$', fontsize=36)
    

    ax6.axhline(y=0.22, color='k', linestyle='--', linewidth=2)
    ax6.axhspan(ymin=ax6.get_ylim()[0], ymax=0.22, color='lightgray', alpha=0.5)    
   
    ax6.scatter(murange,wl30[2]/pp, s=150, facecolors='none', edgecolors='#c0ced7',label='b=2')
    ax6.scatter(murange,wl30[1]/pp, s=150, facecolors='none', edgecolors='#4fb9fc',label='b=1')
    ax6.scatter(murange,wl30[0]/pp, s=150, facecolors='none', edgecolors='#2581eb',label='b=0.5')
    ax6.scatter(murange,wl30[3]/pp, s=150, label='f=1/500',marker='+',c='#050606')
    ax6.scatter(murange,wl30[4]/pp, s=150, label='f=1/1000',marker='+',c='#5b5d5e')

   # ax6.legend(fontsize=28)
    ax6.set_title('$Logistic(\mu),\ N=30$',fontsize=36)

    
    # 第2行第2列：axs[1][1]
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax7.xaxis.set_major_locator(xmajorLocator)
    ax7.xaxis.set_major_formatter(xmajorFormatter)
    ax7.yaxis.set_major_locator(ymajorLocator)
    ax7.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax7.xaxis.set_minor_locator(xminorLocator)
    ax7.yaxis.set_minor_locator(yminorLocator) 
    ax7.tick_params(which='both', width=3,labelsize=34)
    ax7.tick_params(which='major', length=10)  
    ax7.tick_params(which='minor',length=5)
    ax7.tick_params(axis='y', which='both', labelleft=False)
    ax7.set_xlabel('$\mu$', fontsize=36)
   # ax6.set_ylabel('$W_{ACF}$', fontsize=28)
    
    ax7.axhline(y=0.22, color='k', linestyle='--', linewidth=2)
    ax7.axhspan(ymin=ax7.get_ylim()[0], ymax=0.22, color='lightgray', alpha=0.5)   
    
    ax7.scatter(murange,wl100[2]/pp, s=150, facecolors='none', edgecolors='#c0ced7',label='b=2')
    ax7.scatter(murange,wl100[1]/pp, s=150, facecolors='none', edgecolors='#4fb9fc',label='b=1')
    ax7.scatter(murange,wl100[0]/pp, s=150, facecolors='none', edgecolors='#2581eb',label='b=0.5')
    ax7.scatter(murange,wl100[3]/pp, s=150, label='f=1/500',marker='+',c='#050606')
    ax7.scatter(murange,wl100[4]/pp, s=150, label='f=1/1000',marker='+',c='#5b5d5e')

    ax7.set_title('$Logistic(\mu),\ N=100$',fontsize=36)



    plt.subplots_adjust(top = 0.9, bottom = 0.15, right = 0.95, left = 0.1, 
                hspace = 0.2, wspace = 0.15)   
    
    pos4 = ax4.get_position()
    pos5 = ax5.get_position()
    pos6 = ax6.get_position()
    pos7 = ax7.get_position()

    pos1 = ax1.get_position()
    pos2 = ax2.get_position()
    pos3 = ax3.get_position()

        
    # 比如让 ax5 向上移动一些（增加它与 ax4 的间隔）
    ax5.set_position([pos5.x0, pos5.y0 + 0.03, pos5.width, 0.9*pos5.height])   
    ax4.set_position([pos4.x0+0.02, pos4.y0 + 0.03, pos4.width, 0.9*pos4.height])   
    ax6.set_position([pos6.x0+0.02, pos6.y0 - 0.0, pos6.width, 0.9*pos6.height])   
    ax7.set_position([pos7.x0, pos7.y0 - 0.0, pos7.width, 0.9*pos7.height])       


    ax1.set_position([pos1.x0, pos1.y0 , pos1.width, pos1.height])   
    ax2.set_position([pos2.x0, pos2.y0 , pos2.width, pos2.height])   
    ax3.set_position([pos3.x0, pos3.y0 , pos3.width, pos3.height])    


    ax1.annotate('a', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')     
    ax1.annotate('$W_{ACF}=0.966$ \n $AR(1)=0.037$', xy=(0.63,0.3), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')    
    ax2.annotate('b', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax2.annotate('$W_{ACF}=0.141$ \n $AR(1)=0.998$', xy=(0.63,0.32), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax3.annotate('c', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax3.annotate('$W_{ACF}=0.916$ \n $AR(1)=0.999$', xy=(0.63,0.3), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax4.annotate('d', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax5.annotate('e', xy=(-0.05,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax6.annotate('f', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax7.annotate('g', xy=(-0.05,1.05), xycoords='axes fraction', fontsize=42,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    




    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(36, 24)


    plt.savefig("/home/meng/awpsd/fig/fig1com.pdf",dpi=300,bbox_inches='tight')     





def figcombx():
    N=2000
    po=1
    tau=100
    l=1000
    z=np.random.uniform(-1,1,N)
    z1,z2=phasex(z,20)
    trendx=100*pow(np.arange(N)/N,po)
    z3=np.array(z2)+np.array(trendx)
    c1,w1=autoca(z1,tau,l)
    c2,w2=autoca(z,tau,l)
    c3,w3=autoca(z3,tau,l)
    plt.plot(c1)
    plt.plot(c2)
    plt.plot(c3)
    print(w1/np.sqrt(2*tau),w2/np.sqrt(2*tau),w3/np.sqrt(2*tau),c1[tau+1],c2[tau+1],c3[tau+1])
    
    fig = plt.figure()
    ax1 = plt.subplot2grid((6, 3), (0, 0), rowspan=2)
    ax2 = plt.subplot2grid((6, 3), (2, 0), rowspan=2,sharex=ax1)
    ax3 = plt.subplot2grid((6, 3), (4, 0), rowspan=2,sharex=ax1)
    ax4 = plt.subplot2grid((6, 3), (0, 1), rowspan=3)
    ax6 = plt.subplot2grid((6, 3), (3, 1), rowspan=3)
    

    
    x = np.linspace(-100,100,201)  # x 轴数据（0 到 10，100 个点）
    x0=np.linspace(0,2000,2000)
    

    ax1.plot(x, c2, color='#4fb9fc', linewidth=3)
    ax1.set_ylabel('AutoCorr',fontsize=36,labelpad=50)
    ax1.set_xlim(-100, 100)
    ax1.set_ylim(-0.2, 2.4)

    ax1.xaxis.set_major_locator(MultipleLocator(20))
    ax1.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    ax1.xaxis.set_minor_locator(MultipleLocator(10))
    ax1.yaxis.set_major_locator(MultipleLocator(0.5))
    ax1.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax1.yaxis.set_minor_locator(MultipleLocator(0.1))
    ax1.tick_params(which='both', width=2.5, labelsize=36)
    ax1.tick_params(which='major', length=10)
    ax1.tick_params(which='minor', length=5)
    ax1.tick_params(axis='x', which='both', labelbottom=False)

    axins = fig.add_axes([0.13, 0.795, 0.2, 0.08])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z, color='#4fb9fc', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(-1.5, 1.6)
   # axins.set_xlabel('Steps',fontsize=30)
    axins.set_title('White Noise',fontsize=36)
    axins.set_facecolor('#2c425b')
    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(1))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.5))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    axins.tick_params(axis='x', which='both', labelbottom=False)
    
    
    
    # 第二张图
    ax2.plot(x, c1, color='#2581eb', linewidth=3)
    ax2.set_ylabel('AutoCorr',fontsize=36,labelpad=50)
    ax2.set_ylim(-0.01, 2.6)  # 可选：一致范围

    ax2.yaxis.set_major_locator(MultipleLocator(0.5))
    ax2.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax2.yaxis.set_minor_locator(MultipleLocator(0.1))
    ax2.tick_params(which='both', width=2.5, labelsize=36)
    ax2.tick_params(which='major', length=10)
    ax2.tick_params(which='minor', length=5)
    ax2.tick_params(axis='x', which='both', labelbottom=False)
   

    axins = fig.add_axes([0.13, 0.535, 0.2, 0.08])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z1, color='#2581eb', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(500, 1100)
    axins.set_ylim(-0.25, 0.3)
    #axins.set_xlabel('Steps',fontsize=34)    
    axins.set_title('Low Pass Filter',fontsize=36)    
    axins.xaxis.set_major_locator(MultipleLocator(500))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(250))
    axins.yaxis.set_major_locator(MultipleLocator(0.15))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    axins.yaxis.set_minor_locator(MultipleLocator(0.05))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    axins.tick_params(axis='x', which='both', labelbottom=False)
    axins.set_facecolor('#2c425b')

    
    # 第三张图
    ax3.plot(x, c3, color='#99b5cd', linewidth=3)
    ax3.set_ylabel('AutoCorr',fontsize=36,labelpad=10)
    ax3.set_xlabel(r'$\tau$',fontsize=42)
  #  ax3.set_ylim(0, max(z3) * 1.1)  # 调整为趋势范围
    ax3.set_ylim(0.9981, 1.003)  # 调整为趋势范围

    ax3.xaxis.set_major_locator(MultipleLocator(50))
    ax3.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    ax3.xaxis.set_minor_locator(MultipleLocator(25))
    ax3.yaxis.set_major_locator(MultipleLocator(0.002))
    ax3.yaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax3.yaxis.set_minor_locator(MultipleLocator(0.001))
    ax3.tick_params(which='both', width=2.5, labelsize=36)
    ax3.tick_params(which='major', length=10)
    ax3.tick_params(which='minor', length=5)



    
    axins = fig.add_axes([0.13, 0.27, 0.2, 0.08])  # [left, bottom, width, height]，单位是 figure 范围 [0,1]


    axins.plot(x0, z3, color='#99b5cd', linewidth=2)  # 修复：添加绘图线
    axins.set_xlim(1000, 1100)
    axins.set_ylim(49, 56)
   # axins.set_xlabel('Steps',fontsize=34)    
    axins.set_title('Strong Linear Trend',fontsize=36)    
    axins.xaxis.set_major_locator(MultipleLocator(50))
    axins.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.xaxis.set_minor_locator(MultipleLocator(10))
    axins.yaxis.set_major_locator(MultipleLocator(5))
    axins.yaxis.set_major_formatter(FormatStrFormatter('%d'))
    axins.yaxis.set_minor_locator(MultipleLocator(1))
    axins.tick_params(which='both', width=1.8, labelsize=30)
    axins.tick_params(which='major', length=10)  
    axins.tick_params(which='minor', length=5)  
    axins.tick_params(axis='x', which='both', labelbottom=False)
    axins.set_facecolor('#2c425b')
    



    px=np.arange(0,1,0.01)
    murange=np.arange(3.4,4,0.01)
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix30.dat')
    mixwl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix100.dat')
    mixwl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist30.dat')
    wl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist100.dat')
    wl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]

   
    pp=np.sqrt(20)

    ax4.set_ylim(0, 1)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax4.xaxis.set_major_locator(xmajorLocator)
    ax4.xaxis.set_major_formatter(xmajorFormatter)
    ax4.yaxis.set_major_locator(ymajorLocator)
    ax4.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax4.xaxis.set_minor_locator(xminorLocator)
    ax4.yaxis.set_minor_locator(yminorLocator) 
    ax4.tick_params(which='both', width=3,labelsize=34)
    ax4.tick_params(which='major', length=10)  
    ax4.tick_params(which='minor',length=5)

    
    ax4.set_xlabel('$p$', fontsize=42)
    ax4.set_ylabel('$W_{ACF}$', fontsize=36)

    
    ax4.axhline(y=0.22, color='k', linestyle='--', linewidth=2)
    ax4.axhspan(ymin=ax4.get_ylim()[0], ymax=0.22, color='lightgray', alpha=0.5)


    ax4.scatter(px,mixwl30[2]/pp, s=150, facecolors='none', edgecolors='#c0ced7',label='b=2')
    ax4.scatter(px,mixwl30[1]/pp, s=150, facecolors='none', edgecolors='#4fb9fc',label='b=1')
    ax4.scatter(px,mixwl30[0]/pp, s=150, facecolors='none', edgecolors='#2581eb',label='b=0.5')
    ax4.scatter(px,mixwl30[3]/pp, s=150, label='f=1/500',marker='+',c='#050606')
    ax4.scatter(px,mixwl30[4]/pp, s=150, label='f=1/1000',marker='+',c='#5b5d5e')

   # ax1.legend(fontsize=28)
    ax4.set_title('$MIX(p),\ N=50$',fontsize=38)

  
    

    


    ax6.set_ylim(0,1)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax6.xaxis.set_major_locator(xmajorLocator)
    ax6.xaxis.set_major_formatter(xmajorFormatter)
    ax6.yaxis.set_major_locator(ymajorLocator)
    ax6.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax6.xaxis.set_minor_locator(xminorLocator)
    ax6.yaxis.set_minor_locator(yminorLocator) 
    ax6.tick_params(which='both', width=3,labelsize=34)
    ax6.tick_params(which='major', length=10)  
    ax6.tick_params(which='minor',length=5)

    
    ax6.set_xlabel('$\mu$', fontsize=42)
    ax6.set_ylabel('$W_{ACF}$', fontsize=36)
    

    ax6.axhline(y=0.22, color='k', linestyle='--', linewidth=2)
    ax6.axhspan(ymin=ax6.get_ylim()[0], ymax=0.22, color='lightgray', alpha=0.5)    
   
    ax6.scatter(murange,wl30[2]/pp, s=150, facecolors='none', edgecolors='#c0ced7',label='b=2')
    ax6.scatter(murange,wl30[1]/pp, s=150, facecolors='none', edgecolors='#4fb9fc',label='b=1')
    ax6.scatter(murange,wl30[0]/pp, s=150, facecolors='none', edgecolors='#2581eb',label='b=0.5')
    ax6.scatter(murange,wl30[3]/pp, s=150, label='f=1/500',marker='+',c='#050606')
    ax6.scatter(murange,wl30[4]/pp, s=150, label='f=1/1000',marker='+',c='#5b5d5e')

   # ax6.legend(fontsize=28)
    ax6.set_title('$Logistic(\mu),\ N=50$',fontsize=38)
    ax6.legend(fontsize=34, loc=1, bbox_to_anchor=(0.5, 1.0),frameon=False)

    
    # 第2行第2列：axs[1][1]



    plt.subplots_adjust(top = 0.9, bottom = 0.15, right = 0.95, left = 0.1, 
                hspace = 0.35, wspace = 0.2)   
    
    pos4 = ax4.get_position()
    pos6 = ax6.get_position()

    pos1 = ax1.get_position()
    pos2 = ax2.get_position()
    pos3 = ax3.get_position()

        
    # 比如让 ax5 向上移动一些（增加它与 ax4 的间隔）
    ax4.set_position([pos4.x0+0.02, pos4.y0 + 0.03, pos4.width, 0.9*pos4.height])   
    ax6.set_position([pos6.x0+0.02, pos6.y0 - 0.0, pos6.width, 0.9*pos6.height])   


    ax1.set_position([pos1.x0, pos1.y0 , pos1.width, pos1.height])   
    ax2.set_position([pos2.x0, pos2.y0 , pos2.width, pos2.height])   
    ax3.set_position([pos3.x0, pos3.y0 , pos3.width, pos3.height])    


    ax1.annotate('a', xy=(-0.25,1.05), xycoords='axes fraction', fontsize=46,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')     
    ax1.annotate('$W_{ACF}=0.969$', xy=(0.58,0.25), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')    
    ax1.annotate('$AR(1)=0.032$', xy=(0.01,0.25), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')    
    ax2.annotate('b', xy=(-0.25,1.05), xycoords='axes fraction', fontsize=46,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax2.annotate('$W_{ACF}=0.127$', xy=(0.585,0.38), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    
    ax2.annotate('$AR(1)=0.999$', xy=(0.01,0.38), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax3.annotate('c', xy=(-0.25,1.05), xycoords='axes fraction', fontsize=46,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax3.annotate('$W_{ACF}=0.924$', xy=(0.58,0.25), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax3.annotate('$AR(1)=0.999$', xy=(0.01,0.25), xycoords='axes fraction', fontsize=34,
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
    ax4.annotate('d', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=46,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 
  
    ax6.annotate('e', xy=(-0.2,1.05), xycoords='axes fraction', fontsize=46,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom') 

    




    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(32, 23)


    plt.savefig("/home/meng/awpsd/fig/fig1comx.pdf",dpi=300,bbox_inches='tight')     




def mixx(p,N):
    a=0
    for i in range(12):
        a+=pow(np.sin(2*np.pi*i/12),2)/12
        
    x=a*np.sin(2*np.pi*np.arange(N)/12)
        
    b=np.sqrt(3)
    y=np.random.uniform(-b,b,N)

    ratio=int(N*p)
                
    z1=np.zeros(N-ratio)
    z2=np.ones(ratio)
    z=list(z1)+list(z2)
    np.random.shuffle(z)
    z=np.array(z)
    y=np.array(y)
    x=np.array(x)
                    
    mix=(1-z)*x+z*y    
    return mix







def plot_fig1():
    murange=np.arange(3.4,4,0.01)
    m=len(murange)
    sn=100
    tau=10
    l=30
    N=1500
    fs=18
    wl30=[]
    for b in [0.5,1,2]:
    
        wx0=[]
      #  psdx0=[]
       # sampx0=[]
        for mu in murange:
    
    
            wx=[]
           # sampx=[]
            #
            for times in range(sn):
                x0=np.random.choice(1000)/1000        
                logistx=chaost(500,500+N,x0,mu)           
                trendx=1000*pow(np.arange(N)/N,b)
                newx=logistx+trendx
                w=autowa(newx[500:],tau,l)
                if(w>0):
                    wx.append(w)
                
            wx0.append(np.mean(wx))
        plt.plot(wx0)
        wl30.append(wx0)
                 








def mix_test():

    
    mixwl30=[]
    for rx in [0.1,1,100,1000]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.01)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=30
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,1)*1000
                    trendx=np.array(mix)*rx+trend[:len(mix)]
                    w=autowc(trendx[500:],tau,l)
                    wb=autowb(trendx[500:],tau,l)
                 #   h=hurst_rs(trendx[500:500+l])[0]
                    wx.append(w)
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:],fs=len(trendx[500:])/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
        plt.plot(wx0)
        
                #sampx0.append(np.mean(sampx))
        mixwl30.append(wx0)
 
        
    for fx in [500,1000]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.01)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=30
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    xr=np.arange(N)
                    trend=np.sin(2*np.pi*xr/fx)*1
                    trendx=mix+trend
                    w=autowa(trendx,tau,l)                 
                    wx.append(w)
                    wb=autowb(trendx,tau,l)                 
                    wxb.append(wb)

                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
        plt.plot(wxb0)

        mixwl30.append(wx0) 
    
    mixwl100=[]
    for rx in [0.5,1,2]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.01)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=100
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,rx)*1000
                    trendx=mix+trend[:len(mix)]
                    w=autowa(trendx[500:],tau,l)
                 
                    wx.append(w)
                  
                wx0.append(np.mean(wx))
        plt.plot(wx0)
                #sampx0.append(np.mean(sampx))
        mixwl100.append(wx0)
 
        
    for fx in [500,1000]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.01)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=100
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    xr=np.arange(N)
                    trend=np.sin(2*np.pi*xr/fx)*1
                    trendx=mix+trend
                    w=autowa(trendx,tau,l)                 
                    wx.append(w)

                wx0.append(np.mean(wx))
        plt.plot(wx0)

        mixwl100.append(wx0) 


def logistx_test():
    murange=np.arange(3.4,4,0.01)
    m=len(murange)
    sn=100
    tau=10
    l=30
    N=1500
    fs=18
    wl30=[]
    for b in [0.5,1,2]:
    
        wx0=[]
      #  psdx0=[]
       # sampx0=[]
        for mu in murange:
    
    
            wx=[]
           # sampx=[]
            #
            for times in range(sn):
                x0=np.random.choice(1000)/1000        
                logistx=chaost(500,500+N,x0,mu)           
                trendx=1000*pow(np.arange(N)/N,b)
                newx=logistx+trendx
                w=autowa(newx[500:],tau,l)
                if(w>0):
                    wx.append(w)
                
            wx0.append(np.mean(wx))
        plt.plot(wx0)
        wl30.append(wx0)


    
    for fx in [500,1000]:
        wx0=[]
      #  psdx0=[]
       # sampx0=[]
        for mu in murange:
    
    
            wx=[]
           # sampx=[]
            #
            for times in range(sn):
                x0=np.random.choice(1000)/1000        
                logistx=chaost(500,500+N,x0,mu)           
                xr=np.arange(N)
                trendx=np.sin(2*np.pi*xr/fx)*10
                newx=logistx+trendx
                w=autowa(newx,tau,l)
                if(w>0):
                    wx.append(w)
               
            wx0.append(np.mean(wx))    
        plt.plot(wx0)
        plt.plot(wl30[0])
        wl30.append(wx0)
        
############################################################l=1000        
    murange=np.arange(3.4,4,0.01)
    m=len(murange)
    sn=100
    tau=10
    l=100
    N=1500
    fs=18
    wl100=[]
    for b in [0.5,1,2]:
    
        wx0=[]
      #  psdx0=[]
       # sampx0=[]
        for mu in murange:
    
    
            wx=[]
           # sampx=[]
            #
            for times in range(sn):
                x0=np.random.choice(1000)/1000        
                logistx=chaost(500,500+N,x0,mu)           
                trendx=1000*pow(np.arange(N)/N,b)
                newx=logistx+trendx
                w=autowa(newx[500:],tau,l)
                if(w>0):
                    wx.append(w)
                
            wx0.append(np.mean(wx))
        plt.plot(wx0)
        wl100.append(wx0)


    
    for fx in [500,1000]:
        wx0=[]
      #  psdx0=[]
       # sampx0=[]
        for mu in murange:
    
    
            wx=[]
           # sampx=[]
            #
            for times in range(sn):
                x0=np.random.choice(1000)/1000        
                logistx=chaost(500,500+N,x0,mu)           
                xr=np.arange(N)
                trendx=np.sin(2*np.pi*xr/fx)*10
                newx=logistx+trendx
                w=autowa(newx,tau,l)
                if(w>0):
                    wx.append(w)
               
            wx0.append(np.mean(wx))    
        plt.plot(wx0)
        plt.plot(wl1000[0])
        wl100.append(wx0)

def plots():
# =============================================================================
#     outfile=open('/home/meng/bak_bupt/newproj/data/WACF_mix30.dat','w')
#     for i in range(len(px)):
#         outfile.write('%.2f %.6f %.6f %.6f %.6f %.6f \n'%(px[i],mixwl30[0][i],mixwl30[1][i],mixwl30[2][i],mixwl30[3][i],mixwl30[4][i]))
#         outfile.flush()
#     outfile.close()
# 
#     outfile=open('/home/meng/bak_bupt/newproj/data/WACF_mix100.dat','w')
#     for i in range(len(px)):
#         outfile.write('%.2f %.6f %.6f %.6f %.6f %.6f \n'%(px[i],mixwl1000[0][i],mixwl1000[1][i],mixwl1000[2][i],mixwl1000[3][i],mixwl1000[4][i]))
#         outfile.flush()
#     outfile.close()
# 
# 
#     outfile=open('/home/meng/bak_bupt/newproj/data/WACF_logist30.dat','w')
#     for i in range(len(murange)):
#         outfile.write('%.2f %.6f %.6f %.6f %.6f %.6f \n'%(murange[i],wl30[0][i],wl30[1][i],wl30[2][i],wl30[3][i],wl30[4][i]))
#         outfile.flush()
#     outfile.close()
#     
#     outfile=open('/home/meng/bak_bupt/newproj/data/WACF_logist100.dat','w')
#     for i in range(len(murange)):
#         outfile.write('%.2f %.6f %.6f %.6f %.6f %.6f \n'%(murange[i],wl1000[0][i],wl1000[1][i],wl1000[2][i],wl1000[3][i],wl1000[4][i]))
#         outfile.flush()
#     outfile.close()   
# =============================================================================
    
    px=np.arange(0,1,0.01)
    murange=np.arange(3.4,4,0.01)
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix30.dat')
    mixwl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_mix100.dat')
    mixwl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist30.dat')
    wl30=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]   
    
    data=np.loadtxt('/home/meng/bak_bupt/newproj/data/WACF_logist100.dat')
    wl100=[data[:,1],data[:,2],data[:,3],data[:,4],data[:,5]]

    ax=plt.subplot(221)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   
    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    plt.xlabel('$p$',fontsize=28)
    plt.ylabel('$W_{ACF}$',fontsize=28)
    

    
   
    # plt.scatter(px,mixwl30[0], s=150, facecolors='none', edgecolors='#1e341f',label='b=0.5')
    # plt.scatter(px,mixwl30[1], s=150, facecolors='none', edgecolors='#850d29',label='b=0.5')
    # plt.scatter(px,mixwl30[2], s=150, facecolors='none', edgecolors='#bb2649',label='b=0.5')
    # plt.scatter(px,mixwl30[3], s=150, label='f=10',marker='+',c='#17293a')
    # plt.scatter(px,mixwl30[4], s=150, label='f=100',marker='+',c='#304b5f')

    plt.scatter(px,mixwl30[2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.scatter(px,mixwl30[1], s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    plt.scatter(px,mixwl30[0], s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    plt.scatter(px,mixwl30[3], s=150, label='f=1/500',marker='+',c='#118ab2')
    plt.scatter(px,mixwl30[4], s=150, label='f=1/1000',marker='+',c='#073b4c')
    plt.legend(fontsize=24,loc=1,bbox_to_anchor=(0.95,0.5))

   # plt.legend(fontsize=28)
    plt.title('$MIX(p),\ N=30$',fontsize=28)
    plt.annotate('a', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=28,weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')     
    
    ax=plt.subplot(222)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   
    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    plt.xlabel('$p$',fontsize=24)
    plt.ylabel('$W_{ACF}$',fontsize=24)
    
   
    plt.scatter(px,mixwl100[2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.scatter(px,mixwl100[1], s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    plt.scatter(px,mixwl100[0], s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    plt.scatter(px,mixwl100[3], s=150, label='f=1/500',marker='+',c='#118ab2')
    plt.scatter(px,mixwl100[4], s=150, label='f=1/1000',marker='+',c='#073b4c')
   

   # plt.legend(fontsize=24)
    plt.title('$MIX(p),\ N=100$',fontsize=28)
    plt.annotate('b', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=31,weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')     
        
    ax=plt.subplot(223)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   
    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    plt.xlabel('$\mu$',fontsize=28)
    plt.ylabel('$W_{ACF}$',fontsize=28)
    
   
    plt.scatter(murange,wl30[2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.scatter(murange,wl30[1], s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    plt.scatter(murange,wl30[0], s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    plt.scatter(murange,wl30[3], s=150, label='f=1/500',marker='+',c='#118ab2')
    plt.scatter(murange,wl30[4], s=150, label='f=1/1000',marker='+',c='#073b4c')

   # plt.legend(fontsize=28)
    plt.title('$Logistic(\mu),\ N=30$',fontsize=28)
    plt.annotate('c', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=28,weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')     
    
    ax=plt.subplot(224)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   

    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    plt.xlabel('$\mu$',fontsize=28)
    plt.ylabel('$W_{ACF}$',fontsize=28)
    
   
    plt.scatter(murange,wl100[2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.scatter(murange,wl100[1], s=150, facecolors='none', edgecolors='#ffd166',label='b=1')
    plt.scatter(murange,wl100[0], s=150, facecolors='none', edgecolors='#06d6a0',label='b=0.5')
    plt.scatter(murange,wl100[3], s=150, label='f=1/500',marker='+',c='#118ab2')
    plt.scatter(murange,wl100[4], s=150, label='f=1/1000',marker='+',c='#073b4c')

    plt.title('$Logistic(\mu),\ N=100$',fontsize=28)
    plt.annotate('d', xy=(-0.1,1.05), xycoords='axes fraction', fontsize=28,weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')    
        

    plt.subplots_adjust(top = 0.9, bottom = 0.15, right = 0.95, left = 0.1, 
                hspace = 0.3, wspace = 0.2)   
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(24, 18)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/bak_bupt/newproj/fig/WACF.pdf",dpi=300,bbox_inches='tight') 

#ef476f // #ffd166 // #06d6a0 // #118ab2 // #073b4c
 
############################################################################################################################

def plot_ice_autowa():
    path='/home/meng/bak_bupt/newproj/data'
    data=np.loadtxt(path+'/autow_northpole.dat')
    ax=plt.subplot(411)
    xmajorLocator = MultipleLocator(5) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   

    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
   # plt.xlabel('$Year$',fontsize=28)
    #plt.ylabel('$W_{ACF}$',fontsize=28)
    
    murange=np.arange(120)/12+1980
    wl1000=data
   # plt.scatter(murange,wl1000[:,2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.plot(murange,wl1000[:,2][:120],color='k',label='original')
    plt.plot(murange,wl1000[:,4][:120],color='royalblue',label='linear')
    plt.plot(murange,wl1000[:,6][:120],color='tomato',label='oscillatory')


    plt.legend(fontsize=28,loc=1,bbox_to_anchor=(1.2,1.2))
    #plt.title('$Logistic(\mu),\ N=1000$',fontsize=28)
    plt.annotate('$W_{ACF}$', xy=(-0.1,-1.35), xycoords='axes fraction', fontsize=28,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')    

        
    ax=plt.subplot(412)
    xmajorLocator = MultipleLocator(5) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   

    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    # plt.xlabel('$Year$',fontsize=28)
    # plt.ylabel('$W_{ACF}$',fontsize=28)
    
    murange=np.arange(120)/12+1990
    wl1000=data
   # plt.scatter(murange,wl1000[:,2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.plot(murange,wl1000[:,2][120:240],color='k',label='original')
    plt.plot(murange,wl1000[:,4][120:240],color='royalblue',label='linear trend')
    plt.plot(murange,wl1000[:,6][120:240],color='tomato',label='oscillatory trend')
    
    
    ax=plt.subplot(413)
    xmajorLocator = MultipleLocator(5) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   

    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
    # plt.xlabel('$Year$',fontsize=28)
    # plt.ylabel('$W_{ACF}$',fontsize=28)
    
    murange=np.arange(120)/12+2000
    wl1000=data
   # plt.scatter(murange,wl1000[:,2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.plot(murange,wl1000[:,2][240:360],color='k',label='original')
    plt.plot(murange,wl1000[:,4][240:360],color='royalblue',label='linear trend')
    plt.plot(murange,wl1000[:,6][240:360],color='tomato',label='oscillatory trend')    
    

    ax=plt.subplot(414)
    xmajorLocator = MultipleLocator(5) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.5) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.25) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=4)
    ax.tick_params(which='major', length=9)  
    ax.tick_params(which='minor',length=5)
    #plt.plot(taux,dpn,'k--',label='globe')
   

    plt.xticks(fontsize=24)
    plt.yticks(fontsize=24)
   # plt.xlabel('$Year$',fontsize=28)
    #plt.ylabel('$W_{ACF}$',fontsize=28)
    
    murange=np.arange(119)/12+2010
    wl1000=data
   # plt.scatter(murange,wl1000[:,2], s=150, facecolors='none', edgecolors='#ef476f',label='b=2')
    plt.plot(murange,wl1000[:,2][360:],color='k',label='original')
    plt.plot(murange,wl1000[:,4][360:],color='royalblue',label='linear trend')
    plt.plot(murange,wl1000[:,6][360:],color='tomato',label='oscillatory trend')    
    
    plt.annotate('$Year$', xy=(0.5,-0.2), xycoords='axes fraction', fontsize=28,weight='bold',
                          xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                          ha='left', va='bottom')  
    # plt.subplots_adjust(top = 0.95, bottom = 0.2, right = 0.95, left = 0.1, 
    #             hspace = 0.2, wspace = 0.3)   
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(24, 28)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/bak_bupt/newproj/fig/WACF_ice_northpole.pdf",dpi=300,bbox_inches='tight') 

def mix_test():
    N=2000
    a=0
    for i in range(12):
        a+=pow(np.sin(2*np.pi*i/12),2)/12
    
    x=a*np.sin(2*np.pi*np.arange(N)/12)
    
    b=np.sqrt(3)
    y=np.random.uniform(-b,b,N)
    wx=[]
    px=np.arange(0,1,0.01)
    m=len(px)
    
    sn=10
    fs=18
    tau=10
    l=30
    
    wx0=[]
    sampx0=[]
    psdx0=[]
    for p in px:
            ratio=int(N*p)
            
            z1=np.zeros(N-ratio)
            z2=np.ones(ratio)
            z=list(z1)+list(z2)
            wx=[]
            sampx=[]
            psdx=[]
            for st in range(sn):        
                np.random.shuffle(z)
                z=np.array(z)
                y=np.array(y)
                x=np.array(x)
                
                mix=(1-z)*x+z*y
                
                xr=np.arange(N)/N
                trend=np.sin(2*np.pi*xr*10)*10
                trendx=mix+trend
                w=autowa(trendx,tau,l)
                s=nolds.sampen(trendx[:l])    
                p1,p2=pdswelch(trendx[:l],fs)
                psd=sum(p1*p2)
                wx.append(w)
                sampx.append(s)
                psdx.append(psd)
            wx0.append(np.mean(wx))
            sampx0.append(np.mean(sampx))
            psdx0.append(np.mean(psdx))



def logistx_test():
    murange=np.arange(3.4,4,0.01)
    m=len(murange)
    sn=100
    tau=10
    l=30
    N=1500
    fs=18
    wx0=[]
    psdx0=[]
    sampx0=[]
    for mu in murange:


        wx=[]
        sampx=[]
        psdx=[]
        
        for times in range(sn):
            x0=np.random.choice(1000)/1000        
            logistx=chaost(500,500+N,x0,mu) 
            xr=np.arange(N)/N
            trendx=np.sin(2*np.pi*xr*10)*1
            newx=logistx+trendx
            w=autowa(newx,tau,l)
            wx.append(w)
            s=nolds.sampen(newx[:l])
            sampx.append(s)
            p1,p2=pdswelch(newx[:l],fs)
            psd=sum(p1*p2)
            psdx.append(psd)
            # la=nolds.lyap_r(newx[:l])
            # lyapx.append(la)
        wx0.append(np.mean(wx))
        sampx0.append(np.mean(sampx))
        psdx0.append(np.mean(psdx))











###########################################################################################



xaxis=np.arange(3,4,0.1)
xaxis=[3.5,3.7,3.8]
mux=[]
for i in xaxis:
    mu=i
    n1=500
    n2=3000
    x0=0.1
    logistx=chaost(n1,n2,x0,mu)
    wx=[]
    dfax=[]
    sampx=[]
    axx=np.arange(10,1000,10)
    for a in axx:
        tau=5
        l=a
        w=autowa(logistx,tau,l)
        wx.append(w)
        #dfax.append(nolds.dfa(newx[:l]))
        #sampx.append(nolds.sampen(newx[:l]))
       # mux.append(mu)
    plt.plot(axx,wx,'o--')
    
    
    #plt.plot(np.log(axx[:]),np.log(wx[:]))












n1=0
n2=50
x=0.05
mu=3.1
logistx=chaost(n1,n2,x,mu)
#plt.plot(logistx,'o--')
y=np.fft.fft(logistx)
plt.plot(y)




dfax=[]
lyapx=[]
sampx=[]
wx=[]



tau=10
l=30
xaxis=np.arange(3,4,0.1)
xaxis=[3.5,3.7,3.8]
mux=[]
for i in xaxis:
    mu=i
    n1=500
    n2=2000
    x0=0.1
    logistx=chaost(n1,n2,x0,mu)
    wx=[]
    dfax=[]
    sampx=[]
    axx=np.arange(0,50,0.1)
    for a in axx:
        b=1
        trendx=linearx(a,b,n2-n1)
        newx=logistx+trendx
        w=autowa(newx,tau,l)
        wx.append(w)
        #dfax.append(nolds.dfa(newx[:l]))
        #sampx.append(nolds.sampen(newx[:l]))
       # mux.append(mu)
   # plt.plot(axx,wx)
    plt.plot(np.log(axx[:]),np.log(wx[:]))
    
wx=[]    
newx0=[]
for i in range(n2-n1):
    newx0.append(np.random.choice(n2-n1)/(n2-n1))
for a in axx:
    b=1
    trendx=linearx(a,b,n2-n1)
    newx=newx0+trendx
    w=autowa(newx,tau,l)
    wx.append(w)
#plt.plot(axx,wx)
plt.plot(np.log(axx),np.log(wx))





tau=10
l=1000
xaxis=np.arange(3,4,0.1)
xaxis=[3.5,3.7,3.8]
mux=[]
for i in xaxis:
    mu=i
    n1=500
    n2=2000
    x0=0.1
    logistx=chaost(n1,n2,x0,mu)
    wx=[]
    dfax=[]
    sampx=[]
    axx=np.arange(0,1000,1)
    for a in axx:
        b=5
        trendx=sinx(a,b,n2-n1)
        newx=logistx+trendx
        w=autowa(newx,tau,l)
        wx.append(w)
       # dfax.append(nolds.dfa(newx[:l],order=2))
        sampx.append(nolds.sampen(newx[:l]))
       # mux.append(mu)
   # plt.plot(axx,wx)
    plt.plot(np.log(axx[:]),np.log(sampx[:]))
    
wx=[]   
sampx=[] 
newx0=[]
for i in range(n2-n1):
    newx0.append(np.random.choice(n2-n1)/(n2-n1))
for a in axx:
    b=5
    trendx=sinx(a,b,n2-n1)
    newx=newx0+trendx
    w=autowa(newx,tau,l)
    wx.append(w)
    sampx.append(nolds.sampen(newx[:l]))

#plt.plot(axx,wx)
plt.plot(np.log(axx),np.log(wx))


def model_test():
    mixwl30=[]
    for rx in [1,2,3]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        yy=np.random.uniform(-b,b,N)
        np.random.shuffle(yy)
        wx=[]
        px=np.arange(0,1,0.01)
        m=len(px)
        
        sn=10
        fs=18
        tau=10
        l=30
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,1)*1000
                    trendx=np.array(mix)+yy*rx+trend[:len(mix)]
                    w=autowc(trendx[500:],tau,l)
                    wb=autowb(trendx[500:],tau,l)
                 #   h=hurst_rs(trendx[500:500+l])[0]
                    wx.append(w)
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:],fs=len(trendx[500:])/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
        plt.plot(psdx0)
        
                #sampx0.append(np.mean(sampx))
        mixwl30.append(wx0)
 
        
    for fx in [500,1000]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.01)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=30
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    xr=np.arange(N)
                    trend=np.sin(2*np.pi*xr/fx)*1
                    trendx=mix+trend
                    w=autowa(trendx,tau,l)                 
                    wx.append(w)
                    wb=autowb(trendx,tau,l)                 
                    wxb.append(wb)

                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
        plt.plot(wxb0)








                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  