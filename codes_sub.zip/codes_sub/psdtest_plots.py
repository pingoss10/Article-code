#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 10 20:19:15 2024

@author: meng
"""
import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,0):
        x1=x[tau:l+tau]
        x2=x[tau-t:l-t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    for t in range(0,tau):
        x1=x[tau-t:l+tau-t]
        x2=x[tau:l+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    w=(1-np.mean(z))/np.std(z)
    return z
def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def awps(x,s1,l):
    n=round(l/2)
    lx=np.arange(n)
    t0=np.abs(np.fft.fft(x[s1:s1+l]))
    ta=sum(lx*t0[:n])/sum(t0[1:n])
    return ta/n
    


def sinx():
    psx=[]
    for i in range(3,100):
        f=int(i)
        j=np.arange(10000)
        x=np.sin(2*np.pi*j/f)
        psx.append(apsdx(x,0,1000))

        y=np.abs(np.fft.fft(x))
        
        n=np.arange(500)
        z=sum(n*y[:500])/sum(y[1:500])
        psx.append(z)

 
def icepsd():
    path='/home/meng/bak_bupt/newproj/data'
    tmpI=np.loadtxt(path+'/era5ice2.5d_ano_1979to2019_nonzero.ano')   
    tmp=np.loadtxt('/home/meng/bak_bupt/newproj/data/era5t85075d_ano_1979to2019_g.ano')
    nino=np.loadtxt('/home/meng/bak_bupt/newproj/data/enso_nino34.dat')
    
    nt=np.reshape(nino,(105,14965))

    monthds=[0,31,59,90,120,151,181,212,243,273,304,334,365]
    months=[31,28,31,30,31,30,31,31,30,31,30,31]
    N=14965
    a=10000
    T=np.reshape(tmpI,(377,N))
    regrid=np.loadtxt(path+'/nonzeroicenodes.dat')
    
    
    nodes=[]
    z=[]
    for k in range(377):
        x=[apsdx(T[k],i*365,365*5) for i in range(41)]
        y=np.arange(41)
        r,p=pearsonr(x,y)
        if(p<0.05 and r>0):
            nodes.append(k)
            z.append(x)
            plt.plot(x)
        


    nodes=[]
    z=[]
    for k in range(105):
        x=[apsdx(T[k],i*365,365) for i in range(41)]
        z.append(x)
        y=np.arange(41)
        r,p=pearsonr(x,y)
        if(p<0.05 and r>0):
            nodes.append(k)
            z.append(x)
            plt.plot(x)
            
        
        
       
    
    

# x=np.loadtxt('/home/meng/bak_bupt/newproj/data/test_event/node.txt')
# x1=np.reshape(x[364:],(42,365))
# x2=[np.std(x1[:,d]) for d in range(365)]
# #x3=[x1[y,i]/x2[i] for y in range(42) for i in range(365)]
# x3=[x1[0,i]/x2[i] for i in range(365)]
# np.random.shuffle(x3)
# x4=[x3[i]*x2[i] for i in range(365)]



x=np.loadtxt('/home/meng/bak_bupt/newproj/data/test_event/tas-node.txt')


x1=np.reshape(x[364:],(42,365))
x2=[np.std(x1[:,d]) for d in range(365)]
x3=[x1[y,i]/x2[i] for y in range(42) for i in range(365)]




def temp():    
    path='/home/meng/bak_bupt/newproj/data/'
    tmp=np.loadtxt(path+'era5t85075d_ano_1979to2019_g_new_726.ano')
    
    
    monthds=[0,31,59,90,120,151,181,212,243,273,304,334,365]
    months=[31,28,31,30,31,30,31,31,30,31,30,31]
    T=np.reshape(tmp,(726,15695))    
    
    psx=[]
    apsx=[]
    for i in range(1,20):
        fx=np.fft.fft(T[10][:1000])
        fx[1:500-i*20]=0
        fx[500+i*20:1000]=0
        ty=np.real(np.fft.ifft(fx))
        psx.append(awps(ty,0,100))
        apsx.append(apsdx(ty,0,100))
        xp,yp=pdswelch(ty,fs=100)
        plt.plot(xp,yp)    
    
    y=[]
    z=[]
    w=[]
    for i in range(20):
        s1=i*10000
        y.append(awps(x,s1,10000))
        xx=np.abs(np.fft.fft(x[s1:s1+10000]))
        f=10*(i+1)
        z.append(f*max(xx))
        z1=np.arange(5000)
        w.append(sum(z1*xx[:5000]/sum(xx[1:5000])))
        
        
        
            
    f=np.cos(2*pi*t/100)
    x=np.sin(2*pi*t/f)
    




def fftxx():
    path='/home/meng/bak_bupt/newproj/data/'

    tmp=np.loadtxt('/home/meng/bak_bupt/newproj/data/enso/NINO34_ERA5_1959to2021_ano.dat')   


    monthds=[0,31,59,90,120,151,181,212,243,273,304,334,365]
    months=[31,28,31,30,31,30,31,31,30,31,30,31]
    T=np.reshape(tmp,(105,22995))
    
    ser=T[0][:3000]
    l=len(ser)
    tau=5

    cxb=[]
    cx=[]
    ccx=[]
    for ii in range(1,100,5):    
        psdx=[]
        wx=[]
        wxb=[]
        sampx=[]
        
        wxt=[]
        wxbt=[]
        for times in range(100):
            #np.random.shuffle(ser)
            fx=np.fft.fft(ser)
            phx=np.angle(fx)
            np.random.shuffle(phx)
            fy = np.abs(fx)*np.exp(1j*phx)
            y = np.fft.ifft(fy)
            serx=np.real(y)
            xp,yp=pdswelch(ser,fs=l/2)
            zp=sum(xp*yp)
            w=autowa(serx,5,l-2*tau)
            wb=autowb(serx,5,l-2*tau)
            wx.append(w)
            wxb.append(wb)
            s=nolds.sampen(serx)  
            sampx.append(s)
            psdx.append(zp)    
            
            w=autowa(serx,tau*ii,l-2*tau*ii)
            wb=autowb(serx,tau*ii,l-2*tau*ii)
            wxt.append(w)
            wxbt.append(wb)
        cx.append(pearsonr(wx,wxt)[0])
        ccx.append(pearsonr(wx,wxb))
        cxb.append(pearsonr(wxb,wxbt)[0])
    
    
    ser=T[0][:200]
    l=len(ser)
    
    
    wx=[]
    wxb=[]
    sampx=[]
    stdx=[]
    meanx=[]
    for tau in range(2,20):
        xx=autoca(ser,tau,l-2*tau)
        stdx.append(np.std(xx))
        meanx.append(np.mean(xx))
        w=autowa(ser,tau,l-2*tau)
        wb=autowb(ser,tau,l-2*tau)
        wx.append(w)
        wxb.append(wb)
        s=nolds.sampen(ser,emb_dim=tau)  
        sampx.append(s)
    


    psdx=[]
    wx=[]
    wxb=[]
    sampx=[]
    l=1000
    interv=10
    N=int(l/interv)
    tau=10
    for times in range(N):
        n = np.zeros((l,), dtype=complex)
        s1=interv*times
        s2=s1+interv
        n[s1:s2] = np.exp(1j*np.random.uniform(0, 2*np.pi, (interv,)))
        ss = np.fft.ifft(n)    
        ser=np.real(ss)
        xx=autoca(ser,tau,l-2*tau)
        stdx.append(np.std(xx))
        meanx.append(np.mean(xx))
        w=autowa(ser,tau,l-2*tau)
        wb=autowb(ser,tau,l-2*tau)
        wx.append(w)
        wxb.append(wb)
        s=nolds.sampen(ser,emb_dim=tau)  
        sampx.append(s)
        xp,yp=pdswelch(ser,fs=l/2)
        zp=sum(xp*yp)
        psdx.append(zp)        

def mix_test():

    
    mixwl30=[]
   
    for rx in [0]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1.1,0.1)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=300
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        aapsdx0=[]
        awpsx0=[]
    
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                aapsdx=[]
                awpsx=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,rx)*1000
                    trendx=mix+trend[:len(mix)]
                    w=autowa(trendx[500:],tau,l)
                    wb=autowb(trendx[500:],tau,l)
                    wx.append(w)
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:500+l],fs=l/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                    zpp=apsdx(trendx,500,l)
                    aapsdx.append(zpp)
                    awpsx.append(awps(trendx[1:],500,l))
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
                aapsdx0.append(np.mean(aapsdx))
                awpsx0.append(np.mean(awpsx))
        plt.plot(awpsx0)
        
                #sampx0.append(np.mean(sampx))
        mixwl30.append(wx0)
 
        
    for fx in [50,500,1000]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.1)
        m=len(px)
        
        sn=100
        fs=18
        tau=10

        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    xr=np.arange(N)
                    trend=np.sin(2*np.pi*xr/fx)*1
                    trendx=mix+trend
                    w=autowa(trendx,tau,l)                 
                    wx.append(w)
                    wb=autowb(trendx,tau,l)                 
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:500+l],fs=l/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
        plt.plot(psdx0)

        mixwl30.append(wx0) 
        
     
    for l in range(100,1000,100):
  #  for rx in [0]:
        rx=0
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1.1,0.1)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=30
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        aapsdx0=[]
        
    
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                aapsdx=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,rx)*1000
                    trendx=mix+trend[:len(mix)]
                    w=autowa(trendx[500:],tau,l)
                    wb=autowb(trendx[500:],tau,l)
                    wx.append(w)
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:500+l],fs=l/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                    zpp=apsdx(trendx,500,l)
                    aapsdx.append(zpp)
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
                aapsdx0.append(np.mean(aapsdx))
        plt.plot(aapsdx0)
        
                #sampx0.append(np.mean(sampx))
        mixwl30.append(wx0)
         
        
def logistx_test():
    murange=np.arange(3.4,4,0.01)
    m=len(murange)
    sn=100
    tau=10
    l=30
    N=15000
    fs=18
    wx0=[]
    psdx0=[]
    sampx0=[]
    for mu in murange:


        wx=[]
        sampx=[]
        psdx=[]
        
        for times in range(sn):
            x0=np.random.choice(1000)/1000        
            logistx=chaost(500,500+N,x0,mu)           
            trendx=0*pow(np.arange(N)/N,2)
            newx=logistx+trendx
            w=autowa(newx,tau,l)
            wx.append(w)
            s=nolds.sampen(newx[:l])
           # sampx.append(s)
            p1,p2=pdswelch(newx[:l],fs)
            psd=sum(p1*p2)
            zpp=apsdx(newx,500,l)
            psdx.append(psd)
            # la=nolds.lyap_r(newx[:l])
            # lyapx.append(la)
        wx0.append(np.mean(wx))
     #   sampx0.append(np.mean(sampx))
        psdx0.append(np.mean(psdx))        
        
        
def shuffle_phase():
    from numpy import pi, e

yx1=[]
yx2=[]
yx3=[]
yx4=[]
zx1=[]
zx2=[]
zx3=[]
zx4=[]
N=2000
for i in range(100):    
    b=np.sqrt(3)
    y=np.random.uniform(-b,b,N)
    fx=np.fft.fft(y)
    phx=np.angle(fx)
    fy=np.abs(fx)*e**(1j*phx)
    z=np.fft.ifft(fy)
    
    nz=sum(np.abs(fx))/len(fx)
    fw=np.ones(len(fx))*nz
    
    
    
    fyy=fw*e**(1j*phx)
    zz=np.fft.ifft(fyy)
    
    zx=np.real(z)
    zy=np.real(zz)

    l=1000
    
    #print (apsdx(zx,100,l),apsdx(zy,100,l))
    zx1.append(apsdx(zx,100,l))
    zx2.append(apsdx(zy,100,l))
    zx3.append(awps(zy,100,l))
    zx4.append(awps(zx,100,l))
    
    x1=np.abs(np.fft.fft(zx))
    x2=np.abs(np.fft.fft(zy))
    
    x3=np.arange(1001)
    y1=sum(x3*x1[:1001])/sum(x1[:1001])
    
    x3=np.arange(1001)
    y2=sum(x3*x2[:1001])/sum(x2[:1001])    
    yx1.append(y1)
    yx2.append(y2)
    
    l=100
    xp,yp=pdswelch(zy[100:100+l],fs=l/2)
    
    
    t0=np.abs(np.fft.fft(T[0][:365]))
    lx=np.arange(183)
    ta=sum(lx*t0[:183])/sum(t0[:183])*183
    
    
    xp,yp=pdswelch(zy[10:10+l],fs=100)
    zp=sum(xp*yp)
    xx=zp/50
    yx3.append(xx)

    xp,yp=pdswelch(zy[10:10+l],fs=20)
    zp=sum(xp*yp)
    xx=zp/10
    yx4.append(xx)
    
    

    



def awps(x,s1,l):
    n=round(l/2)
    lx=np.arange(n)
    t0=np.abs(np.fft.fft(x[s1:s1+l]))
    ta=sum(lx*t0[:n])/sum(t0[1:n])
    return ta/n
    
def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx








        