#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 19:43:37 2024

@author: meng
"""

from netCDF4 import Dataset
import numpy as np
np.bool = np.bool_
def readdatat2m():
    path='/home/meng/awpsd/data/'
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    

    outfile=open(path+'era5t2m25d_ano_1979to2023_ano_g.ano','w')             
    for i in range(73):
        print (i)
        for j in range(144):
            mm=np.zeros(shape=(17,365))
            for year in range(1979,2024):
                year=int(year)
               # print year
                data = Dataset("/home/meng/awpsd/data/origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')
                air_data=data.variables['t2m'][:,i,j]
                if(len(air_data)>365):
                    air_data=np.delete(air_data,59)
                mm[year-1979,:]=air_data
            for year in range(1979,2024):
                for day in range(365):
                    t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                    outfile.write('%.6f \n'%(t))
                    outfile.flush()                
    outfile.close()  
readdatat2m()