#ifndef CLIMATE
#define CLIMATE

#include <vector>
#include <list>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>

using namespace std;

string out_file="/home/meng/awpsd/data/";
//string in_file="/p/tmp/jingfang/CODE/Python/arctic/DATA/era5ice2d_ano_1979to2019.ano";
//string in_file="/p/tmp/jingfang/CODE/Python/arctic/DATA/era5t8502d_ano_1979to2019.ano";
//string in_file="/p/tmp/jingfang/CODE/Python/arctic/DATA/era5t8505d_ano_1979to2019_g.ano";
string in_file="/home/meng/awpsd/data/era5t2m2.5g_ori_2007to2023.ano";
string in_file1="/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat";
//int  const N = 1313;  //the number of nodes res =2.5 degree

//int  const N = 1788;  //the number of nodes res =2.5 degree
int  const N = 8040;
//int  const N = 2038;  //the number of nodes res =2.5 degree
int  const N1 =377;
//const int NN = 25505;  // the number of time series vector (month)

const int NN = 6205;  // the number of time series vector (month)
//const int NN1 = 14600;
//const int taumax = 200;
const int taumax = 10;

const int stagelength=365;
int numstage=1;
double datanet[N][NN]; // datanet[i][] store the time serier for each node i

double datanet1[N1][NN];
std::vector<int> NODES;
int mdays[]={0,31,59,90,120,151,181,212,243,273,304,334,365};

//std::vector<int> EDGE2;


void readdata1();
void caulation1(int rank);




double mean_value(double ccflist[],int startpoint,int endpoint)
{
    double k=0;
    double S=0;
    for(int i = startpoint;i<=endpoint;i++)
    {
                S += ccflist[i];
                k++;
    }
    return S/k;


}

double stdv(double ccflist[],int startpoint,int endpoint,double meanccf) // calculating standard deviation of ccflist.
{
    double S=0;
    double k=0;
    //ofstream fout;
    for(int x=startpoint;x<=endpoint;x++)
    {
        //S=S+(ccflist[h][x]-meanccf)*(ccflist[h][x]-meanccf);
        S=S+(ccflist[x]-meanccf)*(ccflist[x]-meanccf);
        k++;
    }
    S=sqrt((1/(k-1))*S);
    return S;
}

double corrcoef(int i, int j, int startpoint1, int startpoint2, int length) // calculating Pearson correlation
{
    double r;
    double S1=0;
    double S2=0;
    double S3=0;
    double S4=0;
    double S5=0;
    for(int x=0;x<length;x++)
    {
        S1=S1+datanet[i][startpoint1+x]*datanet[j][startpoint2+x];
        S2=S2+datanet[i][startpoint1+x];
        S3=S3+datanet[j][startpoint2+x];
        S4=S4+datanet[i][startpoint1+x]*datanet[i][startpoint1+x];
        S5=S5+datanet[j][startpoint2+x]*datanet[j][startpoint2+x];
        //cout << x << " " << length << " " << S1 << " " << S2 << " " << S3 << " " << S4 << " " << S5 << endl;
    }
    //cout << S1 << " " << S2 << " " << S3 << " " << S4 << " " << S5 << endl;
    r=((double)length*S1-S2*S3)/(sqrt((double)length*S4-S2*S2)*sqrt((double)length*S5-S3*S3));
    return abs(r);
}


#endif // CLIMATE
