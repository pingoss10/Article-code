/* This code is to  study the cross correction
 * for the CLIMATE network/
 *
 *by Jingfang
 * 2015.11.15
 *
 *
 * */
#include "climate.h"
#include "distance.h"
#include <iostream>
#include <math.h>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <ctime>
#include <cstdlib>
#include <sstream>
#include <fstream>
#include <cmath>
#include <string>
#include <mpi.h>


using namespace  std;


int main(int argc,char **argv)
{
    int rank;
    int size;

    readdata1();

    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
    for(int i=rank;i<17;i+=size)
    {

        caulation1(i);
        //test(i,rank);
    }
    MPI_Finalize();

    return 0;

}
/* 
void test(int i_start, int rank, int size)
{
    ofstream fout1,fout2;
    stringstream ss;
    string stagestr;
        ss.clear();
        ss << rank;
        ss >> stagestr;
        string a="air_"; // output filename
        string b="_.dat";
        string filename = out_file+a+stagestr+b;
        fout1.open(filename.c_str(),std::fstream::app);
        fout1 << i_start<<"," <<rank<< "\n"; // output everything needed.
        fout1.close();
    

}
 */
string int2str(int i)
{
    string s;
    stringstream ss(s);
    ss << i;

    return ss.str();
}
void readdata1()
{

    string finalname1,finalname2;
    ifstream fintemp1,fintemp2;
    stringstream ss;
    //double a;
    //int N=N;
    //int N1=N1;

    finalname1 =in_file;
    fintemp1.open(finalname1.c_str());
    if(!fintemp1)
    {

        cout<<finalname1<<" does not exit!"<<endl;
        exit(1);
    }
    double r;

    for(int i=0;i<N;i++)
    {   //cout<<i<<endl;
        for(int j=0;j<NN;j++)
        {
            fintemp1 >> r;
            datanet[i][j]=r;

        }


    }


    finalname2 =in_file1;
    fintemp2.open(finalname2.c_str());
    if(!fintemp2)
    {

        cout<<finalname2<<" does not exit!"<<endl;
        exit(1);
    }
    double rr;

    for(int i=0;i<N1;i++)
    {   //cout<<i<<endl;
        for(int j=0;j<NN;j++)
        {
            fintemp2 >> rr;
            datanet1[i][j]=rr;

        }


    }


    fintemp1.close();
    fintemp2.close();


}




void caulation1(int rank)
{

    ofstream fout1,fout2;
    stringstream ss,ss1;
    string stagestr,stagestr1;


    double ccf,maxccf,meanccf,minccf;
    int maxind,minind;
    int tauvalues[taumax*2+1];
    double Wmin,Wmax;
    double TDmax,TDmin,TDabs;
    double P0lag;
    for(int x=-taumax;x<=taumax;x++)
    {
        tauvalues[x+taumax]=x; // the list of time delay values (from -tau_max to +tau_max)
    }

    int yearx = rank;
    int monthXX=12;




    ss.clear();
    ss << yearx+2007;
    ss >> stagestr;
    for (int monthx=0; monthx<monthXX;monthx++)
   {

    //int monthx = rank;
    ss1.clear();
    ss1 << monthx+1;
    ss1 >> stagestr1;
    string a="_t2m_autocorr10d_abs"; // output filename
    string b=".dat";
    string filename = out_file+stagestr+"_"+stagestr1+a+b;
    fout1.open(filename.c_str());
    int stagelengthx = mdays[monthx+1] - mdays[monthx];

    int startpoint = (rank+1)*stagelength+mdays[monthx];
    double ccflist1[2*taumax+1];
    double ww,cc,nn,wn,cn;
    double W,C,WN,CN;

     

    for (int node1=0;node1<N;node1++)
    {
        int i=node1;
        ww=0.0;
        cc=0.0;
        nn=0.0;
        wn=0.0;
        cn=0.0;

        for (int node2 =0;node2<1;node2++)
            {
                int j=node1;
                maxccf=-1000;
                maxind=-1000;
                meanccf=0;
                minccf=1000;
                minind=1000;
                for(int tau=taumax;tau>=0;tau--)
                {
                    ccf=corrcoef(j,i,startpoint,startpoint-tau,stagelengthx);
                    ccflist1[taumax-tau]=ccf; // calculate the first half of the cross-correlation
                    meanccf+=ccf/(2*taumax+1); // calculate the mean of the cross-correlation step by step
                    if (ccf>maxccf)
                    {
                        maxccf=ccf; // take the maximal cross-correlation
                        maxind=taumax-tau; // take the index for the maximal cross-correlation
                    }
                    if (ccf<minccf)
                    {
                        minccf=ccf; // take the minimal cross-correlation
                        minind=taumax-tau; // take the index for the minimal cross-correlation
                    }
                    if (tau==0)
                    {
                        P0lag=ccf; // the correlation at 0 time delay.
                    }
                }
                for(int tau=1;tau<=taumax;tau++)
                {
                    ccf=corrcoef(j,i,startpoint-tau,startpoint,stagelengthx);
                    ccflist1[taumax+tau]=ccf; // calculate the second half of the cross-correlation
                    meanccf=meanccf+ccf/(2*taumax+1);
                    if (ccf>maxccf)
                    {
                        maxccf=ccf;
                        maxind=taumax+tau;
                    }
                    if (ccf<minccf)
                    {
                        minccf=ccf;
                        minind=taumax+tau;
                    }
                }
                Wmax=(maxccf-meanccf)/(stdv(ccflist1,0,2*taumax,meanccf)); // calculate positive link weight
                Wmin=(minccf-meanccf)/(stdv(ccflist1,0,2*taumax,meanccf)); // calculate negative link weight
                TDmax=tauvalues[maxind]; // timedelay for the positive peak
                TDmin=tauvalues[minind]; // timedelay for the negative peak
                if(fabs(maxccf) > fabs(minccf))
                {
                    TDabs = TDmax;
                }
                else TDabs = TDmin;
                if(Wmax==Wmax){
                ww=ww+Wmax;
                cc=cc+maxccf;
                wn=wn+Wmin;
                cn=cn+minccf;
                nn=nn+1;
                }
                fout1 << Wmax << "\n"; // output everything needed.
                cout<<i<<" "<<j<<" "<<Wmax<<endl;

        }


    }
    fout1.close();
   }
}

