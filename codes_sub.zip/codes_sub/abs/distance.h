/*
 this head file is to calculate the distance given latitude and longtitude
 for two nodes.


 by jingfang
 2015.11.13 Israel


 Haversine Formula
 R = earth’s radius (mean radius = 6,371km)
 Δlat = lat2− lat1
 Δlong = long2− long1
 a = sin²(Δlat/2) + cos(lat1).cos(lat2).sin²(Δlong/2)
 c = 2.arcsin(sqrt(a))
 d = R.c


 */

#ifndef DISTANCE
#define DISTANCE
#include<math.h>

#include<iostream>
using namespace std;
// @brief The usual PI/180 constant
//static const double DEG_TO_RAD = 0.017453292519943295769236907684886;

static const double DEG_TO_RAD = M_PI/180;
/// @brief Earth's quatratic mean radius for WGS-84
//static const double EARTH_RADIUS_IN_METERS = 6372.797560856;

static const double EARTH_RADIUS_IN_METERS = 6371;
// Convert our passed value to Radians

double ToRad( double nVal )
{
      return nVal * DEG_TO_RAD;
 //   return nVal * (M_PI/180);
}


double CalculateDistance( double nLat1, double nLon1, double nLat2, double nLon2 )
{
    //double nRadius = 6371; // Earth's radius in Kilometers

    // Get the difference between our two points then convert the difference into radians
    double nDLat = ToRad(nLat2 - nLat1);
    //cout<<nDLat<<endl;
    double nDLon = ToRad(nLon2 - nLon1);

    nLat1 =  ToRad(nLat1);
    nLat2 =  ToRad(nLat2);

    double nA =	pow ( sin(nDLat/2), 2) +
                cos(nLat1) * cos(nLat2) *
                pow ( sin(nDLon/2), 2 );

    //double nC = 2 * asin( nA);
    double nC = 2 * atan2( sqrt(nA), sqrt( 1 - nA ));

    double nD = EARTH_RADIUS_IN_METERS * nC;

    return nD; // Return our calculated distance
}





#endif // DISTANCE

