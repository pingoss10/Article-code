#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 10 11:23:24 2025

@author: meng
"""

import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
from numpy import pi, e

def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def mix_test():

        N=20000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
            print (a)
        
        x=a*np.sin(2*np.pi*np.arange(N)/2.5)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1.01,0.01)
        m=len(px)
        
        sn=100
        l=3000
     
        aapsdx0=[]
    
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
               
                aapsdx=[]
                
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                   
                    zpp=apsdx(mix,500,l)
                    aapsdx.append(zpp)
                    
                aapsdx0.append(np.mean(aapsdx))
               # awpsx0.append(np.mean(awpsx))
        plt.plot(aapsdx0)
