#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 15:02:18 2024

@author: meng
"""

import nolds
from scipy.interpolate import griddata
from netCDF4 import Dataset

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
from numpy import pi, e
from netCDF4 import Dataset
import numpy as np
np.bool = np.bool_

import numpy as np
from scipy import stats
import xarray as xr


def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,tau+1):
        x1=x[tau:l+tau]
        x2=x[tau+t:l+t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    w=(1-np.mean(z))/np.std(z)
    return z
def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def autowc(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)*1/np.sqrt(2*tau)
    return a


def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def awps(x,s1,l):
    n=round(l/2)
    lx=np.arange(n)
    t0=np.abs(np.fft.fft(x[s1:s1+l]))
    ta=sum(lx*t0[:n])/sum(t0[1:n])
    return ta/n

def white_noise(N,b):
    yx1=[]
    yx2=[]
    yx3=[]
    yx4=[]
    zx1=[]
    zx2=[]
    zx3=[]
    zx4=[]
    y=np.random.uniform(-b,b,N)#white noise
    fx=np.fft.fft(y)
    phx=np.angle(fx)
    fy=np.abs(fx)*e**(1j*phx)
    z=np.fft.ifft(fy)
        
    nz=sum(np.abs(fx))/len(fx)
    fw=np.ones(len(fx))*nz
        
    fyy=fw*e**(1j*phx)
    zz=np.fft.ifft(fyy)
        
    zx=np.real(z)#white noise
    zy=np.real(zz)#white noise with uniform power spectrum
    
    return z,zz

    
def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

def compare_ori():
    path='/home/meng/awpsd/data/'
    outfile=open(path+'t2m_rmse1d_era5_monthly.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    for year in range(2007,2024):
        year=int(year)   
        print (year)        
        months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
        monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
        data1 = Dataset("/home/meng/awpsd/data/origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')
        To=data1.variables['t2m']
        data2 = xr.open_dataset(path+"origin/t2m_forecast1d_ecwmf_"+str(year)+"", engine = 'cfgrib')
        Tp=data2['t2m'].values
        for m in range(12):
            for k in range(len(nodes)):
                i=int(regrid[:,3][k])
                j=int(regrid[:,4][k])
                to=To[:,i,j]
                tp=Tp[:,i,j]
                if(len(to)>365):
                    to=np.delete(to,59)
                    tp=np.delete(tp,59)
                
                z1=to[monthd[m]:monthd[m]+months[m]]  
                z2=tp[monthd[m]:monthd[m]+months[m]]  
                #print (rmse(z1,z2),np.std(z1))
                outfile.write('%.6f %.6f \n'%(rmse(z1,z2),np.std(z1)))
                outfile.flush()            
    outfile.close()
            
def compare_orit850():
    path='/home/meng/awpsd/data/'
    outfile=open(path+'t2m_rmse10d_era5_monthly.dat','w')
    tau=10
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    for year in range(2007,2024):
        year=int(year)   
        print (year)        
        months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
        monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
        data1 = Dataset("/home/meng/awpsd/data/origin/t850_era5_"+str(year)+".nc",'r',format='NETCDF4')
        To=data1.variables['t']
        data2 = xr.open_dataset(path+"origin/t850_forecast10d_ecwmf_"+str(year)+"", engine = 'cfgrib')
        Tp=data2['t2m'].values
        for m in range(12):
            for k in range(len(nodes)):
                i=int(regrid[:,3][k])
                j=int(regrid[:,4][k])
                to=To[:,i,j]
                tp=Tp[:,i,j]
                if(len(to)>365):
                    to=np.delete(to,59)
                    tp=np.delete(tp,59)
                
                z1=to[monthd[m]:monthd[m]+months[m]]  
                z2=tp[monthd[m]:monthd[m]+months[m]]  
                #print (rmse(z1,z2),np.std(z1))
                outfile.write('%.6f %.6f \n'%(rmse(z1,z2),np.std(z1)))
                outfile.flush()            
    outfile.close()


def readdata_t2m_climateo():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1994,2024):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_climate.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1994,2024):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1994][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1994]=ice
        
        for day in range(365):
            outfile.write('%.6f %.6f \n'%(np.mean(mm[:,day]),np.std(mm[:,day])))
            outfile.flush()                
    outfile.close() 



def read_ano_forec():
    path='/home/meng/awpsd/data/'
    climateo=np.loadtxt(path+'era5t2m2.5g_climateo.ano')
    avex=np.reshape(climateo[:,0],(8040,365))
    stdx=np.reshape(climateo[:,1],(8040,365))
    outfile=open(path+'t2m_forc10d_era5_ano.dat','w')
    
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    for year in range(2007,2024):
        year=int(year)   
        print (year)     
        s=(year-2007)*365
        months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
        monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
        data2 = xr.open_dataset(path+"origin/t2m_forecast10d_ecwmf_"+str(year)+"", engine = 'cfgrib')
        Tp=data2['t2m'].values
        for d in range(365):
            for k in range(len(nodes)):
                i=int(regrid[:,3][k])
                j=int(regrid[:,4][k])
                tp=Tp[:,i,j]
                if(len(tp)>365):
                    tp=np.delete(tp,59)
            
                tt=np.sqrt((tp[d]-avex[k,d])**2)
                ttt=(tp[d]-avex[k,d])/stdx[k,d]
                
                outfile.write('%.6f %.6f \n'%(tt,ttt))
                outfile.flush()            
    outfile.close()
    


def compare_ano():
    path='/home/meng/awpsd/data/'
    temp=np.loadtxt(path+'era5t2m2.5g_ano_2007to2023.ano')
    To=np.reshape(temp,(8040,6205))
    forc=np.loadtxt(path+'t2m_forc5d_era5_ano.dat')
    Tp=np.reshape(forc[:,1],(6205,8040))
    outfile=open(path+'t2m_corr5d_era5_monthly_ano.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    for year in range(2007,2024):
        year=int(year)   
        print (year)     
        s=(year-2007)*365
        months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
        monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
      
        for m in range(12):
            for k in range(len(nodes)):   
                to=To[k][s:s+365]
                tp=Tp[:,k][s:s+365]  
                z1=to[monthd[m]:monthd[m]+months[m]]  
                z2=tp[monthd[m]:monthd[m]+months[m]]  
                outfile.write('%.6f %.6f \n'%(pearsonr(z1,z2)[0],pearsonr(z1,z2)[1]))
                outfile.flush()            
    outfile.close()


def compare_ano():
    path='/home/meng/awpsd/data/'
    temp=np.loadtxt(path+'era5t2m2.5g_ano_2007to2023.ano')
    To=np.reshape(temp,(8040,6205))
    forc=np.loadtxt(path+'t2m_forc10d_era5_ano.dat')
    Tp=np.reshape(forc[:,1],(6205,8040))
    outfile=open(path+'t2m_corr10d_era5_monthly_ano.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    for year in range(2007,2024):
        year=int(year)   
        print (year)     
        s=(year-2007)*365
        months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
        monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
      
        for m in range(12):
            for k in range(len(nodes)):   
                to=To[k][s:s+365]
                tp=Tp[:,k][s:s+365]  
                z1=to[monthd[m]:monthd[m]+months[m]]  
                z2=tp[monthd[m]:monthd[m]+months[m]]  
                outfile.write('%.6f %.6f \n'%(pearsonr(z1,z2)[0],pearsonr(z1,z2)[1]))
                outfile.flush()            
    outfile.close()




















