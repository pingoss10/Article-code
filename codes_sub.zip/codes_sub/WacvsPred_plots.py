#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 17 15:23:11 2024

@author: meng
"""

import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
from scipy.stats import percentileofscore
from scipy.stats import gaussian_kde

from scipy.stats import gaussian_kde
from scipy.signal import detrend
import matplotlib as mpl
import scipy
import glob
import seaborn as sns
import pymannkendall as mk
from scipy.stats import pearsonr
from numpy import pi, e

def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,tau+1):
        x1=x[tau:l+tau]
        x2=x[tau+t:l+t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    return z


    

def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def autowc(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)*1/np.sqrt(2*tau)
    return a


def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)

def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

def sf(x):
    fx=np.fft.fft(x)
    phx=np.angle(fx)
    np.random.shuffle(phx)
    fy=np.abs(fx)*e**(1j*phx)
    y=np.fft.ifft(fy)
    z=np.real(y) 
    return z

def mk_test(y):
    import pymannkendall as mk
    result = mk.original_test(y)
    return result.slope, result.p, result.z

def outputdata():
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/globe_726_new.dat')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    path='/home/meng/awpsd/data/'
    
    node=[int(i) for i in regrid[:,0]]
    year=2023
    
    outfile=open(path+'t2m_10d_8040.dat','w')
    for year in range(2007,2024):
        data1=np.loadtxt(path+"t2m_autowc10d_era5_"+str(year)+".dat")
        data2=np.loadtxt(path+"t2m_rmse10d_era5_"+str(year)+".dat")
        for j in range(12):
            for i in node:
                i=int(i)
                outfile.write('%.6f %.6f \n'%(data1[i,j],data2[i,j]))
                outfile.flush()
    outfile.close()
            
    
    outfile=open(path+'t2m+10d_8040c.dat','w')
    for year in range(2007,2024):
        for month in range(1,13):
            data=np.loadtxt("/home/meng/awpsd/data/"+str(year)+"_"+str(month)+"_t2m_autocorr10d.dat")
            for i in range(len(data)):
                outfile.write('%.6f \n'%(data[i]))
                outfile.flush()
    outfile.close()
    
    
    outfile=open(path+'t2m+10d_8040cabs.dat','w')
    for year in range(2007,2024):
        for month in range(1,13):
            data=np.loadtxt("/home/meng/awpsd/data/"+str(year)+"_"+str(month)+"_t2m_autocorr10d_abs.dat")
            for i in range(len(data)):
                outfile.write('%.6f \n'%(data[i]))
                outfile.flush()
    outfile.close()
    
    
    data=np.loadtxt(path+'t2m_10d_8040.dat')
    
    wx=np.reshape(data[:,0],(204,8040))
    px=np.reshape(data[:,1],(204,8040))


def Wac_vs_Pred():
    path='/home/meng/awpsd/data/'
    data1=np.loadtxt(path+"t2m_autowc10d_era5_monthly.dat")
    #data2=np.loadtxt(path+'t2m+10d_8040c.dat')
    #data3=np.loadtxt(path+'t2m+10d_8040cabs.dat')
    
    data4=np.loadtxt(path+'t2m_rmse5d_era5_monthly.dat')
    climateo=np.loadtxt(path+'era5t2m2.5g_climateo.ano')
    data5=np.loadtxt(path+'t2m_corr5d_era5_monthly_ano.dat')
 
    
    
    
    wx=np.reshape(data1,(204,8040))
    px=np.reshape(data4[:,0],(204,8040))
    ppx=np.reshape(data4[:,0]/data4[:,1],(204,8040))
    psx=np.reshape(data4[:,1],(204,8040))
    cx=np.reshape(abs(data5[:,0]),(204,8040))
    ccx=np.reshape(data5[:,0]/data4[:,1],(204,8040))
    csx=np.reshape(data5[:,1],(204,8040))   
    




    wy=[np.mean(wx[:,i]) for i in range(8040)]
    
    py=[np.mean(px[:,i]) for i in range(8040)]
    psy=[np.mean(psx[:,i]) for i in range(8040)]
   
    
    cy=[np.mean(cx[:,i]) for i in range(8040)]
    csy=[np.mean(csx[:,i]) for i in range(8040)]     
    
    cay=[np.mean(abs(cx[:,i])) for i in range(8040)]


    # wt=[]
    # pt=[]
    # pst=[]
    # ct=[]
    # cst=[]
    
    # wt1=[]
    # pt1=[]
    # pst1=[]
    # ct1=[]
    # cst1=[]

    # for i in range(8040):
    #     slope, p, z = mk_test(wx[:,i])
    #     wt.append(z)   
    #     wt1.append(p)         

    #     slope, p, z = mk_test(px[:,i])
    #     pt.append(z)  
    #     pt1.append(p)  

    #     slope, p, z = mk_test(psx[:,i])
    #     pst.append(z)  
    #     pst1.append(p)  

    #     slope, p, z = mk_test(cx[:,i])
    #     ct.append(z)  
    #     ct1.append(p)  

    #     slope, p, z = mk_test(csx[:,i])
    #     cst.append(z)  
    #     cst1.append(p)  
    
    
    # wcx=[]
    # wcx1=[]    
    # for i in range(8040):
    #     print (i)
    #     x1=[np.mean(wx[j-12:j,i]) for j in range(12,204)] 
    #     x2=[np.mean(cx[j-12:j,i]) for j in range(12,204)] 
    #     wcx.append(pearsonr(x1,x2)[0])
    #     yx=[]
    #     for t in range(100):
    #         y1=sf(x1)
    #         y2=sf(x2)
    #         yx.append(pearsonr(y1,y2)[0])
            
    #     p=percentileofscore(yx, pearsonr(x1,x2)[0], kind='weak')
    #     wcx1.append(p)        



    outfile=open(path+'dwcx.dat','w')
    outfile1=open(path+'dwcxs.dat','w')
    dwcx=[]
    dwcx1=[]    
    dwcx2=[]
    for i in range(8040):
        print (i)
        x1=[np.mean(wx[j-12:j,i]) for j in range(12,204)] 
        x2=[np.mean(cx[j-12:j,i]) for j in range(12,204)] 
        x1=detrend(x1)
        x2=detrend(x2)
        dwcx.append(pearsonr(x1,x2)[0])
        yx=[]
        for t in range(100):
            y1=sf(x1)
            y2=sf(x2)
            ccc=pearsonr(y1,y2)[0]
            yx.append(ccc)
            dwcx2.append(ccc)
            outfile1.write('%.6f \n'%(ccc))
            outfile1.flush()
            
        p=percentileofscore(yx, pearsonr(x1,x2)[0], kind='weak')
        dwcx1.append(p)    
        outfile.write('%.6f %.6f \n'%(pearsonr(x1,x2)[0],p))
        outfile.flush()
    outfile.close()
    outfile1.close()
    

    wy=np.array(wy)
    cay=np.array(cay)
def plot_scatter():
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    from scipy.stats import gaussian_kde


    import numpy as np
    import matplotlib.pyplot as plt
    from mpl_toolkits.basemap import Basemap
    from scipy.interpolate import griddata
        
  #  plt.rcParams['font.family'] = 'Times New Roman'
    
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    fig=plt.figure()   



    
    ax=plt.subplot(321)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=32,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=32,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(wy)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=0.55, vmax=0.85)
    
    # ===== 添加颜色条 =====
    #cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Temporal Mean', fontsize=34, labelpad=15)
    ax.set_title('$W_{ACF}$',fontsize=38,x=0.5,y=1.03)
    ax.annotate('a', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(323)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=32,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=32,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(cay)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis_r', vmin=0.15, vmax=0.3)
    
    # ===== 添加颜色条 =====
    #cbar = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.04, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
 
    
    
    cbar.set_label('Temporal Mean', fontsize=34, labelpad=15)
    ax.set_title('Forecasting Skill',fontsize=38,x=0.5,y=1.03)
    ax.annotate('b', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  




    ax=plt.subplot(325)
 
    # KDE 密度
    wy=np.array(wy)
    cy=np.array(cy)
    xmajorLocator = MultipleLocator(0.1) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.2f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.05) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor',length=6)    
    # KDE 密度
    xy = np.vstack([wy, cy])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wy[idx]
    ex1y_sorted = cay[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax.scatter( wacfy_sorted,ex1y_sorted, c=z_sorted, s=50, cmap='mako')
    ax.annotate('$r=-0.66, p<0.001$', xy=(0.5, 0.9), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')


    ax.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=34)
    ax.set_ylabel(r"Forecasting Skill", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度

    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both', ticks=ticks)
    cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both')
    cbar.ax.tick_params(labelsize=32)
    cbar.set_label("Density", fontsize=34)
    ax.annotate('c', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    
    ax=plt.subplot(322)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=dwcx
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-0.6, vmax=0.6)
    
    # ===== 添加颜色条 =====
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')  
    cbar.ax.tick_params(labelsize=32)
    dwcx1=np.array(dwcx1)
    signodes= (dwcx1< 5) | (dwcx1>95)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')   
    lats1=[2.5]
    lons1=[217.5]
    x, y = m(lons1,lats1)
    m.scatter(x,y,800,marker='.',c='yellow')   
        
    cbar.set_label('r-values', fontsize=34, labelpad=15)
    ax.set_title('Correlations between $W_{\mathrm{ACF}}$ \n and Forecasting Skill',fontsize=34,x=0.5,y=1.03)
   # ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('d', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  

    ax=plt.subplot(324)
 

    ax.xaxis.set_major_locator(MultipleLocator(0.4))
    ax.xaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax.yaxis.set_major_locator(MultipleLocator(1))
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    
    # 设置次刻度
    ax.xaxis.set_minor_locator(MultipleLocator(0.2))
    ax.yaxis.set_minor_locator(MultipleLocator(0.2))
    
    # 设置刻度样式
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor', length=6)
    
    # 设置 y 轴范围
    ax.set_ylim(-0.1, 2)
    
    # 绘制 KDE 曲线（用于视觉美观）
    
    # KDE 绘制（并提取 line 对象）
    x_grid = np.linspace(min(min(dwcx), min(dwcx2)), max(max(dwcx), max(dwcx2)), 1000)
    
    # 用 scipy KDE 计算两个 PDF（用 seaborn 渲染的是图像，用 scipy 是为了取数据）
    kde_real = gaussian_kde(dwcx, bw_method=1.0)
    kde_shuffle = gaussian_kde(dwcx2, bw_method=1.0)
    
    y_real = kde_real(x_grid)
    y_shuffle = kde_shuffle(x_grid)
    
    # 绘图（仍用 seaborn 美观）
    sns.lineplot(x=x_grid, y=y_real, color='firebrick', linewidth=5, label='Real', ax=ax)
    sns.lineplot(x=x_grid, y=y_shuffle, color='grey', linewidth=5, label='Phase Shuffled', ax=ax)
    
    # 找出 real > shuffled 的区域
    mask = y_real > y_shuffle
    mask_left = x_grid < 0
    ax.fill_between(x_grid, y_real, 0, where=mask_left, interpolate=True, 
                    color='yellow', alpha=0.2)    
    # 填充显著区域
    # ax.fill_between(x_grid, y_real, y_shuffle, where=mask, interpolate=True,
    #                 color='yellow', alpha=0.3)
    
    # 坐标轴与图例
    ax.set_xlabel(r"Correlations", fontsize=34)
    ax.set_ylabel(r"PDF", fontsize=34)
    ax.legend(fontsize=34, loc='upper right')

# 画中位数线
    ax.axvline(x=np.median(dwcx), color='firebrick', linestyle=':', linewidth=2, label='Real Median')
    ax.axvline(x=np.median(dwcx2), color='grey', linestyle=':', linewidth=2, label='Shuffled Median')
    
    ax.annotate('$75\%$', xy=(0.3, 0.2), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12),rotation=0,
                textcoords='offset points', color='firebrick', ha='left', va='bottom')
    
    # 添加图注编号
    ax.annotate('e', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12),
                textcoords='offset points', color='k', ha='left', va='bottom')

    ax=plt.subplot(326)
 

    xmajorLocator = MultipleLocator(3) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.1) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    ax2 = ax.twinx()
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.05) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor',length=6)  
    ax2.yaxis.set_minor_locator(yminorLocator) 
    ax2.tick_params(which='both', width=1.2, labelsize=32)
    ax2.tick_params(which='major', length=12)  
    ax2.tick_params(which='minor',length=6)      
    
    i=3891
    x1=[np.mean(wx[j-12:j,i]) for j in range(12,204)] 
    x2=[np.mean(cx[j-12:j,i]) for j in range(12,204)] 
    y1=detrend(x1)
    y2=detrend(x2)   
    x1=np.array(x1)
    x2=np.array(x2)
    x3=np.array(y1)
    x4=np.array(y2)
    dates=np.arange(192)/12.+2007
    ax.plot(dates, x1, color='#1a80bb',linewidth=3, label='$W_{\mathrm{ACF}}$')
    ax.set_ylabel('$W_{\mathrm{ACF}}$', fontsize=34, color='#1a80bb')
    ax.set_ylim(0.45,0.95)
    
    # 副轴：右侧 y 轴
    ax2.plot(dates, x2, color='#112A46',linewidth=3, label='Forecasting Skill')
    ax2.set_ylim(-0.3,0.65)
    ax2.set_ylabel('Forecasting Skill', fontsize=34, color='#112A46')

    ax.annotate('($2.5^\circ N, 142.5^\circ W$)', xy=(0.05,0.93), xycoords='axes fraction', fontsize=34, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')   
    ax.annotate('$r_{detrend}=-0.86$', xy=(0.6,0.1), xycoords='axes fraction', fontsize=34, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')     


    ax.set_xlabel(r"Time", fontsize=34)
    
    ax.annotate('f', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')


    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.2, wspace = 0.3)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(34, 30)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig3_scatter.png",bbox_inches='tight',dpi=300)   




def plot_scatterx():
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    from scipy.stats import gaussian_kde


    import numpy as np
    import matplotlib.pyplot as plt
    from mpl_toolkits.basemap import Basemap
    from scipy.interpolate import griddata
        
  #  plt.rcParams['font.family'] = 'Times New Roman'
    
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    fig=plt.figure()   



    
    ax=plt.subplot(321)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=32,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=32,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(wy)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=0.55, vmax=0.85)
    
    # ===== 添加颜色条 =====
    #cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Temporal Mean', fontsize=34, labelpad=15)
    ax.set_title('$W_{ACF}$',fontsize=38,x=0.5,y=1.03)
    ax.annotate('a', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(323)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=32,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=32,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(cy)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis_r', vmin=0.13, vmax=0.28)
    
    # ===== 添加颜色条 =====
    #cbar = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.04, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
 
    
    
    cbar.set_label('Temporal Mean', fontsize=34, labelpad=15)
    ax.set_title('Forecasting Skill',fontsize=38,x=0.5,y=1.03)
    ax.annotate('b', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  




    ax=plt.subplot(325)
 
    # KDE 密度
    wy=np.array(wy)
    cy=np.array(cy)
    xmajorLocator = MultipleLocator(0.1) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.2f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.05) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor',length=6)    
    # KDE 密度
    xy = np.vstack([wy, cy])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wy[idx]
    ex1y_sorted = cy[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='mako')
    ax.annotate('$r=-0.62, p<0.001$', xy=(0.5, 0.9), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')


    ax.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=34)
    ax.set_ylabel(r"Forecasting Skill", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度

    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both', ticks=ticks)
    cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both')
    cbar.ax.tick_params(labelsize=32)
    cbar.set_label("Density", fontsize=34)
    ax.annotate('c', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    
    ax=plt.subplot(322)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=dwcx
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-0.6, vmax=0.6)
    
    # ===== 添加颜色条 =====
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')  
    cbar.ax.tick_params(labelsize=32)
    dwcx1=np.array(dwcx1)
    signodes= (dwcx1< 5) | (dwcx1>95)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')   
    lats1=[2.5]
    lons1=[222.5]
    x, y = m(lons1,lats1)
    m.scatter(x,y,800,marker='.',c='yellow')   
        
    cbar.set_label('r-values', fontsize=34, labelpad=15)
    ax.set_title('Correlations between $W_{\mathrm{ACF}}$ \n and Forecasting Skill',fontsize=34,x=0.5,y=1.03)
   # ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('d', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  

    ax=plt.subplot(324)
 

    ax.xaxis.set_major_locator(MultipleLocator(0.4))
    ax.xaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    ax.yaxis.set_major_locator(MultipleLocator(1))
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
    
    # 设置次刻度
    ax.xaxis.set_minor_locator(MultipleLocator(0.2))
    ax.yaxis.set_minor_locator(MultipleLocator(0.2))
    
    # 设置刻度样式
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor', length=6)
    
    # 设置 y 轴范围
    ax.set_ylim(-0.1, 2)
    
    # 绘制 KDE 曲线（用于视觉美观）
    
    # KDE 绘制（并提取 line 对象）
    x_grid = np.linspace(min(min(dwcx), min(dwcx2)), max(max(dwcx), max(dwcx2)), 1000)
    
    # 用 scipy KDE 计算两个 PDF（用 seaborn 渲染的是图像，用 scipy 是为了取数据）
    kde_real = gaussian_kde(dwcx, bw_method=1.0)
    kde_shuffle = gaussian_kde(dwcx2, bw_method=1.0)
    
    y_real = kde_real(x_grid)
    y_shuffle = kde_shuffle(x_grid)
    
    # 绘图（仍用 seaborn 美观）
    sns.lineplot(x=x_grid, y=y_real, color='firebrick', linewidth=5, label='Real', ax=ax)
    sns.lineplot(x=x_grid, y=y_shuffle, color='grey', linewidth=5, label='Phase Shuffled', ax=ax)
    
    # 找出 real > shuffled 的区域
    mask = y_real > y_shuffle
    mask_left = x_grid < 0
    ax.fill_between(x_grid, y_real, 0, where=mask_left, interpolate=True, 
                    color='yellow', alpha=0.2)    
    # 填充显著区域
    # ax.fill_between(x_grid, y_real, y_shuffle, where=mask, interpolate=True,
    #                 color='yellow', alpha=0.3)
    
    # 坐标轴与图例
    ax.set_xlabel(r"Correlations", fontsize=34)
    ax.set_ylabel(r"PDF", fontsize=34)
    ax.legend(fontsize=34, loc='upper right')

# 画中位数线
    ax.axvline(x=np.median(dwcx), color='firebrick', linestyle=':', linewidth=2, label='Real Median')
    ax.axvline(x=np.median(dwcx2), color='grey', linestyle=':', linewidth=2, label='Shuffled Median')
    
    ax.annotate('$71\%$', xy=(0.3, 0.2), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12),rotation=0,
                textcoords='offset points', color='firebrick', ha='left', va='bottom')
    
    # 添加图注编号
    ax.annotate('e', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12),
                textcoords='offset points', color='k', ha='left', va='bottom')

    ax=plt.subplot(326)
 

    xmajorLocator = MultipleLocator(3) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.1) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    ax2 = ax.twinx()
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.05) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor',length=6)  
    ax2.yaxis.set_minor_locator(yminorLocator) 
    ax2.tick_params(which='both', width=1.2, labelsize=32)
    ax2.tick_params(which='major', length=12)  
    ax2.tick_params(which='minor',length=6)      
    
    i=3893
    x1=[np.mean(wx[j-12:j,i]) for j in range(12,204)] 
    x2=[np.mean(cx[j-12:j,i]) for j in range(12,204)] 
    y1=detrend(x1)
    y2=detrend(x2)   
    x1=np.array(x1)
    x2=np.array(x2)
    x3=np.array(y1)
    x4=np.array(y2)
    dates=np.arange(192)/12.+2007
    ax.plot(dates, x1, color='#1a80bb',linewidth=3, label='$W_{\mathrm{ACF}}$')
    ax.set_ylabel('$W_{\mathrm{ACF}}$', fontsize=34, color='#1a80bb')
    ax.set_ylim(0.45,0.95)
    
    # 副轴：右侧 y 轴
    ax2.plot(dates, x2, color='#112A46',linewidth=3, label='Forecasting Skill')
    ax2.set_ylim(-0.3,0.65)
    ax2.set_ylabel('Forecasting Skill', fontsize=34, color='#112A46')

    ax.annotate('($2.5^\circ N, 137.5^\circ W$)', xy=(0.05,0.93), xycoords='axes fraction', fontsize=34, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')   
    ax.annotate('$r=-0.48$ \n $r_{detrend}=-0.60$', xy=(0.6,0.1), xycoords='axes fraction', fontsize=34, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')     


    ax.set_xlabel(r"Time", fontsize=34)
    
    ax.annotate('f', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')


    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.2, wspace = 0.3)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(34, 30)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig3_scatter10d.png",bbox_inches='tight',dpi=300)   




    

    print (pearsonr(x1,x2))
    zz1=py
    zz2=psy
    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(zz2, zz1)
    x=np.array(zz2)
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = slope*x_data+intercept
    plt.scatter(zz2,zz1)
    plt.plot(x_data,y_data,'r')
    zz3=slope*np.array(zz2)+intercept
    zz4=np.array(zz1)-np.array(zz3)
 
    zz1=x1
    zz2=x6
    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(zz2, zz1)
    x=np.array(zz2)
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = slope*x_data+intercept
    plt.scatter(zz2,zz1)
    plt.plot(x_data,y_data,'r')
    zz3=slope*np.array(zz2)+intercept
    zz5=np.array(zz1)-np.array(zz3)
    
    print (rmse(zz1,zz3),pearsonr(x1,zz5))    
 
    print (rmse(zz1,zz3),pearsonr(zz5,zz4))


    xwo=[]
    for i in range(204):
        xwo.append(pearsonr(wx1[i,:],ox[i,:])[0])

    xrs=[]
    for i in range(204):
        xrs.append(pearsonr(px[i,:],psx[i,:])[0])

    
    z1=[np.mean(wx[i:i+12,:2796]) for i in range(192)]
    z2=[np.mean(px[i:i+12,:2796]) for i in range(192)]
    z3=[np.mean(wx[i:i+12,2796:4020+1225]) for i in range(192)]    
    z4=[np.mean(px[i:i+12,2796:4020+1225]) for i in range(192)]   
    z5=[np.mean(wx[i:i+12,4020+1225:]) for i in range(192)]
    z6=[np.mean(px[i:i+12,4020+1225:]) for i in range(192)]
    z7=[np.mean(psx[i:i+12,4020+1225:]) for i in range(192)]
    
    xxx=[]
    xa=[np.mean(wx1[i,:]) for i in range(204)]
    for i in range(192):
        xxx.append(sum(xa[i:i+12]))
        
    zz1=z6
    zz2=z7

    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(zz2, zz1)
    x=np.array(zz2)
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = slope*x_data+intercept
    plt.scatter(zz2,zz1)
    plt.plot(x_data,y_data,'r')
    zz3=slope*np.array(zz2)+intercept
    zz4=np.array(zz1)-np.array(zz3)
    
    print (rmse(zz1,zz3),pearsonr(z1,zz4))
    
    
    z1=[np.mean(wx[i,:4020]) for i in range(204)]
    z2=[np.mean(cx[i,:4020]) for i in range(204)]
    z3=[np.mean(csx[i,:4020]) for i in range(204)]    
    z5=[np.mean(px[i,:4020]) for i in range(204)]
    z6=[np.mean(psx[i,:4020]) for i in range(204)]
    
    
    z1=[np.mean(wx1[i,:]) for i in range(204)]
    z2=[np.mean(ex[i,:]) for i in range(204)]
    z3=[np.mean(ox[i,:]) for i in range(204)]    
    z4=[np.mean(ox1[i,:]) for i in range(204)]   
    z5=[np.mean(px[i,:]) for i in range(204)]
    z6=[np.mean(psx[i,:]) for i in range(204)]    
    
    xxx=[]
    xa=[np.mean(wx1[i,:]) for i in range(204)]
    for i in range(192):
        xxx.append(sum(xa[i:i+12]))
        
    zz1=z5
    zz2=z6

    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(zz2, zz1)
    x=np.array(zz2)
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = slope*x_data+intercept
    plt.scatter(zz2,zz1)
    plt.plot(x_data,y_data,'r')
    zz3=slope*np.array(zz2)+intercept
    zz4=np.array(zz1)-np.array(zz3)
    
    print (rmse(zz1,zz3),pearsonr(z1,zz4))
    
    k1=[np.mean(z1[i:i+12]) for i in range(192)]
    k2=[np.mean(z2[i:i+12]) for i in range(192)]
    k3=[np.mean(z3[i:i+12]) for i in range(192)]
    k5=[np.mean(z5[i:i+12]) for i in range(192)]
    k6=[np.mean(z6[i:i+12]) for i in range(192)]
    
    
    
######################time
   
    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(zz2, zz1)
    x=np.array(zz2)
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = slope*x_data+intercept
    plt.scatter(zz2,zz1)
    plt.plot(x_data,y_data,'r')
    zz3=slope*np.array(zz2)+intercept
    zz4=np.array(zz1)-np.array(zz3)
    
    print (rmse(zz1,zz3),pearsonr(y1,zz4))

####################

    import numpy as np
    from scipy.optimize import curve_fit
    def poly2d(x, a, b, c):
        return a + b*x + c*x**2 
    
    # initial data to fit
    
    x=zz2
    y=zz1
    # fit poly3d to x, y
    coefs_poly2d, _ = curve_fit(poly2d, x, y)
    
    # initialize some points
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = poly2d(x_data, *coefs_poly2d)
    # plot the points
    plt.plot(x, y, 'ro', x_data, y_data);
    
    zz3=poly2d(np.array(zz2),*coefs_poly2d)
    
    zz4=np.array(zz1)-np.array(zz3)
    print (rmse(zz1,zz3),pearsonr(y1,zz4))

######################
    import numpy as np
    from scipy.optimize import curve_fit
    def poly3d(x, a, b, c, d):
        return a + b*x + c*x**2 + d*x**3
    
    # initial data to fit
    
    x=zz2
    y=zz1
    # fit poly3d to x, y
    coefs_poly3d, _ = curve_fit(poly3d, x, y)
    
    # initialize some points
    x_data = np.linspace(min(x), max(x), 50)
    # transform x_data to y-axis values via poly3d
    y_data = poly3d(x_data, *coefs_poly3d)
    # plot the points
    plt.plot(x, y, 'ro', x_data, y_data);
    
    zz3=poly3d(np.array(zz2),*coefs_poly3d)
    
    zz4=np.array(zz1)-np.array(zz3)

    print (rmse(zz1,zz3),pearsonr(y1,zz4))
    
    
#########################space    
    x1x=[] 
    x2x=[]
    for i in range(204):
        zz2=psx[i]
        zz1=px[i]
        slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(zz2, zz1)
        # x=np.array(zz2)
        # x_data = np.linspace(min(x), max(x), 50)
        # # transform x_data to y-axis values via poly3d
        # y_data = slope*x_data+intercept
        # plt.scatter(zz2,zz1)
        # plt.plot(x_data,y_data,'r')
        zz3=slope*np.array(zz2)+intercept
        zz4=np.array(zz1)-np.array(zz3)
        x1x.append(pearsonr(wx1[i],zz4)[0])
        plt.plot(x1x)
##############   
        x=zz2
        y=zz1         
        coefs_poly2d, _ = curve_fit(poly2d, x, y)
         
        zz3=poly2d(np.array(zz2),*coefs_poly2d)
        
        zz4=np.array(zz1)-np.array(zz3)
        x2x.append(pearsonr(wx1[i],zz4)[0])


###########################
    pxps=[]
    for i in range(204):
        pxps.append(pearsonr(px[i],psx[i])[0])
         
    pearsonr(pxps,x2x)   
    
    pxwx=[]
    for i in range(204):
        pxwx.append(pearsonr(px[i],wx1[i])[0])

    x1=[]
    x2=[]
    x3=[]
    x4=[]
    for i in range(192):
        x1.append(np.mean(y1[i:i+12]))
        x2.append(np.mean(zz4[i:i+12]))
        x3.append(np.mean(zz1[i:i+12]))
        x4.append(np.mean(zz2[i:i+12]))

####################


    data=np.loadtxt(path+"t2m_sampen_era5.dat")
    x=np.reshape(data,(17,8040))
    y=[np.mean(x[i,:4020]) for i in range(17)]
    
    yy=[]
    for i in range(17):
        yy.append(np.mean(zz4[i*12:(i+1)*12]))









    
    yk1=np.reshape(y1,(17,12))
    yk2=np.reshape(y2,(17,12))
    zzk1=np.reshape(zz1,(17,12))
    zzk2=np.reshape(zz2,(17,12))
    zzk4=np.reshape(zz4,(17,12))
    
    for i in range(12):
        print (pearsonr(yk1[:,i],zzk4[:,i]))
    
    pearsonr(y1,y2)
    plt.scatter(y1,y2)
    
    
    
    


    wxx1=[]
    pxx1=[]
    wxx2=[]
    pxx2=[]
    for i in range(8040):
        for k in range(12):
           x1=[]
           x2=[]
           for j in range(17): 
               d=int(j*12+k)
               x1.append(wx1[d,i])
               x2.append(px[d,i])
           wxx1.append(np.mean(x1))
           pxx1.append(np.mean(x2))
           wxx2.append(np.std(x1))
           pxx2.append(np.std(x2))           
    wxx1=np.reshape(wxx1,(8040,12))
    pxx1=np.reshape(pxx1,(8040,12))    
    wxx2=np.reshape(wxx2,(8040,12))
    pxx2=np.reshape(pxx2,(8040,12))   


    wy1=[]
    py1=[]
    for i in range(8040):
        for j in range(17):
            for k in range(12):
                d=int(j*12+k)
                wy1.append((wx1[d,i]-wxx1[i,k])/wxx2[i,k])
                py1.append((px[d,i]-pxx1[i,k])/pxx2[i,k])
    wz1=np.reshape(wy1,(8040,204))
    pz1=np.reshape(py1,(8040,204))            
    
    z1=[np.mean(wz1[:4020,i]) for i in range(204)]
    z2=[np.mean(pz1[:4020,i]) for i in range(204)]



    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    data=np.loadtxt('/home/meng/awpsd/data/coldwave_3days.txt')
    c1x=data[nodes]
    pearsonr(x1,c1x)
    
    












