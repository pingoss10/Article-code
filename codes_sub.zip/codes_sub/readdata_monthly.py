#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 10:48:38 2021

@author: meng
"""

from netCDF4 import Dataset
import numpy as np

def anualave(x,n):
    x1=np.reshape(x,(n,12))
    x2=[np.mean(x1[:,i]) for i in range(12)]
    return x2
def anualstd(x,n):
    x1=np.reshape(x,(n,12))
    x2=[np.std(x1[:,i]) for i in range(12)]
    return x2


data1=Dataset('/home/meng/bak_bupt/newproj/data/ogl_era5_monthly.nc','r',format='NETCDF4')

nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')

lats=nodes[:,3]
lons=nodes[:,4]

ogl=data1.variables['ttr'][12:492,:,:]

outfile=open('/home/meng/bak_bupt/newproj/data/monthly_ogl_monthly.dat','w')
for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    x=ogl[:,i,j]
    y=anualstd(x, 40)
    z=anualave(x, 40)    
    for q in range(len(x)):
        q1=int(q/12)
        q2=q%12
        x1=(x[q]-y[q2])/z[q2]
        outfile.write('%.6f \n'%(x1))
        outfile.flush()
outfile.close()










path1='/home/meng/bupt_data/origin/'
path2='/home/meng/bupt_data/data/seaice/'

data1=Dataset(path1+'monthly_10mv_10mu_sst.nc','r',format='NETCDF4')
data2=Dataset(path1+'monthly_div_geo_u_v.nc','r',format='NETCDF4')
data3=Dataset(path1+'monthly_cloud_rh_vorticity.nc','r',format='NETCDF4')
data4=Dataset(path1+'monthly_surface_waveperiod.nc','r',format='NETCDF4')
data5=Dataset('/home/meng/bak_bupt/newproj/data/monthlywind_1980_2019.nc','r',format='NETCDF4')
data6=Dataset('/home/meng/bak_bupt/newproj/data/monthlywind500hpa_1980_2019.nc','r',format='NETCDF4')


nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')

lats=nodes[:,3]
lons=nodes[:,4]


v10m=data1.variables['v10'][:492,0,:,:]
u10m=data1.variables['u10'][:492,0,:,:]
sst=data1.variables['sst'][:492,0,:,:]
div=data2.variables['d'][:492,0,:,:]#850hpa
geo=data2.variables['z'][:492,0,:,:]#850hpa
u=data2.variables['u'][:492,0,:,:]#850hpa
v=data2.variables['v'][:492,0,:,:]#850hpa
u850=data5.variables['u'][:,1,:,:]
v850=data5.variables['v'][:,1,:,:]
u250=data5.variables['u'][:,0,:,:]
v250=data5.variables['v'][:,0,:,:]
u500=data6.variables['u'][:,:,:]
v500=data6.variables['v'][:,:,:]

vor=data3.variables['vo'][:492,0,:,:]#850hpa vorticity
cloud=data3.variables['cc'][:492,0,:,:]#850hpa fraction of cloud cover
rh=data3.variables['r'][:492,0,:,:]#850hpa relative humidity

tpre=data4.variables['tp'][:492,0,:,:]#surface total precipitation
cpre=data4.variables['cp'][:492,0,:,:]#surface convection precipitation
wave=data4.variables['mwp'][:492,0,:,:]#surface mean wave period
crain=data4.variables['crr'][:492,0,:,:]#surface convection rain rate



outfile1=open('/home/meng/bak_bupt/newproj/data/monthly_ori_wind500.nc','w')

for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    
for i in range(73):
    print (i)
    for j in range(144):
        #x1=u[:,i,j]
        x=u500[:,i,j]
        y=v500[:,i,j]
        z=np.sqrt(x*x+y*y)
           
        for q in range(len(x)):
            
            outfile1.write('%.6f %.6f %.6f \n'%(x[q],y[q],z[q]))
            outfile1.flush()
           
outfile1.close()




outfile1=open('/home/meng/bak_bupt/newproj/data/monthly_ori_wind850.nc','w')

for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    
for i in range(73):
    print (i)
    for j in range(144):
        #x1=u[:,i,j]
        x=u850[:,i,j]
        y=v850[:,i,j]
        z=np.sqrt(x*x+y*y)
           
        for q in range(len(x)):
            
            outfile1.write('%.6f %.6f %.6f \n'%(x[q],y[q],z[q]))
            outfile1.flush()
           
outfile1.close()



outfile=open(path2+'monthly_ano_cp.nc','w')
for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    x=cpre[:,i,j]
    y=anualave(x, 41)
    z=anualstd(x, 41)    
    for q in range(len(x)):
        q1=int(q/12)
        q2=q%12
        x1=(x[q]-y[q2])/z[q2]
        outfile.write('%.6f \n'%(x1))
        outfile.flush()
outfile.close()

outfile=open(path2+'monthly_ano_rh850.nc','w')
outfile1=open(path2+'monthly_ano_rh_oceannodes.dat','w')

for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    x=rh[:,i,j]
    y=anualave(x, 41)
    z=anualstd(x, 41)    
    if(min(z)!=0):

        for q in range(len(x)):
            q1=int(q/12)
            q2=q%12
            x1=(x[q]-y[q2])/z[q2]
            outfile.write('%.6f \n'%(x1))
            outfile.flush()
        outfile1.write('%d \n'%(k))
        outfile1.flush()
outfile.close()
outfile1.close()


xx=[]
outfile=open('/home/meng/bak_bupt/newproj/data/monthly_ano_wind250.nc','w')
outfile1=open('/home/meng/bak_bupt/newproj/data/monthly_ori_wind250.nc','w')

for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    x1=u250[:,i,j]
    x2=v250[:,i,j]
    x=[x1[i]*x1[i]+x2[i]*x2[i] for i in range(len(x1))]
    y=anualave(x, 40)
    z=anualstd(x, 40)    
    for q in range(len(x)):
        q1=int(q/12)
        q2=q%12
        x1=(x[q]-y[q2])/z[q2]
        outfile.write('%.6f \n'%(x1))
        outfile.flush()
        outfile1.write('%.6f \n'%(x[q]))
        outfile1.flush()
outfile.close()
outfile1.close()




    
xx=[]
outfile=open('/home/meng/bak_bupt/newproj/data/monthly_ano_Uwind250.nc','w')
outfile1=open('/home/meng/bak_bupt/newproj/data/monthly_ori_Uwind250.nc','w')

for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    #x1=u[:,i,j]
    x=u250[:,i,j]
    #x=abs(x2)
    y=anualave(x, 40)
    z=anualstd(x, 40)    
    for q in range(len(x)):
        q1=int(q/12)
        q2=q%12
        x1=(x[q]-y[q2])/z[q2]
        outfile1.write('%.6f \n'%(x[q]))
        outfile1.flush()
        outfile.write('%.6f \n'%(x1))
        outfile.flush()
outfile.close()
outfile1.close()

xx=[]
#outfile=open('/home/meng/bak_bupt/newproj/data/monthly_ano_Vwind250_10512.nc','w')
outfile1=open('/home/meng/bak_bupt/newproj/data/monthly_ori_wind250_10512.nc','w')

for i in range(73):
    for j in range(144):
        x=u250[:,i,j]
        #x=abs(x2)
        y=v250[:,i,j]
        y=anualave(x, 40)
        z=anualstd(x, 40)    
        for q in range(len(x)):
        
            outfile1.write('%.6f %.6f \n'%(x[q],y[q]))
            outfile1.flush()
#outfile.close()
outfile1.close()


    

outfile=open(path2+'monthly_sst_ori.nc','w')
outfile1=open(path2+'monthly_sst_ori_oceannodes.dat','w')

for k in range(len(nodes)):
    print (k)
    i=int(lats[k])
    j=int(lons[k])
    x=sst[:,i,j]
    y=anualstd(x, 41)
    z=anualave(abs(x), 41)    
    if(min(z)!=0):

        for q in range(len(x)):
            q1=int(q/12)
            q2=q%12
            x1=(x[q]-y[q2])/z[q2]
            outfile.write('%.6f \n'%(x[q]))
            outfile.flush()
        outfile1.write('%d \n'%(k))
        outfile1.flush()
outfile.close()
outfile1.close()    
# =============================================================================
# def scattermap_global():
#     data=Dataset('/home/meng/CLUSTER_DATA/orgindata/ERA5850/1990.nc','r',format='NETCDF4')
#     lats=data.variables['latitude'][:]
#     lons=data.variables['longitude'][:]
#     outfile=open('/home/jingfang/CLUSTER_DATA/CODE/Python/arctic/DATA/regridcos2.5d_global.dat','w')
#     nodes=0
#     for i in range(0,73,1):
#         lat=lats[i]
#         #if(-40<lat<40):
#         a=np.cos(lat*np.pi/180.)
#         if(a==0):
#             b=1
#         else:
#             b=int(1/a)
#         y=np.arange(0,144,1*b)
#         for j in y:
#             lon=lons[j]
#             n=i*144+j
#             nodes+=1
#             outfile.write('%d %.6f %.6f %d %d \n'%(n,lat,lon,i,j))
#             outfile.flush()
#     outfile.close()
# =============================================================================
