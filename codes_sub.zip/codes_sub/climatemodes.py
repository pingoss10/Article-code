#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 08:51:52 2024

@author: meng
"""
import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde
from scipy.signal import detrend
import matplotlib as mpl
import scipy
import glob
import seaborn as sns
from numpy import pi, e
def sf(x):
    fx=np.fft.fft(x)
    phx=np.angle(fx)
    np.random.shuffle(phx)
    fy=np.abs(fx)*e**(1j*phx)
    y=np.fft.ifft(fy)
    z=np.real(y) 
    return z

def readIOD():
    import json
    path='/home/meng/awpsd/data/'
    file = open("/home/meng/awpsd/data/IOD.txt")
    data = json.load(file) 
    
    x_values = [float(item["x"]) for item in data["items"]]
    y_values = [float(item["y"]) for item in data["items"]]
    outfile=open('/home/meng/awpsd/data/iod.dat','w')
    for i in range(len(x_values)):
        outfile.write('%.6f %.6f \n'%(x_values[i],y_values[i]))
        outfile.flush()
    outfile.close()
    
    
    iop=np.loadtxt('/home/meng/awpsd/data/iod.dat')
    outfile=open('/home/meng/awpsd/data/iod_monthly.dat','w')
    iopx=[]
    for year in range(1993,2024):
        for month in range(1,13):
            date=year+month/12.
            datee=date-1/12.
            lists=np.where(iop[:,0]>datee)[0]
            lists=[int(i) for i in lists]
            list1=np.where(iop[:,0][lists]<=date)[0]
            list2=np.array(lists)[list1]
            iopx.append(np.mean(iop[:,1][list2]))
            outfile.write('%.6f %.6f \n'%(year+(month-1)/12.,np.mean(iop[:,1][list2])))
            outfile.flush()
    outfile.close()


def correlation():
    wacf=np.loadtxt(path+"t2m_ext_era5_ori_monthly1_1980.dat")
    wacfx=np.reshape(wacf[:,1],(528,8040))
    iod=np.loadtxt('/home/meng/awpsd/data/iod_monthly.dat')
    iopx=iod[:,1]
    outfile=open(path+'iop_wac.dat','w')
    for i in range(8040):
        r,p=pearsonr(wacfx[156:,i],iopx)
        outfile.write('%.6f %.6f \n'%(r,p))
        outfile.flush()
    outfile.close()
    
    data=np.loadtxt(path+'iop_wac.dat')
    rx=data[:,0]
    px=data[:,1]
    
    taux=24
    outfile=open(path+'iop_wac_tau24.dat','w')
    for i in range(8040):
        xx=[]
        yy=[]
        for tau in range(-taux,taux+1):
            x=wacfx[156+taux+tau:528-taux+tau,i]
            y=iopx[taux:len(iopx)-taux]
            r,p=pearsonr(x,y)
            xx.append(r)
            yy.append(p)
        a=np.max(xx)
        b=np.min(xx)
        if(abs(a)>abs(b)):
            c=a
        else:
            c=b
        d=np.where(np.array(xx)==c)[0]
        d=d[0]
        e=yy[d]
        outfile.write('%.6f %d %.6f \n'%(c,d-tau,e))
        outfile.flush()
    outfile.close()
    
    data=np.loadtxt(path+'iod_wac_tau24.dat')
    rx=data[:,0]
    tx=data[:,1]
    px=data[:,2]
    xx=np.where(px<0.05)[0]
    plt.hist(tx)
    
    outfile=open(path+'iod_wac_tau24_s.dat','w')
    for i in range(8040):   
        print (i)
        sx=[]
        for st in range(100):
            x=sf(wacfx[156:,i])
            y=iopx
            xx=[]
            for tau in range(-taux,taux):
                x1=x[taux+tau:len(iopx)-taux+tau]
                x2=y[taux:len(iopx)-taux]               
                r,p=pearsonr(x1,x2)
                xx.append(r)
            xx=np.array(xx)
            a=np.max(abs(xx))             
            sx.append(a)
        a1=np.percentile(sx, 95)
        outfile.write('%.6f \n'%(a1))
        outfile.flush()
    outfile.close()
    
    data=np.loadtxt(path+'iod_wac_tau24_s.dat')
    rx=data[:,0]
    tx=data[:,1]
    px=data[:,2]
    xx=np.where(px<0.05)[0]
    plt.hist(tx)
def plot_maps():
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
   
    data=np.loadtxt('/home/meng/awpsd/data/iod_wac_tau24.dat')
    rx=data[:,0]
    datas=np.loadtxt('/home/meng/awpsd/data/iod_wac_tau24_s.dat')
    
    ax=plt.plot()
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,15.),labels=[True,True,True,True],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,60.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)
    
        #lats1=np.array(lats1)
        #lons1=np.array(lons1)
    color=rx
    m.scatter(x,y,200,marker='o',c=color,cmap='vlag',vmin=-0.3,vmax=0.3)
#    m.scatter(x,y,200,marker='o',c=color,cmap='bwr_r')          
    cb=plt.colorbar(fraction=0.025,pad=0.06,extend='both')
    # cb.set_label(label='Correlation', size=34, weight='bold')
    # cb.ax.tick_params(labelsize=34)
    # a=abs(min(color))
    # b=abs(max(color))
    # c=max(a,b) 
    # c=0.3
    # plt.clim(-c,c)
    
    custom_ticks = [-0.3, -0.15, 0, 0.15, 0.3]  # Define the specific values you want
    cb.set_ticks(custom_ticks)
    cb.set_ticklabels([f"{tick:.2f}" for tick in custom_ticks])  # Format tick labels
    
    # Set colorbar label and display
    cb.set_label('Correlation', size=34, weight='bold')
    cb.ax.tick_params(labelsize=34)
    signodes=[nodes[i] for i in range(len(nodes)) if (abs(data[:,0][i])>datas[i])]
    print (len(signodes))
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)
    
        #lats1=np.array(lats1)
        #lons1=np.array(lons1)
    m.scatter(x,y,200,marker='x',c='k')
       # ax.colorbar(im, fraction=0.046, pad=0.04)  
        #plt.colorbar() 
    plt.title('$IOD$',fontsize=34) #annual
      
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(30, 12)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/IOD_WACF.png")           

    
    
    
    
    
    
    
    
    
    