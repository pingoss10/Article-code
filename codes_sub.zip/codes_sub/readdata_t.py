#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 20:53:57 2020

@author: jingfang
"""

#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 18:25:46 2020

@author: jingfang
"""
from netCDF4 import Dataset
import numpy as np
np.bool = np.bool_

path='/home/meng/CLUSTER_DATA/'
path='/p/tmp/jingfang/'

def storm():
  data = Dataset('/home/meng/bak_bupt/newproj/data/IBTrACS.since1980.v04r00.nc','r',format='NETCDF4')  
  wtype=data.variables['td9636_stage'][:]
def readdatat850ano_g():
    path='/home/meng/bak_bupt/newproj/data/'
    nodes=np.loadtxt(path+'regridcos2.5d_global.dat')  
    
    data = Dataset(path+"temperature_850hPa.nc",'r',format='NETCDF4')
    air_data=data.variables['t'][:]
    outfile=open(path+'era5t85025d_ano_1979to2019_g_new.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  

def readdataice():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos1d.dat')  
    air_data=[]
    for year in range(1996,2007):
        print (year)
        data = Dataset(path+"orgindata/seaice/ERA5_ice_"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['siconc'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5ice1d_ori_1996to2006.ano','w')             
    for k in range(len(nodes)):
        print (k)
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        for year in range(1996,2007):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_ice_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['siconc'][:,i,j]
            ice=air_data[year-1996][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for l in ice:
                outfile.write('%.6f \n'%(l))
                outfile.flush()
    outfile.close()
#readdataice()

def readdataiceano():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2d.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        yn+=1
        data = Dataset(path+"orgindata/seaice/ERA5_ice_"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['siconc'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5ice2d_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
               
        
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                if(np.std(mm[:,day])==0):
                    t=0
                else:
                    t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()
    
            
    outfile.close()   

def nozeroicenodes():
    path='/p/tmp/jingfang/'

    regrid=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos7.5d_global.dat')
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/newnodes_icedata75.dat')
    #nodes=np.loadtxt('/home/meng/bupt_data/data/seaice/newnodes_icedata.dat')
    x=np.zeros(1788)
    for year in range(1979,2020):
        print (year)
        data = Dataset(path+"orgindata/seaice/ERA5_ice_"+str(year)+".nc",'r',format='NETCDF4')
        #air_data.append(data.variables['siconc'][:])
        lats=data.variables['latitude'][:]
        lons=data.variables['longitude'][:]
        #icec=data.variables['siconc'][:]
        for l in range(len(nodes)):
        
            i=int(nodes[:,0][l])
            j=int(nodes[:,1][l])
            k=data.variables['siconc'][:,i,j]
            if(sum(k)>0):
                x[l]+=1
            else:
                print (l,i,j,x[l])
    outfile=open(path+'CODE/Python/arctic/DATA/nonzeroicenodes75.dat','w')
    for i in range(1788):
        if(x[i]>0):
            a=regrid[:,0][i]
            b=regrid[:,1][i]
            c=regrid[:,2][i]
            d=regrid[:,3][i]
            e=regrid[:,4][i]
            f=nodes[:,0][i]
            g=nodes[:,1][i]
            k=x[i]
            outfile.write('%d %.1f %.1f %d %d %d %d %d\n'%(a,b,c,d,e,f,g,k))
            outfile.flush()
    outfile.close()




           # print (x[l])        
                    
#=============================================================================
        #outfile=open('/home/meng/bupt_data/data/seaice/newnodes.dat','w')
        #n=0

# =============================================================================
#         jx=[]
#         outfile=open('/home/meng/bupt_data/data/seaice/newnodes_icedata.dat','w')
#         for i in range(8040):
#             a=regrid[:,0][i]
#             b=regrid[:,1][i]
#             c=regrid[:,2][i]
#             d=regrid[:,3][i]
#             e=regrid[:,4][i]
#             if(c>=180):
#                 c=c-360.
#             if(b in lats and c in lons):
#                 #n+=1
#                 lats=list(lats)
#                 lons=list(lons)
#                 bb=lats.index(b)
#                 cc=lons.index(c)
#                 ix.append(bb)
#                 jx.append(cc)
#                 outfile.write('%d %d \n'%(bb,cc))
#                 outfile.flush()
#         outfile.close()
# =============================================================================
                #outfile.write('%d %.1f %.1f %d %d \n'%(a,b,c,d,e))
                #outfile.flush()
        #outfile.close()

#=============================================================================
                    
        




def readdataiceano25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/nonzeroicenodes75.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/seaice/ERA5_ice_"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['siconc'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5ice7.5d_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,0][k])
        j=int(nodes[:,1][k])
               
        
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                if(np.std(mm[:,day])==0):
                    t=0
                else:
                    t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()
    
            
    outfile.close()   

def readdatat850ano():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2d.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2021):
        yn+=1
        data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t8502d_ano_1979to2020.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2021):
            year=int(year)
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2021):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()
    
            
    outfile.close() 




def readdatat850ano_g():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t8505d_ano_1979to2019_g.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  



def readdatat850ano_g75():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos7.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t85075d_ano_1979to2019_g.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  





def readdatat850ano_a_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_arctic.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2021):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t8502.5d_ano_1979to2020.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2021):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat850ano_10512():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_arctic.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2021):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t8502.5d_ano_1979to2019_10512.ano','w')             
    for i in range(73):
        for j in range(144):
            mm=np.zeros(shape=(yn,365))
            for year in range(1979,2020):
                year=int(year)
               # print (year)
                #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
                #ice=data.variables['t'][:,i,j]
                ice=air_data[year-1979][:,i,j]
                if(year%4==0 and year%100!=0) or (year%400==0):
                    ice=np.delete(ice,59)
                mm[year-1979]=ice
            for year in range(1979,2020):
                for day in range(365):
                    t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                    outfile.write('%.6f \n'%(t))
                    outfile.flush()                
    outfile.close()  

def readdatat850ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2021):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/"+str(year)+".nc",'r',format='NETCDF4')
        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t8502.5g_ano_1979to2020.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2021):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2021):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
    
def readdatat200ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t200_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t2002.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()

def readdatat550ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t550_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t5502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()


def readdatat1000ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t1000_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t10002.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()


def readdatat750ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t750_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t7502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()


def readdatat900ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t900_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t9002.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()

def readdatat950ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t950_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t9502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()
 

def readdatat700ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t700_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t7002.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close() 
def readdatat100ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t100_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t1002.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()    
def readdatat150ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t150_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t1502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat250ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t250_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t2502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat300ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t300_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t3002.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat350ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t350_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t3502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat450ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t450_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t4502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat650ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t650_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t6502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat50ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t50_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t502.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
def readdatat1ano_g_25():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t1_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t12.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
    
def readdatat850ano_g_75():
    nodes=np.loadtxt(path+'CODE/Python/arctic/DATA/regridcos2.5d_global.dat')  
    air_data=[]
    yn=0
    for year in range(1979,2020):
        print (year)
        yn+=1
        data = Dataset(path+"orgindata/ERA5850/t1_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'CODE/Python/arctic/DATA/era5t12.5g_ano_1979to2019.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2020):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1979]=ice
        for year in range(1979,2020):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()  
    
def readdata_t2m_ano():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1994,2024):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_ano_2007to2023.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1994,2024):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1994][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for p in range(len(ice)):
                mm[year-1994][p]=ice[p]
        for year in range(2007,2024):
            for day in range(365):
                t=(mm[year-1994,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close() 

def readdata_t2m_ano1979():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1979,2025):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_ano_1979.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2025):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for p in range(len(ice)):
                mm[year-1979][p]=ice[p]
        for year in range(1979,2025):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close() 

     
def readdata_t2m_ori():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(2006,2025):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_ori_2006to2024.ano','w')             
    for k in range(len(nodes)):
        print (k)
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        for year in range(2006,2025):
            year=int(year)
            
            ice=air_data[year-2006][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for day in range(len(ice)):
                t=ice[day]
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()      
 
def readdata_t2m_ori1979():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1979,2025):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_ori_1979.ano','w')             
    for k in range(len(nodes)):
        print (k)
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        for year in range(1979,2025):
            year=int(year)
            
            ice=air_data[year-1979][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for day in range(len(ice)):
                t=ice[day]
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()      
     
def readdata_t850_ori1979():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1979,2025):
        print (year)
        yn+=1
        data = Dataset("/home/meng/awpsd/data/origin/t850_era5_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'era5t850h2.5g_ori_1979.ano','w')             
    for k in range(len(nodes)):
        print (k)
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        for year in range(1979,2025):
            year=int(year)
            
            ice=air_data[year-1979][:,0,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for day in range(len(ice)):
                t=ice[day]
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close()   

def readdata_t850_ano1979():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1979,2025):
        print (year)
        yn+=1
        data = Dataset("/home/meng/awpsd/data/origin/t850_era5_"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t'][:])
    outfile=open(path+'era5t850h2.5g_ano_1979.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1979,2025):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1979][:,0,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for p in range(len(ice)):
                mm[year-1979][p]=ice[p]
        for year in range(1979,2025):
            for day in range(365):
                t=(mm[year-1979,day]-np.mean(mm[:,day]))/np.std(mm[:,day])
                outfile.write('%.6f \n'%(t))
                outfile.flush()                
    outfile.close() 


    
def readdata_t2m_climateo():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1994,2024):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_climate.ano','w')             
    for k in range(len(nodes)):
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1994,2024):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1994][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            mm[year-1994]=ice
        
        for day in range(365):
            outfile.write('%.6f %.6f \n'%(np.mean(mm[:,day]),np.std(mm[:,day])))
            outfile.flush()                
    outfile.close()    
def readdata_t2m_ext():
    path='/home/meng/awpsd/data/'
    nodes=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    air_data=[]
    yn=0
    for year in range(1994,2025):
        print (year)
        yn+=1
        data = Dataset(path+"origin/ERA5_t2m_0hour/"+str(year)+".nc",'r',format='NETCDF4')

        air_data.append(data.variables['t2m'][:])
    outfile=open(path+'era5t2m2.5g_3std_2007to2023.ano','w')             
    for k in range(len(nodes)):
        print (k)
        i=int(nodes[:,3][k])
        j=int(nodes[:,4][k])
        mm=np.zeros(shape=(yn,365))
        for year in range(1994,2024):
            year=int(year)
           # print (year)
            #data = Dataset(path+"orgindata/seaice/ERA5_850hp_"+str(year)+".nc",'r',format='NETCDF4')
            #ice=data.variables['t'][:,i,j]
            ice=air_data[year-1994][:,i,j]
            if(year%4==0 and year%100!=0) or (year%400==0):
                ice=np.delete(ice,59)
            for p in range(len(ice)):
                mm[year-1994][p]=ice[p]
        for year in range(2006,2024):
            for day in range(365):
                t=(mm[year-1994,day]-np.mean(mm[:,day]))
               # print (t,np.std(mm[:,day]))
                if(np.abs(t)>np.std(mm[:,day])):
                    tn=1
                else:
                    tn=0
                outfile.write('%d \n'%(tn))
                outfile.flush()                
    outfile.close()  
if __name__ == "__main__":    
#    readdataiceano()
#    readdataiceano25()
#    readdatat850ano()
#    readdatat850ano_g()
#    readdatat850ano_a_25()
#    readdatat850ano_g_25()
#     readdatat200ano_g_25()
#     readdatat1000ano_g_25()
#     readdatat550ano_g_25()
#    readdatat750ano_g_25()
#    readdatat900ano_g_25()
#    readdatat950ano_g_25()
#    readdatat700ano_g_25()
#    readdatat100ano_g_25()    
#    readdatat150ano_g_25()
#    readdatat250ano_g_25()
#    readdatat300ano_g_25()
#    readdatat350ano_g_25()
#    readdatat450ano_g_25()
#     readdatat650ano_g_25()
#     readdatat50ano_g_25()
#     readdatat650ano_g_25()
#    nozeroicenodes()  
#    readdatat850ano_g_25()
#    readdatat850ano_10512()
#    readdatat850ano_g75()
#    readdataiceano25()
    readdata_t850_ano1979()