#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 13:32:37 2024

@author: meng
"""

import nolds
from scipy.interpolate import griddata
from netCDF4 import Dataset

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
from numpy import pi, e
from netCDF4 import Dataset
import numpy as np
np.bool = np.bool_

def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,tau+1):
        x1=x[tau:l+tau]
        x2=x[tau+t:l+t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    w=(1-np.mean(z))/np.std(z)
    return z
def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def autowc(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)*1/np.sqrt(2*tau)
    return a


def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def awps(x,s1,l):
    n=round(l/2)
    lx=np.arange(n)
    t0=np.abs(np.fft.fft(x[s1:s1+l]))
    ta=sum(lx*t0[:n])/sum(t0[1:n])
    return ta/n

def white_noise(N,b):
    yx1=[]
    yx2=[]
    yx3=[]
    yx4=[]
    zx1=[]
    zx2=[]
    zx3=[]
    zx4=[]
    y=np.random.uniform(-b,b,N)#white noise
    fx=np.fft.fft(y)
    phx=np.angle(fx)
    fy=np.abs(fx)*e**(1j*phx)
    z=np.fft.ifft(fy)
        
    nz=sum(np.abs(fx))/len(fx)
    fw=np.ones(len(fx))*nz
        
    fyy=fw*e**(1j*phx)
    zz=np.fft.ifft(fyy)
        
    zx=np.real(z)#white noise
    zy=np.real(zz)#white noise with uniform power spectrum
    
    return z,zz
def function_ex():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ano_2007to2023.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6935))
    stdx=[np.std(T[i]) for i in range(8040)]
    meanx=[np.mean(T[i]) for i in range(8040)]
    outfile=open(path+"t2m_extreme_era5_monthly.dat",'w')
    for year in range(2007,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):
                
                s=(year-2006)*365+monthd[m]
                        
                x=T[i,s:s+months[m]]
                y=np.abs(np.array(x)-meanx[i])
                z=np.where(np.array(y)>3*stdx[i])[0]
                outfile.write('%.6f \n'%(len(z)/months[m]))
                outfile.flush()      
    outfile.close()

def function_ex():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ano_2007to2023.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6935))
    stdx=[np.std(T[i]) for i in range(8040)]
    meanx=[np.mean(T[i]) for i in range(8040)]
    outfile=open(path+"t2m_extreme_change_era5_monthly.dat",'w')
    for year in range(2007,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):
                
                s=(year-2006)*365+monthd[m]
                        
                x=T[i,s:s+months[m]]
                y=np.abs(np.array(x)-meanx[i])
                z=np.where(np.array(y)>3*stdx[i])[0]
                outfile.write('%.6f \n'%(len(z)/months[m]))
                outfile.flush()      
    outfile.close()
                
























                