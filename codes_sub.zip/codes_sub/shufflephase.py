#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 11:05:06 2024

@author: meng
"""

from numpy import pi, e
from scipy.stats.stats import pearsonr
import numpy as np


#input is x, output is z
fx=np.fft.fft(x)
phx=np.angle(fx)
np.random.shuffle(phx)
fy=np.abs(fx)*e**(1j*phx)
y=np.fft.ifft(fy)
z=np.real(y) 