#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 10:44:19 2024

@author: meng
"""


import numpy as np
from scipy import stats
import xarray as xr




d = xr.open_dataset('/home/meng/awpsd/data/origin/t2m_forecast5d_ecwmf_2007', engine = 'cfgrib')

xx=d['t2m'].values