#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 10 19:07:01 2025

@author: meng
"""
from itertools import combinations
from math import log
import nolds

def construct_templates(timeseries_data: list, m: int = 2):
    num_windows = len(timeseries_data) - m + 1
    return [timeseries_data[x : x + m] for x in range(0, num_windows)]


def get_matches(templates: list, r: float):
    return len(
        list(filter(lambda x: is_match(x[0], x[1], r), combinations(templates, 2)))
    )


def is_match(template_1: list, template_2: list, r: float):
    return all([abs(x - y) < r for (x, y) in zip(template_1, template_2)])


def sample_entropy(timeseries_data: list, window_size: int, r: float):
    B = get_matches(construct_templates(timeseries_data, window_size), r)
    A = get_matches(construct_templates(timeseries_data, window_size + 1), r)
    return -log(A / B)

def hurst_rs(price_series):
    """
    Calculates the Hurst Exponent using the Rescaled Range (R/S) analysis method.
    """
    # Compute log returns
    log_returns = np.diff(np.log(price_series))
    
    # Create an array of lag values
    lags = range(2, 100)
    
    # Calculate the array of the variances of the lagged differences
    tau = [np.sqrt(np.std(np.subtract(log_returns[lag:], log_returns[:-lag]))) for lag in lags]
    
    # Use a linear fit to estimate the Hurst Exponent
    poly = np.polyfit(np.log(lags), np.log(tau), 1)
    
    # The Hurst exponent is the slope of the linear fit
    hurst_exponent = poly[0]*2.0
    
    # The fractal dimension is related to the Hurst exponent
    fractal_dimension = 2 - hurst_exponent
    
    return hurst_exponent, fractal_dimension


def function_sampen_y():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_2007to2023.ano')
    tau=10
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6205))
  
    outfile=open(path+"t2m_sampen_era5_m5.dat",'w')
    for year in range(2007,2023):
        print (year)
        for month in range(12):
            print (month)
            s=(year-2007)*365+monthd[month]
            for i in range(8040):  
               # print (i)             
                x=T[i][s:s+365]
                s1=sample_entropy(x, 5, 0.2*np.std(x))
                #s2=nolds.sampen(x)
                outfile.write('%.6f \n'%(s1))
                outfile.flush()      
    outfile.close()

def function_wac_y():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_2007to2023.ano')
    tau=10
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6205))
  
    outfile=open(path+"t2m_autowc10d_era5_yearly.dat",'w')
    for year in range(2007,2024):
        print (year)
        s=(year-2007)*365
        for i in range(8040):
            x=T[i][s+tau:s+365-tau]
            w=autowc(x,tau,len(x)-2*tau)
            outfile.write('%.6f \n'%(w))
            outfile.flush()      
    outfile.close()

def function_hurst_y():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_2007to2023.ano')
    tau=10
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6205))
  
    outfile=open(path+"t2m_hurst_era5.dat",'w')
    for year in range(2007,2023):
        print (year)
        for month in range(12):
            print (month)
            s=(year-2007)*365+monthd[month]
            for i in range(8040):  
               # print (i)             
                x=T[i][s:s+365]
                #s1=sample_entropy(x, 5, 0.2*np.std(x))
                s1,s2=hurst_rs(x)
                outfile.write('%.6f %.6f \n'%(s1,s2))
                outfile.flush()      
    outfile.close()




import numpy as np
from scipy.linalg import eigh  # For eigen decomposition

# =============================================================================
# def EOF_analysis_with_entropy(data):
#     # Step 1: Remove the mean from each row (detrending)
#     data_mean = np.mean(data, axis=1, keepdims=True)
#     data_anomaly = data - data_mean
# 
#     # Step 2: Compute the covariance matrix
#     cov_matrix = np.cov(data_anomaly)
# 
#     # Step 3: Perform eigen decomposition
#     eigenvalues, eigenvectors = eigh(cov_matrix)
# 
#     # Step 4: Sort eigenvalues and corresponding eigenvectors in descending order
#     sorted_idx = np.argsort(eigenvalues)[::-1]
#     eigenvalues = eigenvalues[sorted_idx]
#     eigenvectors = eigenvectors[:, sorted_idx]
# 
#     # Step 5: Get the EOFs (spatial patterns) and PCs (time series)
#     EOFs = eigenvectors  # EOF spatial patterns
#     PCs = np.dot(EOFs.T, data_anomaly)  # PCs (time series associated with each EOF)
# 
#     # Step 6: Calculate entropy based on normalized eigenvalues
#     # Normalize eigenvalues to sum to 1 (like a probability distribution)
#     eigenvalues_norm = eigenvalues / np.sum(eigenvalues)
#     entropy = -np.sum(eigenvalues_norm * np.log(eigenvalues_norm + 1e-12))  # Add small value to avoid log(0)
# 
#     return EOFs, PCs, entropy, eigenvalues
# 
# =============================================================================
    
import math

def haversine(lon1, lat1, lon2, lat2):
    # 将经纬度从度转换为弧度
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])
    
    # Haversine 公式
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # 地球半径 (单位：公里)
    R = 6371.0
    distance = R * c
    return distance
import numpy as np

def EOF_analysis(data):
    """
    Perform EOF (Empirical Orthogonal Function) analysis on the input data using Singular Value Decomposition (SVD).
    
    Parameters:
    - data: 2D numpy array with shape (M, N), where M is the number of time steps and N is the number of spatial locations.
    
    Returns:
    - EOFs: Spatial patterns (EOFs) as a 2D array of shape (N, min(M, N)).
    - PCs: Temporal patterns (PCs) as a 2D array of shape (M, min(M, N)).
    - eigenvalues: Approximated eigenvalues representing the variance explained by each mode.
    - entropy: Entropy based on the distribution of eigenvalues.
    """
    # Step 1: Remove the mean from each spatial location (detrending)
    data_mean = np.mean(data, axis=0, keepdims=True)
    data_anomaly = data - data_mean

    # Step 2: Perform SVD on the data anomaly
    U, S, Vt = np.linalg.svd(data_anomaly, full_matrices=False)

    # Step 3: Extract EOFs and PCs
    EOFs = Vt.T  # EOFs as spatial patterns, shape (N, min(M, N))
    PCs = U      # PCs as temporal patterns, shape (M, min(M, N))

    # Step 4: Calculate eigenvalues (variance explained by each mode)
    eigenvalues = S**2 / (data.shape[0] - 1)  # Normalizing to resemble covariance-based eigenvalues

    # Step 5: Calculate entropy based on normalized eigenvalues
    eigenvalues_norm = eigenvalues / np.sum(eigenvalues)  # Normalize eigenvalues to sum to 1
    entropy = -np.sum(eigenvalues_norm * np.log(eigenvalues_norm + 1e-12))  # Small value to avoid log(0)

    return EOFs, PCs,  entropy,eigenvalues

import numpy as np

def EOF_analysis_with_entropy(data):
    # Step 1: Detrend the data by removing the mean from each row
    data_mean = np.mean(data, axis=1, keepdims=True)
    data_anomaly = data - data_mean

    # Step 2: Calculate the covariance matrix
    cov_matrix = np.cov(data_anomaly)

    # Step 3: Perform eigen decomposition of the covariance matrix
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)

    # Step 4: Sort eigenvalues and eigenvectors in descending order
    sorted_indices = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[sorted_indices]
    eigenvectors = eigenvectors[:, sorted_indices]

    # Step 5: Get EOFs (spatial patterns) and PCs (principal components)
    EOFs = eigenvectors  # EOFs are the eigenvectors of the covariance matrix
    PCs = np.dot(EOFs.T, data_anomaly)  # PCs are the projections of the data onto the EOFs

    # Step 6: Calculate entropy based on normalized eigenvalues
    # Normalize eigenvalues to sum to 1
    eigenvalues_norm = eigenvalues / np.sum(eigenvalues)
    entropy = -np.sum(eigenvalues_norm * np.log(eigenvalues_norm + 1e-12))  # Small value to avoid log(0)

    return EOFs, PCs, eigenvalues, entropy
def function_eof():    
    # Print the entropy
   # print("Entropy based on EOF:", entropy)

    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_1979.ano')
    tau=10
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16715))
  
    outfile=open(path+"eofentropy_southx.dat",'w')
    for year in range(1980,2024):
        print (year)
        for month in range(12):
            print (month)
            s=(year-1979)*365+monthd[month]
            data=T[4020:,s:s+months[month]]
            data=data.T
            EOFs, PCs, entropy, eigenvalues = EOF_analysis(data)
            outfile.write('%.6f \n'%(entropy))
            outfile.flush()      
    outfile.close()
    
def plot_eofnvsw():    
    path='/home/meng/awpsd/data/'
    entnor=np.loadtxt(path+"eofentropy_northx.dat")
    entsou=np.loadtxt(path+"eofentropy_southx.dat")
    
    wacf=np.loadtxt(path+"t2m_autowc10d_era5_monthly_1980.dat")
    
    wacfx=np.reshape(wacf,(528,8040))
    
    wacfn=[np.mean(wacfx[i,:4020]) for i in range(528)]
    wacfs=[np.mean(wacfx[i,4020:]) for i in range(528)]
    
    wnx=[np.mean(wacfn[i-12:i]) for i in range(12,528)]
    wsx=[np.mean(wacfs[i-12:i]) for i in range(12,528)]
    enx=[np.mean(entnor[i-12:i]) for i in range(12,528)]
    esx=[np.mean(entsou[i-12:i]) for i in range(12,528)]
    
    wnx=np.array(wnx)
    wsx=np.array(wsx)
    enx=np.array(enx)
    esx=np.array(esx)


    import matplotlib.pyplot as plt
    
   # fig = plt.figure(figsize=(10, 6))
    
    # 左上大图（2x2）
    ax1 = plt.subplot2grid((7, 13), (0, 0), rowspan=3, colspan=6)
    ax11 = ax1.twinx()
    
    # 右上图（2行1列）
    ax2 = plt.subplot2grid((7, 13), (0, 7), rowspan=3, colspan=3,sharey=ax11)
    
    # 下方大图（2行3列）
    ax3 = plt.subplot2grid((7, 13), (4, 0), rowspan=3, colspan=6)
    ax33 = ax3.twinx()
    
    # 中间右上角小图（不会和 ax1 冲突）
    ax4 = plt.subplot2grid((7, 13), (4, 7), rowspan=3, colspan=3,sharey=ax33)
    
    # plt.tight_layout()
    # plt.show()


    wy=np.array(wnx)
    cy=np.array(enx)
    xmajorLocator = MultipleLocator(12) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.004) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.3f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax1.xaxis.set_major_locator(xmajorLocator)
    ax1.xaxis.set_major_formatter(xmajorFormatter)
    ax1.yaxis.set_major_locator(ymajorLocator)
    ax1.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.002) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax1.xaxis.set_minor_locator(xminorLocator)
    ax1.yaxis.set_minor_locator(yminorLocator) 
    ax1.tick_params(which='both', width=1.2, labelsize=32)
    ax1.tick_params(which='major', length=12)  
    ax1.tick_params(which='minor',length=6)    
    
    
    
    #修改次刻度
    ymajorLocator = MultipleLocator(0.04) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式    
    yminorLocator = MultipleLocator(0.02) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax11.yaxis.set_major_locator(ymajorLocator)
    ax11.yaxis.set_major_formatter(ymajorFormatter)
    ax11.xaxis.set_minor_locator(xminorLocator)
    ax11.yaxis.set_minor_locator(yminorLocator) 
    ax11.tick_params(which='both', width=1.2, labelsize=32)
    ax11.tick_params(which='major', length=12)  
    ax11.tick_params(which='minor',length=6)  
      

    dates=np.arange(516)/12.+1981
    
    # 副轴：右侧 y 轴
    ax1.plot(dates, wnx, color='firebrick',linewidth=3, label='$W_{ACF}$')
    ax11.plot(dates, enx, color='#d8a6a6',linewidth=3, label='Entropy')
    ax11.set_ylim(2.5,2.72)
    ax1.set_ylim(0.701,0.728)
    ax11.set_ylabel('Entropy', fontsize=38, color='#d8a6a6')
    ax1.set_ylabel('$W_{ACF}$', fontsize=38, color='firebrick')
    ax1.set_title('Northern Hemisphere',fontsize=38)
    ax1.set_xlabel('Time', fontsize=34, color='k')

    ax1.annotate('a', xy=(-0.12, 1.05), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')    
##################################################################33
  
    xmajorLocator = MultipleLocator(12) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.01) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.3f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax3.xaxis.set_major_locator(xmajorLocator)
    ax3.xaxis.set_major_formatter(xmajorFormatter)
    ax3.yaxis.set_major_locator(ymajorLocator)
    ax3.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.005) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax3.xaxis.set_minor_locator(xminorLocator)
    ax3.yaxis.set_minor_locator(yminorLocator) 
    ax3.tick_params(which='both', width=1.2, labelsize=32)
    ax3.tick_params(which='major', length=12)  
    ax3.tick_params(which='minor',length=6)    
    
    
    
    #修改次刻度
    ymajorLocator = MultipleLocator(0.04) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式    
    yminorLocator = MultipleLocator(0.02) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax33.yaxis.set_major_locator(ymajorLocator)
    ax33.yaxis.set_major_formatter(ymajorFormatter)
    ax33.xaxis.set_minor_locator(xminorLocator)
    ax33.yaxis.set_minor_locator(yminorLocator) 
    ax33.tick_params(which='both', width=1.2, labelsize=32)
    ax33.tick_params(which='major', length=12)  
    ax33.tick_params(which='minor',length=6)  
      

    dates=np.arange(516)/12.+1981
    
    # 副轴：右侧 y 轴
    ax3.plot(dates, wsx, color='#1a80bb',linewidth=3, label='$W_{ACF}$')
    ax33.plot(dates, esx, color='#8cc5e3',linewidth=3, label='Entropy')
    ax33.set_ylim(2.62,2.87)
    ax3.set_ylim(0.745,0.775)
    ax3.set_ylabel('$W_{ACF}$', fontsize=38, color='#1a80bb')
    ax3.set_xlabel('Time', fontsize=38, color='k')

    ax33.set_ylabel('Entropy', fontsize=38, color='#8cc5e3')
    ax3.set_title('Southern Hemisphere',fontsize=38)
    ax3.annotate('c', xy=(-0.12, 1.05), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')    


###########################################################################3
    xmajorLocator = MultipleLocator(0.008) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.3f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.04) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax2.xaxis.set_major_locator(xmajorLocator)
    ax2.xaxis.set_major_formatter(xmajorFormatter)
    ax2.yaxis.set_major_locator(ymajorLocator)
    ax2.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.004) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.02) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax2.xaxis.set_minor_locator(xminorLocator)
    ax2.yaxis.set_minor_locator(yminorLocator) 
    ax2.tick_params(which='both', width=1.2, labelsize=32)
    ax2.tick_params(which='major', length=12)  
    ax2.tick_params(which='minor',length=6)    
    # KDE 密度
    xy = np.vstack([wnx, enx])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wnx[idx]
    ex1y_sorted = enx[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax2.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='rocket')
    ax2.annotate('$r=0.55, p<0.001$', xy=(0.03, 0.93), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    ax2.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=38)
    #ax2.set_ylabel(r"Entropy", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度
    ax2.set_title('Northern Hemisphere',fontsize=38)

    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both', ticks=ticks)
    cbar = plt.colorbar(im, ax=ax2, fraction=0.05, pad=0.04, extend='both')
    cbar.ax.tick_params(labelsize=32)
    cbar.set_label("Density", fontsize=38)
    ax2.annotate('b', xy=(-0.15, 1.05), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')

###########################################################################3
    xmajorLocator = MultipleLocator(0.008) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.3f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.04) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax4.xaxis.set_major_locator(xmajorLocator)
    ax4.xaxis.set_major_formatter(xmajorFormatter)
    ax4.yaxis.set_major_locator(ymajorLocator)
    ax4.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.002) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.02) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax4.xaxis.set_minor_locator(xminorLocator)
    ax4.yaxis.set_minor_locator(yminorLocator) 
    ax4.tick_params(which='both', width=1.2, labelsize=32)
    ax4.tick_params(which='major', length=12)  
    ax4.tick_params(which='minor',length=6)    
    # KDE 密度
    xy = np.vstack([wsx, esx])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wsx[idx]
    ex1y_sorted = esx[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax4.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='mako')
    ax4.annotate('$r=0.68, p<0.001$', xy=(0.03, 0.93), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    ax4.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=38)
   # ax4.set_ylabel(r"Entropy", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度
    ax4.set_title('Southern Hemisphere',fontsize=38)

    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both', ticks=ticks)
    cbar = plt.colorbar(im, ax=ax4, fraction=0.05, pad=0.04, extend='both')
    cbar.ax.tick_params(labelsize=32)
    cbar.set_label("Density", fontsize=38)
    ax4.annotate('d', xy=(-0.15, 1.05), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')


    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.0, wspace = 0.2)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(45, 22)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig4_scatter.pdf",bbox_inches='tight',dpi=300)   


def plot_eofnvswx():    
    path='/home/meng/awpsd/data/'
    entnor=np.loadtxt(path+"eofentropy_northx.dat")
    entsou=np.loadtxt(path+"eofentropy_southx.dat")
    
    wacf=np.loadtxt(path+"t2m_autowc10d_era5_monthly_1980.dat")
    
    wacfx=np.reshape(wacf,(528,8040))
    
    wacfn=[np.mean(wacfx[i,:4020]) for i in range(528)]
    wacfs=[np.mean(wacfx[i,4020:]) for i in range(528)]
    
    wnx=[np.mean(wacfn[i-12:i]) for i in range(12,528)]
    wsx=[np.mean(wacfs[i-12:i]) for i in range(12,528)]
    enx=[np.mean(entnor[i-12:i]) for i in range(12,528)]
    esx=[np.mean(entsou[i-12:i]) for i in range(12,528)]
    
    wnx=np.array(wnx)
    wsx=np.array(wsx)
    enx=np.array(enx)
    esx=np.array(esx)


    import matplotlib.pyplot as plt
    
   # fig = plt.figure(figsize=(10, 6))
    
    # 左上大图（2x2）
    ax1 = plt.subplot2grid((12, 7), (0, 0), rowspan=3, colspan=8)
    ax11 = ax1.twinx()
    
    # 右上图（2行1列）
    ax2 = plt.subplot2grid((12, 7), (8, 0), rowspan=5, colspan=3)
    
    # 下方大图（2行3列）
    ax3 = plt.subplot2grid((12, 7), (4, 0), rowspan=3, colspan=8)
    ax33 = ax3.twinx()
    
    # 中间右上角小图（不会和 ax1 冲突）
    ax4 = plt.subplot2grid((12, 7), (8, 4), rowspan=5, colspan=3)
    
    # plt.tight_layout()
    # plt.show()


    wy=np.array(wnx)
    cy=np.array(enx)
    xmajorLocator = MultipleLocator(10) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.01) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax1.xaxis.set_major_locator(xmajorLocator)
    ax1.xaxis.set_major_formatter(xmajorFormatter)
    ax1.yaxis.set_major_locator(ymajorLocator)
    ax1.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.005) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax1.xaxis.set_minor_locator(xminorLocator)
    ax1.yaxis.set_minor_locator(yminorLocator) 
    ax1.tick_params(which='both', width=1.2, labelsize=42)
    ax1.tick_params(which='major', length=20)  
    ax1.tick_params(which='minor',length=10)    
    
    
    
    #修改次刻度
    ymajorLocator = MultipleLocator(0.1) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式    
    yminorLocator = MultipleLocator(0.05) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax11.yaxis.set_major_locator(ymajorLocator)
    ax11.yaxis.set_major_formatter(ymajorFormatter)
    ax11.xaxis.set_minor_locator(xminorLocator)
    ax11.yaxis.set_minor_locator(yminorLocator) 
    ax11.tick_params(which='both', width=1.2, labelsize=42)
    ax11.tick_params(which='major', length=20)  
    ax11.tick_params(which='minor',length=10)  
      

    dates=np.arange(516)/12.+1981
    
    # 副轴：右侧 y 轴
    ax1.plot(dates, wnx, color='firebrick',linewidth=3, label='$W_{ACF}$')
    ax11.plot(dates, enx, color='#d8a6a6',linewidth=3, label='Entropy')
    ax11.set_ylim(2.5,2.72)
    ax1.set_ylim(0.701,0.728)
    ax11.set_ylabel('Entropy', fontsize=46, color='#d8a6a6')
    ax1.set_ylabel('$W_{ACF}$', fontsize=46, color='firebrick')
    ax1.set_title('NH',fontsize=46)
    ax1.set_xlabel('Time', fontsize=46, color='k')

    ax1.annotate('a', xy=(-0.15, 1.05), xycoords='axes fraction',
                fontsize=50, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')    
##################################################################33
  
    xmajorLocator = MultipleLocator(10) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.01) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax3.xaxis.set_major_locator(xmajorLocator)
    ax3.xaxis.set_major_formatter(xmajorFormatter)
    ax3.yaxis.set_major_locator(ymajorLocator)
    ax3.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.005) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax3.xaxis.set_minor_locator(xminorLocator)
    ax3.yaxis.set_minor_locator(yminorLocator) 
    ax3.tick_params(which='both', width=1.2, labelsize=42)
    ax3.tick_params(which='major', length=20)  
    ax3.tick_params(which='minor',length=10)    
    
    
    
    #修改次刻度
    ymajorLocator = MultipleLocator(0.1) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.1f') #设置y轴标签文本的格式    
    yminorLocator = MultipleLocator(0.05) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax33.yaxis.set_major_locator(ymajorLocator)
    ax33.yaxis.set_major_formatter(ymajorFormatter)
    ax33.xaxis.set_minor_locator(xminorLocator)
    ax33.yaxis.set_minor_locator(yminorLocator) 
    ax33.tick_params(which='both', width=1.2, labelsize=42)
    ax33.tick_params(which='major', length=20)  
    ax33.tick_params(which='minor',length=10)  
      

    dates=np.arange(516)/12.+1981
    
    # 副轴：右侧 y 轴
    ax3.plot(dates, wsx, color='#1a80bb',linewidth=3, label='$W_{ACF}$')
    ax33.plot(dates, esx, color='#8cc5e3',linewidth=3, label='Entropy')
    ax33.set_ylim(2.62,2.87)
    ax3.set_ylim(0.745,0.775)
    ax3.set_ylabel('$W_{ACF}$', fontsize=46, color='#1a80bb')
    ax3.set_xlabel('Time', fontsize=46, color='k')

    ax33.set_ylabel('Entropy', fontsize=46, color='#8cc5e3')
    ax3.set_title('SH',fontsize=46)
    ax3.annotate('b', xy=(-0.15, 1.05), xycoords='axes fraction',
                fontsize=50, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')    


###########################################################################3
    xmajorLocator = MultipleLocator(0.01) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.05) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax2.xaxis.set_major_locator(xmajorLocator)
    ax2.xaxis.set_major_formatter(xmajorFormatter)
    ax2.yaxis.set_major_locator(ymajorLocator)
    ax2.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.005) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.01) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax2.xaxis.set_minor_locator(xminorLocator)
    ax2.yaxis.set_minor_locator(yminorLocator) 
    ax2.tick_params(which='both', width=1.2, labelsize=42)
    ax2.tick_params(which='major', length=20)  
    ax2.tick_params(which='minor',length=10)    
    # KDE 密度
    xy = np.vstack([wnx, enx])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wnx[idx]
    ex1y_sorted = enx[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax2.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='rocket')
    ax2.annotate('$r=0.55$', xy=(0.5, 0.05), xycoords='axes fraction',
                fontsize=46, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    ax2.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=46)
    ax2.set_ylabel(r"Entropy", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度
    ax2.set_title('NH',fontsize=46)

    cbar = plt.colorbar(im, ax=ax2, orientation='horizontal',
                        fraction=0.05, pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=42, top=False, labeltop=False, bottom=True)
    cbar.set_label("KDE", fontsize=42, labelpad=20)
    cbar.ax.xaxis.set_label_position('bottom')
# 微调位置（可选）
    cbar.ax.title.set_position((1.5, 0.1))    
    ax2.annotate('c', xy=(-0.4, 1.05), xycoords='axes fraction',
                fontsize=50, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')

###########################################################################3
    xmajorLocator = MultipleLocator(0.01) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.2f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(0.05) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%.2f') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax4.xaxis.set_major_locator(xmajorLocator)
    ax4.xaxis.set_major_formatter(xmajorFormatter)
    ax4.yaxis.set_major_locator(ymajorLocator)
    ax4.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.005) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(0.01) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax4.xaxis.set_minor_locator(xminorLocator)
    ax4.yaxis.set_minor_locator(yminorLocator) 
    ax4.tick_params(which='both', width=1.2, labelsize=42)
    ax4.tick_params(which='major', length=20)  
    ax4.tick_params(which='minor',length=10)    
    # KDE 密度
    xy = np.vstack([wsx, esx])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wsx[idx]
    ex1y_sorted = esx[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax4.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='mako')
    ax4.annotate('$r=0.68$', xy=(0.3, 0.05), xycoords='axes fraction',
                fontsize=46, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    ax4.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=46)
    ax4.set_ylabel(r"Entropy", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度
    ax4.set_title('SH',fontsize=46)

    cbar = plt.colorbar(im, ax=ax4, orientation='horizontal',
                        fraction=0.05, pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=42, top=False, labeltop=False, bottom=True)
    cbar.set_label("KDE", fontsize=42, labelpad=20)
    cbar.ax.xaxis.set_label_position('bottom')
       
    
    ax4.annotate('d', xy=(-0.3, 1.05), xycoords='axes fraction',
                fontsize=50, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')


    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.5, wspace = 0.4)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(20, 26)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig4_scatterx.pdf",bbox_inches='tight',dpi=300)   
