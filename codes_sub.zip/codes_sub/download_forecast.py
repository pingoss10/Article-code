#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 09:24:31 2024

@author: meng
"""

import cdsapi



for years in range(2013,2024):    
    dataset = "seasonal-original-pressure-levels"
    request = {
        "originating_centre": "ncep",
        "system": "2",
        "variable": ["temperature"],
        "year": [years],
        "month": [
            "01", "02", "03",
            "04", "05", "06",
            "07", "08", "09",
            "10", "11", "12"
        ],
        "day": [
            "01", "02", "03",
            "04", "05", "06",
            "07", "08", "09",
            "10", "11", "12",
            "13", "14", "15",
            "16", "17", "18",
            "19", "20", "21",
            "22", "23", "24",
            "25", "26", "27",
            "28", "29", "30",
            "31"
        ],
        "leadtime_hour": ["24"],
        "data_format": "netcdf"
    }

    client = cdsapi.Client()
    client.retrieve(dataset, request).download( "/home/meng/awpsd/data/origin/t2m_forecast10d_ncep_"+str(years)+".nc")
    
    
    
    