#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 15:02:18 2024

@author: meng
"""

import nolds
from scipy.interpolate import griddata
from netCDF4 import Dataset

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
from scipy.signal import detrend

from scipy.stats import gaussian_kde
import pymannkendall as mk
import matplotlib as mpl
from scipy.stats import linregress
import glob
import seaborn as sns
from numpy import pi, e
from netCDF4 import Dataset
import numpy as np
np.bool = np.bool_
from scipy.stats import percentileofscore

def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,tau+1):
        x1=x[tau:l+tau]
        x2=x[tau+t:l+t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    w=(1-np.mean(z))/np.std(z)
    return z
def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def autowc(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)*1/np.sqrt(2*tau)
    return a


def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)

def mk_test(y):
    import pymannkendall as mk
    result = mk.original_test(y)
    return result.slope, result.p, result.z

def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def awps(x,s1,l):
    n=round(l/2)
    lx=np.arange(n)
    t0=np.abs(np.fft.fft(x[s1:s1+l]))
    ta=sum(lx*t0[:n])/sum(t0[1:n])
    return ta/n

def sf(x):
    fx=np.fft.fft(x)
    phx=np.angle(fx)
    np.random.shuffle(phx)
    fy=np.abs(fx)*e**(1j*phx)
    y=np.fft.ifft(fy)
    z=np.real(y) 
    return z

def white_noise(N,b):
    yx1=[]
    yx2=[]
    yx3=[]
    yx4=[]
    zx1=[]
    zx2=[]
    zx3=[]
    zx4=[]
    y=np.random.uniform(-b,b,N)#white noise
    fx=np.fft.fft(y)
    phx=np.angle(fx)
    fy=np.abs(fx)*e**(1j*phx)
    z=np.fft.ifft(fy)
        
    nz=sum(np.abs(fx))/len(fx)
    fw=np.ones(len(fx))*nz
        
    fyy=fw*e**(1j*phx)
    zz=np.fft.ifft(fyy)
        
    zx=np.real(z)#white noise
    zy=np.real(zz)#white noise with uniform power spectrum
    
    return z,zz

def function_autocorr():
    #path='/home/meng/bupt_data/data/seaice/'
    path='/home/meng/awpsd/data/'
    #wx=np.zeros(shape=(480,8040))
    #cx=np.zeros(shape=(480,8040))
    outfile=open(path+'autocorr_abs.dat','w')
    n=0
    for year in range(1980,2024):
        print (year)
        for month in range(1,13):
            print (month)
            year=int(year)
            month=int(month)
            data=np.loadtxt(path+""+str(year)+"_"+str(month)+"_TT_autocorr_abs.dat")
            
            w=data
            #c=data[:,1]
           
            for i in range(8040):
                outfile.write('%.6f \n'%(w[i]))
                outfile.flush()
     #       wx[n]=w
     #       cx[n]=c
     #       n+=1        
    outfile.close()

    
def function_wac():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_2006to2024.ano')
    tau=30
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6860))
  
    # for m in range(11,12):
    #     outfile=open(path+"t2m_autowc5d_era5_month"+str(m)+".dat",'w')
    #     for year in range(2008,2023):
    #         year=int(year)   
    #         print (year)   
    #         for i in range(len(nodes)):
    #             s=(year-2007)*365+monthd[m]
    #             x=T[i,s-tau:s+months[m]+tau]
    #             w=autowc(x,tau,months[m])
    #             outfile.write('%.6f \n'%(w))
    #             outfile.flush()
    #     outfile.close()
    outfile=open(path+"t2m_autowc30d_era5_monthly.dat",'w')
    for year in range(2007,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-2006)*365+monthd[m]
                        
                x=T[i,s-tau:s+months[m]+tau]
                w=autowc(x,tau,months[m])
                outfile.write('%.6f \n'%(w))
                outfile.flush()      
    outfile.close()
                
def function_wac():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_1979.ano')
    tau=10
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16715))
      
  
    outfile=open(path+"t2m_autowc10d_era5_monthly_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            print (m)
            for i in range(len(nodes)):
                print (i)
                s=(year-1979)*365+monthd[m]
                        
                x=T[i,s-tau:s+months[m]+tau]
                w=autowc(x,tau,months[m])
                outfile.write('%.6f \n'%(w))
                outfile.flush()      
    outfile.close()


    outfile=open(path+"t2m_std_era5_monthly_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            #print (m)
            for i in range(len(nodes)):
             #   print (i)
                s=(year-1979)*365+monthd[m]
                        
                x=T[i,s-tau:s+months[m]+tau]
                w=np.std(x)
                outfile.write('%.6f \n'%(w))
                outfile.flush()      
    outfile.close()



def function_autocorr():
    #path='/home/meng/bupt_data/data/seaice/'
    path='/home/meng/awpsd/data/'
    #wx=np.zeros(shape=(480,8040))
    #cx=np.zeros(shape=(480,8040))
    outfile=open(path+'autocorr850_absx.dat','w')
    n=0
    for year in range(1980,2024):
        print (year)
        for month in range(1,13):
            print (month)
            year=int(year)
            month=int(month)
           # data=np.loadtxt(path+""+str(year)+"_"+str(month)+"_TT850_autocorr_abs.dat")
            data=np.loadtxt("/home/meng/bak_bupt/newproj/data/"+str(year)+"_"+str(month)+"_TT_autocorr_abs.dat")
            w=data
            #c=data[:,1]
           
            for i in range(8040):
                outfile.write('%.6f \n'%(w[i]))
                outfile.flush()
     #       wx[n]=w
     #       cx[n]=c
     #       n+=1        
    outfile.close()


def function_wac_ano():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ano_2007to2023.ano')
    tau=5
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6205))
    outfile=open(path+"t2m_autowc5d_era5_monthly_ano.dat",'w')
    for year in range(2007,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):
                if(year==2007 and m==0):
                    s=(year-2007)*365+monthd[m]+tau
                else:
                    if(year==2023 and m==11):
                        s=(year-2007)*365+monthd[m]-tau
                    else:
                        s=(year-2007)*365+monthd[m]
                        
                x=T[i,s-tau:s+months[m]+tau]
                w=autowc(x,tau,months[m])
                outfile.write('%.6f \n'%(w))
                outfile.flush()      
    outfile.close()





def function_ori_ext():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_2006to2024.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6860))
    cyc=np.loadtxt(path+'era5t2m2.5g_climate.ano')
    mx=np.reshape(cyc[:,0],(8040,365))
    sx=np.reshape(cyc[:,1],(8040,365))
    outfile=open(path+"t2m_era5_ex_ori2.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(2006,2024):
            #print (year)
            for d in range(365):
                s=(year-2006)*365+d
                a=(T[i,s]-mx[i,d])
                if(np.abs(a)>2*sx[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()


    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ex_ori2.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,6570))
  
    outfile=open(path+"t2m_ext_era5_ori_monthly2.dat",'w')
    for year in range(2007,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-2006)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s-1:s+months[m]]
                for j in range(months[m]):
                    if(xx[j]==1 and xx[j-1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close()    


def function_ori_ext1979():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_1979.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16715))
    
    cyc=np.loadtxt(path+'era5t2m2.5g_climate.ano')
    mx=np.reshape(cyc[:,0],(8040,365))
    sx=np.reshape(cyc[:,1],(8040,365))
    outfile=open(path+"t2m_era5_ex_ori2_1979.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(1979,2024):
            #print (year)
            for d in range(365):
                s=(year-1979)*365+d
                a=(T[i,s]-mx[i,d])
                if(np.abs(a)>2*sx[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()


    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ex_ori2_1979.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16425))
  
    outfile=open(path+"t2m_ext_era5_ori_monthly2_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1979)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s-1:s+months[m]]
                for j in range(months[m]):
                    if(xx[j]==1 and xx[j-1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close()    



def function_change_ext1979():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_1979.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16715))

    T1=[(np.abs(T[i][1:]-T[i][:-1])) for i in range(8040)]


########################3
    sx1 = []
    outfile=open(path+"t2m_era5_ext15_Tstdcircle_1980.dat",'w')  
    
    for n in range(8040):                     # 外层：第 n 个空间点
        t = T[n][:]                      # 取出该点的时间序列
        for j in range(365):                  # 一年内的每一天
            # 收集44年中该天（±7天范围）的值
            tt = np.array([t[365*y + j - 7 : 365*y + j + 8] 
                           for y in range(1, 45)
                           if (365*y + j + 7) <= len(t)])  # 防越界保护
            tt = tt.reshape(-1, 1)            # 拉平成一列
            sx1.append(np.std(tt))             # 计算标准差

            outfile.write('%.6f \n'%(i))
            outfile.flush()
    outfile.close()   

############################3

    mx= []
    sx = []
    outfile=open(path+"t2m_era5_ex15_msT1_1980.dat",'w')
    for n in range(8040):                     # 外层：第 n 个空间点
        t = T1[n][:]                      # 取出该点的时间序列
        for j in range(365):                  # 一年内的每一天
            # 收集44年中该天（±7天范围）的值
            tt = np.array([t[365*y + j - 7 : 365*y + j + 8] 
                           for y in range(1, 45)
                           if (365*y + j + 8) <= len(t)])  # 防越界保护
            tt = tt.reshape(-1, 1)            # 拉平成一列
            sx.append(np.std(tt))  
            mx.append(np.mean(tt))
            outfile.write('%.6f %.6f \n'% (np.std(tt),np.mean(tt)))
            outfile.flush()
    outfile.close()
            
             
    mx=np.reshape(mx,(8040,365))
    sx=np.reshape(sx,(8040,365))
    outfile=open(path+"t2m_era5_ex15_change1_1980.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(1980,2024):
            #print (year)
            for d in range(365):
                s=(year-1979)*365+d
                if(T1[i][s]>sx[i,d]+mx[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()



    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ex15_change1_1980.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16060))
  
    outfile=open(path+"t2m_ex15_era5_change_monthly1_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1980)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s:s+months[m]]
                for j in range(months[m]-1):
                    if(xx[j]==1 and xx[j+1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close()   



##################################3
    
    sx=[]
    for i in range(8040):
        t=T[i][:16425]
        t=np.reshape(t,(45,365))
        for j in range(365):
            sx.append(np.std(t[:,j]))
               
    sx=np.reshape(sx,(8040,365))
    outfile=open(path+"t2m_era5_ext_change3_1980.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(1980,2024):
            #print (year)
            for d in range(365):
                s=(year-1979)*365+d
                if(np.abs(T1[i][s])>3*sx[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()




    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ext_change3_1980.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16060))
  
    outfile=open(path+"t2m_ext_era5_change_monthly3_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1980)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s:s+months[m]]
                for j in range(months[m]-1):
                    if(xx[j]==1 and xx[j+1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close()   

######################################

    sx=[]
    for i in range(8040):
        t=T[i][:16425]
        t=np.reshape(t,(45,365))
        for j in range(365):
            sx.append(np.std(t[:,j]))
               
    sx=np.reshape(sx,(8040,365))
    outfile=open(path+"t2m_era5_ext_change3_1980.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(1980,2024):
            #print (year)
            for d in range(365):
                s=(year-1979)*365+d
                if(np.abs(T1[i][s])>3*sx[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()




    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ext_change3_1980.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16060))
  
    outfile=open(path+"t2m_ext_era5_change_monthly3_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1980)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s:s+months[m]]
                for j in range(months[m]-1):
                    if(xx[j]==1 and xx[j+1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close() 


############################33


    sx1 = []
    
    for n in range(8040):                     # 外层：第 n 个空间点
        t = T[n][:]                      # 取出该点的时间序列
        for j in range(365):                  # 一年内的每一天
            # 收集44年中该天（±7天范围）的值
            tt = np.array([t[365*y + j - 7 : 365*y + j + 8] 
                           for y in range(1, 45)
                           if (365*y + j + 8) <= len(t)])  # 防越界保护
            tt = tt.reshape(-1, 1)            # 拉平成一列
            sx1.append(np.std(tt))             # 计算标准差


     
    sx1=np.reshape(sx1,(8040,365))
    
    outfile=open(path+"t2m_era5_ext15_change2_1980.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(1980,2024):
            #print (year)
            for d in range(365):
                s=(year-1980)*365+d
                if(np.abs(T1[i][s])>2*sx1[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()




    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ext15_change2_1980.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16060))
  
    outfile=open(path+"t2m_ext15_era5_change_monthly2_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1980)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s:s+months[m]]
                for j in range(months[m]-1):
                    if(xx[j]==1 and xx[j+1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close() 


###############################################

    sx2 = []
    sm2 = []
    
    for n in range(8040):                     # 外层：第 n 个空间点
        t = T[n][:]                      # 取出该点的时间序列
        for j in range(365):                  # 一年内的每一天
            # 收集44年中该天（±7天范围）的值
            tt = np.array([t[365*y + j - 7 : 365*y + j + 8] 
                           for y in range(1, 45)
                           if (365*y + j + 8) <= len(t)])  # 防越界保护
            tt = tt.reshape(-1, 1)            # 拉平成一列
            sx2.append(np.std(tt))             # 计算标准差
            sm2.append(np.mean(tt))    

     
    sx2=np.reshape(sx2,(8040,365))
    sm2=np.reshape(sm2,(8040,365))
    
    outfile=open(path+"t2m_era5_ext15_1980STD1.dat",'w')
    for i in range(len(nodes)):
        print (i)
        for year in range(1980,2024):
            #print (year)
            for d in range(365):
                s=(year-1980)*365+d
                if(T[i][s]>1*sx2[i,d]+sm2[i,d] or T[i][s]<sm2[i,d]-1*sm2[i,d]):
                    b=1
                else:
                    b=0
                outfile.write('%d \n'%(b))
                outfile.flush()   
    outfile.close()




    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+"t2m_era5_ext15_1980STD1.dat")
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16060))
  
    outfile=open(path+"t2m_ext15_era5_monthly1_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1980)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s:s+months[m]]
                for j in range(months[m]-1):
                    if(xx[j]==1 and xx[j+1]!=1):
                        b+=1
                        
                outfile.write('%d %d \n'%(a,b))
                outfile.flush()      
    outfile.close() 






    wen=np.loadtxt('/home/meng/awpsd/data/results/3sigma/events_tempdiff_deseason_hi_lo_sum_monthly_1980_2024_merged.dat')
    hao=np.loadtxt('/home/meng/awpsd/data/results/3sigma/tasdiff/deseasonalized and normalized/days_tempdiff_deseason_hi_lo_sum_monthly_1980_2024.dat')
    ext3=np.loadtxt(path+"t2m_ext15_era5_monthly3_1980.dat")    #extreme T 3STD(T)+mean(T)
    ex3=np.loadtxt(path+"t2m_ext15_era5_change_monthly3_1980.dat")  # extreme T1  3STD(T)
    ext1=np.loadtxt(path+"t2m_ext15_era5_monthly1_1980.dat")    # extreme T 3STD(T)+mean(T)
    ex1=np.loadtxt(path+"t2m_ext15_era5_change_monthly2_1980.dat")  #extreme T1  2STD(T)
    wacf=np.loadtxt(path+"t2m_autowc10d_era5_monthly_1980.dat")
    hw=np.loadtxt('/home/meng/awpsd/data/results/heat_flat.dat')
    cw=np.loadtxt('/home/meng/awpsd/data/results/cold_flat.dat')
    psd=np.loadtxt('/home/meng/bak_bupt/newproj/data/psd_sum_t850.dat')
    std=np.loadtxt(path+"t2m_std_era5_monthly_1980.dat")
    ww=hw+cw
    extt3=np.loadtxt(path+"t2m_ex15_era5_change_monthly3_1980.dat")  #extreme T1  3STD(T1)+mean(T1)
    extt1=np.loadtxt(path+"t2m_ex15_era5_change_monthly1_1980.dat")  #extreme T1  1STD(T1)+mean(T1)
    extt2=np.loadtxt(path+"t2m_ex15_era5_change_monthly2_1980.dat")  #extreme T1  2STD(T1)+mean(T1)

    
    extt1x=np.reshape(extt1[:,0],(528,8040))    
    extt3x=np.reshape(extt3[:,0],(528,8040))
    extt2x=np.reshape(extt2[:,0],(528,8040))    
    ext3x=np.reshape(ext3[:,0],(528,8040))
    ex3x=np.reshape(ex3[:,0],(528,8040))
    ext1x=np.reshape(ext1[:,0],(528,8040))
    ex1x=np.reshape(ex1[:,0],(528,8040))    
    wacfx=np.reshape(wacf,(528,8040))
    hwx=np.reshape(hw,(8040,40))
    cwx=np.reshape(cw,(8040,40))
    wx=np.reshape(ww,(8040,40))
    psdx=np.reshape(psd,(8040,480))
    stdx=np.reshape(std,(528,8040))

    extt2y=[sum(extt2x[:,i]) for i in range(8040)]    
    extt1y=[sum(extt1x[:,i]) for i in range(8040)]
    extt3y=[sum(extt3x[:,i]) for i in range(8040)]
    ext3y=[sum(ext3x[:,i]) for i in range(8040)]
    ex3y=[sum(ex3x[:,i]) for i in range(8040)]
    ext1y=[sum(ext1x[:,i]) for i in range(8040)]
    ex1y=[sum(ex1x[:,i]) for i in range(8040)]
    wacfy=[np.mean(wacfx[:,i]) for i in range(8040)]
    hwy=[sum(hwx[i,:]) for i in range(8040)]
    cwy=[sum(cwx[i,:]) for i in range(8040)]
    wy=[sum(hwx[i,:])+sum(cwx[i,:]) for i in range(8040)]
    psdy=[np.mean(psdx[i,:]) for i in range(8040)]
    stdy=[sum(stdx[:,i]) for i in range(8040)]
    
   
    wenx=np.reshape(wen,(8040,540))
    haox=np.reshape(hao,(8040,540))
    
    weny=[sum(wenx[i,:]) for i in range(8040)]
    haoy=[sum(haox[i,:]) for i in range(8040)]

    
    extt3a=[sum(extt3x[i,:]) for i in range(528)]
    ext3a=[sum(ext3x[i,:]) for i in range(528)]
    ex3a=[sum(ex3x[i,:]) for i in range(528)]
    extt1a=[sum(extt1x[i,:]) for i in range(528)]
    ext1a=[sum(ext1x[i,:]) for i in range(528)]
    ex1a=[sum(ex1x[i,:]) for i in range(528)]
    wacfa=[sum(wacfx[i,:]) for i in range(528)]
    hwa=[sum(hwx[:,i]) for i in range(40)]
    cwa=[sum(cwx[:,i]) for i in range(40)]
    wa=[sum(hwx[:,i])+sum(cwx[:,i]) for i in range(40)]      
    wena=[sum(wenx[:,i]) for i in range(528)]
    haoa=[sum(haox[:,i]) for i in range(528)]    
    stda=[sum(stdx[i,:]) for i in range(528)]
    
    
    wacf_ex1=[]
    wacf_ex1_p=[]    
    for i in range(8040):
        print (i)
        x1=[np.mean(wacfx[j-12:j,i]) for j in range(12,528)] 
        x2=[np.mean(ex1x[j-12:j,i]) for j in range(12,528)] 
        wacf_ex1.append(pearsonr(x1,x2)[0])
        yx=[]
        for t in range(100):
            y1=sf(x1)
            y2=sf(x2)
            yx.append(pearsonr(y1,y2)[0])
        p=percentileofscore(yx, pearsonr(x1,x2)[0], kind='weak')
  
        wacf_ex1_p.append(p)   
    
    wacfz=[]
    ext3z=[]
    ex3z=[]
    extt3z=[]
    extt1z=[]    
    wenz=[]
    haoz=[]
    psdz=[]
    ext1z=[]
    ex1z=[]
    for i in range(8040):
        for j in range(44):
            wacfz.append(np.mean(wacfx[j*12:j*12+12,i]))
            extt3z.append(sum(extt3x[j*12:j*12+12,i]))
            extt1z.append(sum(extt1x[j*12:j*12+12,i]))
            ext3z.append(sum(ext3x[j*12:j*12+12,i]))
            ex3z.append(sum(ex3x[j*12:j*12+12,i]))
            ext1z.append(sum(ext1x[j*12:j*12+12,i]))
            ex1z.append(sum(ex1x[j*12:j*12+12,i]))            
            
            

            
    wacfz=np.reshape(wacfz,(8040,44))
    extt3z=np.reshape(extt3z,(8040,44))
    extt1z=np.reshape(extt1z,(8040,44))
    ext3z=np.reshape(ext3z,(8040,44))
    ex3z=np.reshape(ex3z,(8040,44))
    ext1z=np.reshape(ext1z,(8040,44))
    ex1z=np.reshape(ex1z,(8040,44))
    
 
    
    
    psdt=[]
    wacft=[]
    wt=[]
    ex3t=[]
    ext3t=[]
    ex1t=[]
    ext1t=[]  
    hwt=[]
    cwt=[]
    extt1t=[]
    extt3t=[]
    for i in range(8040):
        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),wacfz[i])
        if(p_value<0.05):
            wacft.append(slope)
        else:
            wacft.append(0)
        slope, intercept, r_value, p_value, std_err = linregress(np.arange(480),psdx[i,:480])
        # if(p_value<0.05):
        #     psdt.append(slope)
        # else:
        #     psdt.append(0)            
            
        # slope, intercept, r_value, p_value, std_err = linregress(np.arange(40),wx[i])
        # if(p_value<0.05):
        #     wt.append(slope)
        # else:
        #     wt.append(0)
        # slope, intercept, r_value, p_value, std_err = linregress(np.arange(40),hwx[i])
        # if(p_value<0.05):
        #     hwt.append(slope)
        # else:
        #     hwt.append(0)
        # slope, intercept, r_value, p_value, std_err = linregress(np.arange(40),cwx[i])
        # if(p_value<0.05):
        #     cwt.append(slope)
        # else:
        #     cwt.append(0)

            
        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ex3z[i])
        if(p_value<0.05):
            ex3t.append(slope)
        else:
            ex3t.append(0)           

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ext3z[i])
        if(p_value<0.05):
            ext3t.append(slope)
        else:
            ext3t.append(0)   

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ex1z[i])
        if(p_value<0.05):
            ex1t.append(slope)
        else:
            ex1t.append(0)           

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ext1z[i])
        if(p_value<0.05):
            ext1t.append(slope)
        else:
            ext1t.append(0)   

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),extt3z[i])
        if(p_value<0.05):
            extt3t.append(slope)
        else:
            extt3t.append(0)           

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),extt1z[i])
        if(p_value<0.05):
            extt1t.append(slope)
        else:
            extt1t.append(0)   

    wacft1=[]
    wt1=[]
    ex3t1=[]
    ext3t1=[]
    ex1t1=[]
    ext1t1=[]  
    extt1t1=[]
    extt3t1=[]
    for i in range(8040):
        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),wacfz[i])
        wacft1.append(r_value)   
        
        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ex3z[i])
        ex3t1.append(r_value)

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ext3z[i])
        ext3t1.append(r_value) 

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ex1z[i])
        ex1t1.append(r_value)         

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),ext1z[i])
        ext1t1.append(r_value)

        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),extt3z[i])
        extt3t1.append(r_value)
        
        slope, intercept, r_value, p_value, std_err = linregress(np.arange(44),extt1z[i])
        extt1t1.append(r_value)


    wacft2=[]
    wt2=[]
    ex3t2=[]
    ext3t2=[]
    ex1t2=[]
    ext1t2=[]  
    extt1t2=[]
    extt3t2=[]
    wacft3=[]
    wt3=[]
    ex3t3=[]
    ext3t3=[]
    ex1t3=[]
    ext1t3=[]  
    extt1t3=[]
    extt3t3=[]
    for i in range(8040):
        slope, p, z = mk_test(wacfz[i])
        wacft2.append(z)   
        wacft3.append(p)         

        slope, p, z = mk_test(ex1z[i])
        ex1t2.append(z)  
        ex1t3.append(p)  

        slope, p, z = mk_test(ex3z[i])
        ex3t2.append(z)  
        ex3t3.append(p)  









    
    wacfy=np.array(wacfy)
    ex1y=np.array(ex1y)
    ex3y=np.array(ex3y)
    wacft=np.array(wacft)
    ex1t=np.array(ex1t)
    ex3t=np.array(ex3t)

    a1=np.array(wacft)
    b1=np.array(ex1t)
    mask = (np.array(a1) != 0) & (np.array(b1) != 0)   # 同时非零的位置

    import numpy as np
    
    a = a1[mask]
    b = b1[mask]
    
    # 原始标量积
    S_obs = np.dot(a, b)
    
    # 随机置换 b（或 a），打破其对应关系
    n_perm = 10000
    S_rand = np.zeros(n_perm)
    for i in range(n_perm):
        b_perm = np.random.permutation(b)
        S_rand[i] = np.dot(a, b_perm)
    
    # p 值（双侧）
    p_val = np.mean(np.abs(S_rand) >= np.abs(S_obs))
    print(f"Scalar product = {S_obs:.4f},  p = {p_val:.4f}")
    cc, pval = pearsonr(a, b)
    print("Pearson r =", cc,pval)
 
    outfile=open(path+'spacemean.dat','w')
    for i in range(8040):
        outfile.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(wacfy[i]/528.,hwy[i]/40.,cwy[i]/40.,wy[i]/40,ex1y[i]/44.,ex3y[i]/44.,ext1y[i]/44.,ext3y[i]/44.,extt1y[i]/44.,extt3y[i]/44.))
        outfile.flush()
    outfile.close()
    
    outfile=open(path+'timemean.dat','w')
    for i in range(8040):
        outfile.write('%.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f \n'%(wacft[i],hwt[i],cwt[i],wt[i],ex1t[i],ex3t[i],ext1t[i],ext3t[i],extt1t[i],extt3t[i]))
        outfile.flush()
    outfile.close()
        
def plot_map():
    import numpy as np
    import matplotlib.pyplot as plt
    from mpl_toolkits.basemap import Basemap
    from scipy.interpolate import griddata
        
  #  plt.rcParams['font.family'] = 'Times New Roman'
    
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    fig=plt.figure()   



    
    ax=plt.subplot(321)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(wcx)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu', vmin=-0.5, vmax=0.5)
    
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('$W_{ACF}$', fontsize=32, labelpad=15)
    ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('a', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(322)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(wacft2)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-3, vmax=4.7)
    
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    signodes= (np.array(wacft3)< 0.05)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')    
    
    
    cbar.set_label('$W_{ACF}$', fontsize=32, labelpad=15)
    ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('b', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  

    ax=plt.subplot(323)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=ex1y
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=-100, vmax=1500)
    
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Extreme Events ($2\sigma$)', fontsize=32, labelpad=15)
   # ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('c', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(324)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(ex1t2)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-4.5, vmax=6.5)
    
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Extreme Events ($2\sigma$)', fontsize=32, labelpad=15)
    
    signodes= (np.array(ex1t3)< 0.05)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')
  #  ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('d', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  


    ax=plt.subplot(325)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=ex3y
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=-30, vmax=160)
    
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Extreme Events ($3\sigma$)', fontsize=32, labelpad=15)
    #ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('e', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(326)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(ex3t2)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-3, vmax=4)
    
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar.ax.tick_params(labelsize=32)
    signodes= (np.array(ex3t3)< 0.05)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')   
    cbar.set_label('Extreme Events ($3\sigma$)', fontsize=32, labelpad=15)
   # ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('f', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  

    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.05, wspace = 0.3)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(34, 30)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig2test.png",bbox_inches='tight')           





def plot_scatter():
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    from scipy.stats import gaussian_kde


    import numpy as np
    import matplotlib.pyplot as plt
    from mpl_toolkits.basemap import Basemap
    from scipy.interpolate import griddata
        
  #  plt.rcParams['font.family'] = 'Times New Roman'
    
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    fig=plt.figure()   



    
    ax=plt.subplot(321)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=32,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=32,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(wacfy)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=0.57, vmax=hh)
    
    # ===== 添加颜色条 =====
    #cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Temporal Mean', fontsize=34, labelpad=15)
    ax.set_title('$W_{ACF}$',fontsize=38,x=0.5,y=1.03)
    ax.annotate('a', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(322)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=32,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=32,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])

    color=np.array(wacft2)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-3, vmax=4.7)
    
    # ===== 添加颜色条 =====
    #cbar = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.04, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    signodes= (np.array(wacft3)< 0.05)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')    
    
    
    cbar.set_label('Temporal Trend (Z score)', fontsize=34, labelpad=15)
    ax.set_title('$W_{ACF}$',fontsize=38,x=0.5,y=1.03)
    ax.annotate('d', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  

    ax=plt.subplot(323)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=ex1y
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=-100, vmax=1500)
    
    # ===== 添加颜色条 =====
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')  
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Temporal Mean', fontsize=34, labelpad=15)
    ax.set_title('Extreme Events',fontsize=38,x=0.5,y=1.03)
   # ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('b', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(324)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lat1=np.array(regrid[:,1][nodes])
    lon1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(ex1t2)
# ===== 网格准备 =====
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lon1), np.max(lon1), numcols)
    lat = np.linspace(np.max(lat1), np.min(lat1), numrows)
    lonX, lat = np.meshgrid(lonX, lat)
    
    
    
    z_lin  = griddata((lon1, lat1), color, (lonX, lat), method='linear')
    z_near = griddata((lon1, lat1), color, (lonX, lat), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    
    im = m.pcolormesh(lonX, lat, z_grid, latlon=True, shading='auto', cmap='RdBu_r', vmin=-4.5, vmax=6.5)
    
    # ===== 添加颜色条 =====
    #cbar = m.colorbar(im, fraction=0.035, location='right', pad=0.4, extend='both')
    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both')
    cbar = plt.colorbar(im, ax=ax, fraction=0.028,     # 控制粗细
                    pad=0.04,
                    aspect=15,         # 默认是 20，越小越粗
                    shrink=1.0, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Temporal Trend (Z score)', fontsize=34, labelpad=15)
    ax.set_title('Extreme Events',fontsize=38,x=0.5,y=1.03)
    
    signodes= (np.array(ex1t3)< 0.05)   # 同时非零的位置
    lats1=np.array(regrid[:,1][signodes])
    lons1=np.array(regrid[:,2][signodes])
    x, y = m(lons1,lats1)

    m.scatter(x,y,20,marker='.',c='k')
  #  ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('e', xy=(-0.1,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')      
   
    
    # 核密度估计
    ax = plt.subplot(325)
    xmajorLocator = MultipleLocator(0.2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%.1f') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(400) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%d') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(0.1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(200) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor',length=6)    
    # KDE 密度
    xy = np.vstack([wacfy, ex1y])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wacfy[idx]
    ex1y_sorted = ex1y[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='mako')
   # ax.set_title("KDE Density Scatter", fontsize=32)
    ax.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=34)
    ax.set_ylabel(r"Extreme Events", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度

    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both', ticks=ticks)
    cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both',ticks=[0.002,0.006,0.010,0.014])
    cbar.ax.tick_params(labelsize=32)
    cbar.set_label("Density", fontsize=34)
    
    # ✅ 添加标注（必须在 plt.show() 前）
    ax.annotate('$r=0.86, p<0.001$', xy=(0.03, 0.93), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    ax.annotate('c', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    
    # ✅ 最后显示图像
    #plt.tight_layout()
   # plt.show()


    ax=plt.subplot(326)
 
    # KDE 密度
    wacft2=np.array(wacft2)
    ex1t2=np.array(ex1t2)
    xmajorLocator = MultipleLocator(2) #将x主刻度标签设置为20的倍数
    xmajorFormatter = FormatStrFormatter('%d') #设置x轴标签文本的格式
    ymajorLocator = MultipleLocator(2) #将y轴主刻度标签设置为0.5的倍数
    ymajorFormatter = FormatStrFormatter('%d') #设置y轴标签文本的格式
    # #设置主刻度标签的位置,标签文本的格式
    ax.xaxis.set_major_locator(xmajorLocator)
    ax.xaxis.set_major_formatter(xmajorFormatter)
    ax.yaxis.set_major_locator(ymajorLocator)
    ax.yaxis.set_major_formatter(ymajorFormatter)
    
    #修改次刻度
    xminorLocator = MultipleLocator(1) #将x轴次刻度标签设置为5的倍数
    yminorLocator = MultipleLocator(1) #将此y轴次刻度标签设置为0.1的倍数
    #设置次刻度标签的位置,没有标签文本格式
    ax.xaxis.set_minor_locator(xminorLocator)
    ax.yaxis.set_minor_locator(yminorLocator) 
    ax.tick_params(which='both', width=1.2, labelsize=32)
    ax.tick_params(which='major', length=12)  
    ax.tick_params(which='minor',length=6)    
    # KDE 密度
    xy = np.vstack([wacft2, ex1t2])
    z = gaussian_kde(xy)(xy)
    idx = z.argsort()
    wacfy_sorted = wacft2[idx]
    ex1y_sorted = ex1t2[idx]
    z_sorted = z[idx]
    
    # 绘图
    im = ax.scatter(wacfy_sorted, ex1y_sorted, c=z_sorted, s=50, cmap='mako')
    ax.annotate('$r=0.34, p<0.001$', xy=(0.03, 0.93), xycoords='axes fraction',
                fontsize=38, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    ax.set_xlabel(r"$W_{\mathrm{ACF}}$", fontsize=34)
    ax.set_ylabel(r"Extreme Events", fontsize=34)
    
    # 添加颜色条
   # ticks = np.linspace(0.002,0.016,6)  # 设置5个刻度

    #cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both', ticks=ticks)
    cbar = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.04, extend='both',ticks=[0.01,0.03,0.05,0.07])
    cbar.ax.tick_params(labelsize=32)
    cbar.set_label("Density", fontsize=34)
    ax.annotate('f', xy=(-0.1, 1.04), xycoords='axes fraction',
                fontsize=42, weight='bold', xytext=(0, -12), textcoords='offset points',
                color='k', rotation=0, ha='left', va='bottom')
    


    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.05, wspace = 0.3)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(34, 30)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig2_scatter.png",bbox_inches='tight',dpi=300)   














def plot_land():
    import numpy as np
    import matplotlib.pyplot as plt
    from mpl_toolkits.basemap import Basemap
    from scipy.interpolate import griddata
        
  #  plt.rcParams['font.family'] = 'Times New Roman'
    
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    fig=plt.figure()   



    
    ax=plt.subplot(321)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=wacfy
    on_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x, y)])
    on_ocean = ~on_land
    lons_land = lons1[on_land]
    lats_land = lats1[on_land]
    color_land0 = np.array(color)[on_land]   # 对应颜色数据同步筛选
    
    # 绘制陆地节点
    xx, yy = m(lons_land, lats_land)
    
    
    
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lons1), np.max(lons1), numcols)
    latX = np.linspace(np.max(lats1), np.min(lats1), numrows)
    # x1, y1 = m(lonX,lat)
    lonX, latX = np.meshgrid(lonX, latX)
    x1, y1 = m(lonX,latX)
    mask_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x1.ravel(), y1.ravel())])

    # mask_land = m.is_land(x.ravel(), y.ravel())   # 一维结果
    mask_land = mask_land.reshape(x1.shape)        # 还原二维掩膜
    
    z_lin  = griddata((lons1,lats1), np.array(color), (lonX, latX), method='linear')
    z_near = griddata((lons1,lats1), np.array(color), (lonX, latX), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)

    z_grid = np.where(mask_land, z_grid, np.nan)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    im = m.pcolormesh(lonX, latX, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=ll, vmax=hh)
    
    cbar = m.colorbar(im, fraction=0.02, location='right', pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('$W_{ACF}$', fontsize=32, labelpad=15)
    ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('a', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(322)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(wacft)*10
    on_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x, y)])
    on_ocean = ~on_land
    lons_land = lons1[on_land]
    lats_land = lats1[on_land]
    color_land0 = np.array(color)[on_land]   # 对应颜色数据同步筛选
    
    # 绘制陆地节点
    xx, yy = m(lons_land, lats_land)
    
    
    
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lons1), np.max(lons1), numcols)
    latX = np.linspace(np.max(lats1), np.min(lats1), numrows)
    # x1, y1 = m(lonX,lat)
    lonX, latX = np.meshgrid(lonX, latX)
    x1, y1 = m(lonX,latX)
    mask_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x1.ravel(), y1.ravel())])

    # mask_land = m.is_land(x.ravel(), y.ravel())   # 一维结果
    mask_land = mask_land.reshape(x1.shape)        # 还原二维掩膜
    
    z_lin  = griddata((lons1,lats1), np.array(color), (lonX, latX), method='linear')
    z_near = griddata((lons1,lats1), np.array(color), (lonX, latX), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)

    z_grid = np.where(mask_land, z_grid, np.nan)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    im = m.pcolormesh(lonX, latX, z_grid, latlon=True, shading='auto', cmap='magma', vmin=-0.01, vmax=0.01)
    
    cbar = m.colorbar(im, fraction=0.02, location='right', pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('$W_{ACF}$', fontsize=32, labelpad=15)
    ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('b', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  


    ax=plt.subplot(323)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=ex1y
    on_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x, y)])
    on_ocean = ~on_land
    lons_land = lons1[on_land]
    lats_land = lats1[on_land]
    color_land0 = np.array(color)[on_land]   # 对应颜色数据同步筛选
    
    # 绘制陆地节点
    xx, yy = m(lons_land, lats_land)
    
    
    
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lons1), np.max(lons1), numcols)
    latX = np.linspace(np.max(lats1), np.min(lats1), numrows)
    # x1, y1 = m(lonX,lat)
    lonX, latX = np.meshgrid(lonX, latX)
    x1, y1 = m(lonX,latX)
    mask_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x1.ravel(), y1.ravel())])

    # mask_land = m.is_land(x.ravel(), y.ravel())   # 一维结果
    mask_land = mask_land.reshape(x1.shape)        # 还原二维掩膜
    
    z_lin  = griddata((lons1,lats1), np.array(color), (lonX, latX), method='linear')
    z_near = griddata((lons1,lats1), np.array(color), (lonX, latX), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)

    z_grid = np.where(mask_land, z_grid, np.nan)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    im = m.pcolormesh(lonX, latX, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=ll, vmax=hh)
    
    cbar = m.colorbar(im, fraction=0.02, location='right', pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Extreme Events', fontsize=32, labelpad=15)
    #ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('c', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(324)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(ex1t)*10
    on_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x, y)])
    on_ocean = ~on_land
    lons_land = lons1[on_land]
    lats_land = lats1[on_land]
    color_land0 = np.array(color)[on_land]   # 对应颜色数据同步筛选
    
    # 绘制陆地节点
    xx, yy = m(lons_land, lats_land)
    
    
    
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lons1), np.max(lons1), numcols)
    latX = np.linspace(np.max(lats1), np.min(lats1), numrows)
    # x1, y1 = m(lonX,lat)
    lonX, latX = np.meshgrid(lonX, latX)
    x1, y1 = m(lonX,latX)
    mask_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x1.ravel(), y1.ravel())])

    # mask_land = m.is_land(x.ravel(), y.ravel())   # 一维结果
    mask_land = mask_land.reshape(x1.shape)        # 还原二维掩膜
    
    z_lin  = griddata((lons1,lats1), np.array(color), (lonX, latX), method='linear')
    z_near = griddata((lons1,lats1), np.array(color), (lonX, latX), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)

    z_grid = np.where(mask_land, z_grid, np.nan)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    im = m.pcolormesh(lonX, latX, z_grid, latlon=True, shading='auto', cmap='magma', vmin=-2, vmax=2)
    
    cbar = m.colorbar(im, fraction=0.02, location='right', pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Extrend Events', fontsize=32, labelpad=15)
    #ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('d', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  


    ax=plt.subplot(325)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=hwy
    on_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x, y)])
    on_ocean = ~on_land
    lons_land = lons1[on_land]
    lats_land = lats1[on_land]
    color_land0 = np.array(color)[on_land]   # 对应颜色数据同步筛选
    
    # 绘制陆地节点
    xx, yy = m(lons_land, lats_land)
    
    
    
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lons1), np.max(lons1), numcols)
    latX = np.linspace(np.max(lats1), np.min(lats1), numrows)
    # x1, y1 = m(lonX,lat)
    lonX, latX = np.meshgrid(lonX, latX)
    x1, y1 = m(lonX,latX)
    mask_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x1.ravel(), y1.ravel())])

    # mask_land = m.is_land(x.ravel(), y.ravel())   # 一维结果
    mask_land = mask_land.reshape(x1.shape)        # 还原二维掩膜
    
    z_lin  = griddata((lons1,lats1), np.array(color), (lonX, latX), method='linear')
    z_near = griddata((lons1,lats1), np.array(color), (lonX, latX), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)

    z_grid = np.where(mask_land, z_grid, np.nan)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    im = m.pcolormesh(lonX, latX, z_grid, latlon=True, shading='auto', cmap='viridis', vmin=ll, vmax=hh)
    # ===== 添加颜色条 =====
    cbar = m.colorbar(im, fraction=0.02, location='right', pad=0.3, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Heat Waves', fontsize=32, labelpad=15)
    #ax.set_title('Temporal Mean',fontsize=38,x=0.5,y=1.03)
    ax.annotate('e', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  



    ax=plt.subplot(326)
    nodes=np.arange(8040)
    m = Basemap(projection='robin',lon_0=0,resolution='c')# draw coastlines, country boundaries, fill continents.
    m.drawcoastlines(linewidth = 3)
    
    m.drawparallels(np.arange(-90.,120.,30.),labels=[True,False,False,False],fontsize=34,linewidth=2)
    m.drawmeridians(np.arange(0.,360.,90.),labels=[False,False,False,True],fontsize=34,linewidth=2)
           
    lats1=np.array(regrid[:,1][nodes])
    lons1=np.array(regrid[:,2][nodes])
    x, y = m(lons1,lats1)

    color=np.array(hwt)*10
    on_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x, y)])
    on_ocean = ~on_land
    lons_land = lons1[on_land]
    lats_land = lats1[on_land]
    color_land0 = np.array(color)[on_land]   # 对应颜色数据同步筛选
    
    # 绘制陆地节点
    xx, yy = m(lons_land, lats_land)
    
    
    
    numcols, numrows = 360, 180
    lonX = np.linspace(np.min(lons1), np.max(lons1), numcols)
    latX = np.linspace(np.max(lats1), np.min(lats1), numrows)
    # x1, y1 = m(lonX,lat)
    lonX, latX = np.meshgrid(lonX, latX)
    x1, y1 = m(lonX,latX)
    mask_land = np.array([m.is_land(xi, yi) for xi, yi in zip(x1.ravel(), y1.ravel())])

    # mask_land = m.is_land(x.ravel(), y.ravel())   # 一维结果
    mask_land = mask_land.reshape(x1.shape)        # 还原二维掩膜
    
    z_lin  = griddata((lons1,lats1), np.array(color), (lonX, latX), method='linear')
    z_near = griddata((lons1,lats1), np.array(color), (lonX, latX), method='nearest')
    z_grid = np.where(np.isnan(z_lin), z_near, z_lin)

    z_grid = np.where(mask_land, z_grid, np.nan)
    ll=np.nanmin(z_grid) 
    hh=np.nanmax(z_grid)
    im = m.pcolormesh(lonX, latX, z_grid, latlon=True, shading='auto', cmap='magma', vmin=-1, vmax=1)
    cbar = m.colorbar(im, fraction=0.02, location='right', pad=0.3, extend='both')
    
    #cbar = plt.colorbar(im, fraction=0.02, orientation='vertical', pad=0.1, extend='both')
    cbar.ax.tick_params(labelsize=32)
    
    cbar.set_label('Heat Waves', fontsize=32, labelpad=15)
    #ax.set_title('Temporal Trend (per decade)',fontsize=38,x=0.5,y=1.03)
    ax.annotate('f', xy=(-0.05,1.04), xycoords='axes fraction', fontsize=42, weight='bold',
                         xytext=(0, -12), textcoords='offset points',color='k',rotation=0,
                         ha='left', va='bottom')  




    plt.subplots_adjust(top = 0.95, bottom = 0.1, right = 0.95, left = 0.05, 
                hspace = 0.05, wspace = 0.3)   
          
    
    figure = plt.gcf() # get current figure
                # 
    figure.set_size_inches(30, 20)
        #plt.savefig("/home/meng/fig/community_"+str(yy)+".png")     
    plt.savefig("/home/meng/awpsd/fig/fig2land.png",bbox_inches='tight')           

def function_std_1979():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ori_1979.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16715))
  
  
    outfile=open(path+"t2m_std_era5_ori_monthly3_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1979)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s-1:s+months[m]]
                a=np.std(xx)
                        
                outfile.write('%.6f \n'%(a))
                outfile.flush()      
    outfile.close()    



def function_ano_ext_1979():
    path='/home/meng/awpsd/data/'
    #outfile=open(path+'t2m_autowc10d_era5.dat','w')
    regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
    nodes=[int(i) for i in regrid[:,0]]
    temp=np.loadtxt(path+'era5t2m2.5g_ano_1979.ano')
    months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
    monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
    T=np.reshape(temp,(8040,16790))
    mt=[np.mean(T[i]) for i in range(8040)]
    st=[np.std(T[i]) for i in range(8040)]
  
  
    outfile=open(path+"t2m_era5_ano_monthly3_1980.dat",'w')
    for year in range(1980,2024):
        print (year)
        for m in range(12):
            for i in range(len(nodes)):               
                s=(year-1979)*365+monthd[m]                        
                x=T[i,s:s+months[m]]
                a=sum(x)
                b=0
                xx=T[i,s-1:s+months[m]]
                xx=np.array(xx)
                yy=np.where(xx>(mt[i]+3*st[i]))[0]
                        
                outfile.write('%.6f \n'%(a))
                outfile.flush()      
    outfile.close()    



















# def function_ano():
#     path='/home/meng/awpsd/data/'
#     #outfile=open(path+'t2m_autowc10d_era5.dat','w')
#     regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
#     nodes=[int(i) for i in regrid[:,0]]
#     temp=np.loadtxt(path+'era5t2m2.5g_ori_2006to2024.ano')
#     months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
#     monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
#     T=np.reshape(temp,(8040,6860))
#     cyc=np.loadtxt(path+'era5t2m2.5g_climate.ano')
#     mx=np.reshape(cyc[:,0],(8040,365))
#     sx=np.reshape(cyc[:,1],(8040,365))
#     outfile=open(path+"t2m_era5_ano.dat",'w')
#     for i in range(len(nodes)):
#         print (i)
#         for year in range(2006,2024):
#             #print (year)
#             for d in range(365):
#                 s=(year-2006)*365+d
#                 a=(T[i,s]-mx[i,d])/sx[i,d]
#                 outfile.write('%.6f \n'%(a))
#                 outfile.flush()   
#     outfile.close()


# def extreme_ano():
#     data=np.loadtxt(path+"t2m_era5_ano.dat")
#     datax=np.reshape(data,(8040,6570))
#     outfile=open(path+"t2m_std_ext_era5_ano.dat",'w')
#     for i in range(8040):
#         t=np.array(datax[i])
#         x=np.zeros(len(t))
#         y=np.where(abs(t)>2*np.std(t))[0]
#         x[y]=1
#         for k in range(len(x)):
#             outfile.write('%d \n'%(x[k]))
#             outfile.flush()
#     outfile.close()

# def read_extreme_y():
#     path='/home/meng/awpsd/data/'
#     #outfile=open(path+'t2m_autowc10d_era5.dat','w')
#     regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
#     nodes=[int(i) for i in regrid[:,0]]
#     temp=np.loadtxt(path+"t2m_std_ext_era5_ano.dat")
#     tau=5
#     months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
#     monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
#     T=np.reshape(temp,(8040,6570))
  
#     outfile=open(path+"t2m_ano1_ext_era5_yearly.dat",'w')
#     for year in range(2007,2024):
#         print (year)
#         for m in range(12):
#             for i in range(len(nodes)):               
#                 s=(year-2006)*365+monthd[m]                        
#                 x=T[i,s:s+365]
#                 a=sum(x)
#                 b=0
#                 xx=T[i,s-1:s+365]
#                 for j in range(months[m]):
#                     if(xx[j]==1 and xx[j-1]!=1):
#                         b+=1
                        
#                 outfile.write('%d %d \n'%(a,b))
#                 outfile.flush()      
#     outfile.close()    

        

# def read_extreme():
#     path='/home/meng/awpsd/data/'
#     #outfile=open(path+'t2m_autowc10d_era5.dat','w')
#     regrid=np.loadtxt('/home/meng/bak_bupt/newproj/data/regridcos2.5d_global.dat')
#     nodes=[int(i) for i in regrid[:,0]]
#     temp=np.loadtxt(path+'era5t2m2.5g_3std_2007to2023.ano')
#     tau=5
#     months=[31,28,31,30,31,30,31,31,30,31,30,31]            # print year
#     monthd=[0,31,59,90,120,151,181,212,243,273,304,334]
#     T=np.reshape(temp,(8040,6570))
  
#     outfile=open(path+"t2m_ano1_ext_era5_monthly.dat",'w')
#     for year in range(2007,2024):
#         print (year)
#         for m in range(12):
#             for i in range(len(nodes)):               
#                 s=(year-2006)*365+monthd[m]                        
#                 x=T[i,s:s+months[m]]
#                 a=sum(x)
#                 b=0
#                 xx=T[i,s-1:s+months[m]]
#                 for j in range(months[m]):
#                     if(xx[j]==1 and xx[j-1]!=1):
#                         b+=1
                        
#                 outfile.write('%d %d \n'%(a,b))
#                 outfile.flush()      
#     outfile.close()   



