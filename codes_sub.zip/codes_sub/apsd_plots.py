#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 18 13:01:28 2024

@author: meng
"""

import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
from numpy import pi, e





def logistic(x,mu):
	y = mu*x*(1.0-x)
	return y 
def chaost(n1,n2,x0,mu):
    x=x0
    z=np.linspace(0.0,1.0,n2-n1)
    for i in range(0,n1):
        x=logistic(x,mu)
    for i in range(n1,n2):
        x=logistic(x,mu)
        z[i-n1]=x
    return z

def autoca(x,tau,l):
    z=[]
    for t in range(-tau,0):
        x1=x[tau:l+tau]
        x2=x[tau-t:l-t+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    for t in range(0,tau):
        x1=x[tau-t:l+tau-t]
        x2=x[tau:l+tau]
        r=pearsonr(x1,x2)[0]
        z.append(abs(r))
    w=(1-np.mean(z))/np.std(z)
    return z
def autowa(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))/np.std(xx)
    return a
    
def autowb(x,tau,l):
    xx=autoca(x,tau,l)
    a=(1-np.mean(xx))
    return a

def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def awps(x,s1,l):
    n=round(l/2)
    lx=np.arange(n)
    t0=np.abs(np.fft.fft(x[s1:s1+l]))
    ta=sum(lx*t0[:n])/sum(t0[1:n])
    return ta/n




def white_noise():
    yx1=[]
    yx2=[]
    yx3=[]
    yx4=[]
    zx1=[]
    zx2=[]
    zx3=[]
    zx4=[]
    N=2000
    for i in range(100):    
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)#white noise
        fx=np.fft.fft(y)
        phx=np.angle(fx)
        fy=np.abs(fx)*e**(1j*phx)
        z=np.fft.ifft(fy)
        
        nz=sum(np.abs(fx))/len(fx)
        fw=np.ones(len(fx))*nz
        
        fyy=fw*e**(1j*phx)
        zz=np.fft.ifft(fyy)
        
        zx=np.real(z)#white noise
        zy=np.real(zz)#white noise with uniform power spectrum
    
        l=1000
        
        #print (apsdx(zx,100,l),apsdx(zy,100,l))
        zx1.append(apsdx(zx,100,l))
        zx2.append(apsdx(zy,100,l))
        zx3.append(awps(zy,100,l))
        zx4.append(awps(zx,100,l))
        
        
        
        
        xp,yp=pdswelch(zy[10:10+l],fs=100)
        zp=sum(xp*yp)
        xx=zp/50
        yx3.append(xx)
    
        xp,yp=pdswelch(zy[10:10+l],fs=20)
        zp=sum(xp*yp) 
        xx=zp/10
        yx4.append(xx)
        
        yx1.append(awps(zx,0,N))
        yx2.append(awps(zy,0,N))
    

def temp():    
    path='/home/meng/bak_bupt/newproj/data/'
    tmp=np.loadtxt(path+'era5t85075d_ano_1979to2019_g_new_726.ano')
    
    
    monthds=[0,31,59,90,120,151,181,212,243,273,304,334,365]
    months=[31,28,31,30,31,30,31,31,30,31,30,31]
    T=np.reshape(tmp,(726,15695))    
    
    psx=[]
    apsx=[]
    for i in range(1,20):
        fx=np.fft.fft(T[10][:1000])
        fx[1:500-i*20]=0
        fx[500+i*20:1000]=0
        ty=np.real(np.fft.ifft(fx))
        psx.append(awps(ty,0,100))
        apsx.append(apsdx(ty,0,100))
        xp,yp=pdswelch(ty,fs=100)
        plt.plot(xp,yp)    

def mix_test():

    
    mixwl30=[]
   
    for rx in [1]:
        N=20000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
            print (a)
        
        x=a*np.sin(2*np.pi*np.arange(N)/2.5)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1.1,0.1)
        m=len(px)
        
        sn=10
        fs=18
        tau=10
        l=3000
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        aapsdx0=[]
        awpsx0=[]
    
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                aapsdx=[]
                awpsx=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,rx)*0
                    trendx=mix+trend[:len(mix)]
                   # trendx=np.array(mix)*rx
                    w=autowa(trendx[500:],tau,l)
                    wb=autowb(trendx[500:],tau,l)
                    wx.append(w)
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:500+l],fs=30)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                    zpp=apsdx(trendx,500,l)
                    aapsdx.append(zpp)
                    awpsx.append(awps(trendx[1:],500,l))
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
                aapsdx0.append(np.mean(aapsdx))
               # awpsx0.append(np.mean(awpsx))
        plt.plot(aapsdx0)
        
                #sampx0.append(np.mean(sampx))
        mixwl30.append(wx0)
 
        
    for fx in [50,500,1000]:
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1,0.1)
        m=len(px)
        
        sn=100
        fs=18
        tau=10

        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    xr=np.arange(N)
                    trend=np.sin(2*np.pi*xr/fx)*1
                    trendx=mix+trend
                    w=autowa(trendx,tau,l)                 
                    wx.append(w)
                    wb=autowb(trendx,tau,l)                 
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:500+l],fs=l/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
        plt.plot(psdx0)

        mixwl30.append(wx0) 
        
     
    for l in range(100,1000,100):
  #  for rx in [0]:
        rx=0
        N=2000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
        
        x=a*np.sin(2*np.pi*np.arange(N)/12)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1.1,0.1)
        m=len(px)
        
        sn=100
        fs=18
        tau=10
        l=30
        
        wx0=[]
        sampx0=[]
        psdx0=[]
        wxb0=[]
        aapsdx0=[]
        
    
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
                wx=[]
                sampx=[]
                psdx=[]
                wxb=[]
                aapsdx=[]
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                    trend=pow(np.arange(N)/N,rx)*1000
                    trendx=mix+trend[:len(mix)]
                    w=autowa(trendx[500:],tau,l)
                    wb=autowb(trendx[500:],tau,l)
                    wx.append(w)
                    wxb.append(wb)
                    xp,yp=pdswelch(trendx[500:500+l],fs=l/2)
                    zp=sum(xp*yp)
                    psdx.append(zp)
                    zpp=apsdx(trendx,500,l)
                    aapsdx.append(zpp)
                  
                wx0.append(np.mean(wx))
                wxb0.append(np.mean(wxb))
                psdx0.append(np.mean(psdx))
                aapsdx0.append(np.mean(aapsdx))
        plt.plot(aapsdx0)
        
                #sampx0.append(np.mean(sampx))
        mixwl30.append(wx0)













import nolds
from scipy.interpolate import griddata

from collections import Counter
import os
os.environ['PROJ_LIB'] = r'/home/meng/anaconda3/pkgs/proj-7.2.0-h8b9fe22_0/share/proj'
from matplotlib import colors 
from numpy.random import multivariate_normal 
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from matplotlib.ticker import MultipleLocator, FormatStrFormatter 
from scipy.stats.stats import pearsonr
from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from numpy import random, histogram2d, diff
import matplotlib.pyplot as plt
from scipy.interpolate import interp2d
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
from scipy.stats import rankdata
    
from scipy.stats import gaussian_kde

import matplotlib as mpl
    
import glob
import seaborn as sns
from numpy import pi, e

def pdswelch(x,fs): 
        
    from scipy import signal
    import numpy as np
    import matplotlib.pyplot as plt
    m=fs
    f, Pxx_den = signal.welch(x, fs, nperseg=m)
   # print (sum(Pxx_den))
    return f,Pxx_den/sum(Pxx_den)


def apsdx(x,s1,l):
    xp,yp=pdswelch(x[s1:s1+l],fs=l/2)
    zp=sum(xp*yp)
    xx=zp/l*4
    return xx

def mix_test():

        N=20000
        a=0
        for i in range(12):
            a+=pow(np.sin(2*np.pi*i/12),2)/12
            print (a)
        
        x=a*np.sin(2*np.pi*np.arange(N)/2.5)
        
        b=np.sqrt(3)
        y=np.random.uniform(-b,b,N)
        wx=[]
        px=np.arange(0,1.01,0.01)
        m=len(px)
        
        sn=100
        l=3000
     
        aapsdx0=[]
    
        for p in px:
                ratio=int(N*p)
                
                z1=np.zeros(N-ratio)
                z2=np.ones(ratio)
                z=list(z1)+list(z2)
               
                aapsdx=[]
                
                for st in range(sn):        
                    np.random.shuffle(z)
                    z=np.array(z)
                    y=np.array(y)
                    x=np.array(x)
                    
                    mix=(1-z)*x+z*y
                   
                    zpp=apsdx(mix,500,l)
                    aapsdx.append(zpp)
                    
                aapsdx0.append(np.mean(aapsdx))
               # awpsx0.append(np.mean(awpsx))
        plt.plot(aapsdx0)




