#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun May 17 19:02:50 2020

@author: fanjingfang
"""

import os
os.environ['PROJ_LIB'] = r'/home/jingfang/anaconda2/share/proj'

import matplotlib
#matplotlib.use('Agg')  # Or any other X11 back-end
#from mpl_toolkits.basemap import Basemap, addcyclic, shiftgrid
from netCDF4 import Dataset
import numpy as np

import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from scipy.interpolate import interp2d
from matplotlib.colors import LogNorm    

import struct
import array
import glob
def readseaicebin1():
    import struct
    import array 
    import glob
#    with open('/home/jingfang/CLUSTER_CODE/jun/nt_201812_f17_v1.1_n.bin', 'rb') as inh:
#        indata = inh.read()
    def read_binary_file(filename):
        try:
            f = open(filename, 'rb')
            n = os.path.getsize(filename)
            data = array.array('B')
            data.read(f, n)
            f.close()
            fsize = data.__len__()
            return (fsize, data)
        
        except IOError:
            return (-1, [])
        
        # somewhere in your code
    mdays=[31,28,31,30,31,30,31,31,30,31,30,31]
    #a='/Users/fanjingfang/CLUSTER_DATA/'
    a='/p/tmp/jingfang/'
    outfile=open(a+'CODE/Python/arctic/DATA/NASSSIC/dates.dat','w')
    outfile1=open(a+'CODE/Python/arctic/DATA/NASSSIC/oceannodes.dat','w')

    num=0
    #z=[]
    for year in range(1978,2019):
        print year
        if(year==1978):
            mmin=11
        else:
            mmin=1
        mmax=13
        for month in range(mmin,mmax):
            ds=0
            for day in range(mdays[month-1]):
                label=int(year*10000+month*100+day+1)
                files=glob.glob(a+"data/seaice/NASSSIC/nt_"+str(label)+"*n.bin")
                if(len(files)!=0):
                    filename=files[0]
    #filename='/home/jingfang/CLUSTER_DATA/data/seaice/NASSSIC/nt_20181230_f17_v1.1_n.bin'
                    t = read_binary_file(filename)
                    fsize = t[0]
                        
                    if (fsize > 0):
                        data = t[1][300:]
                        #x=[i for i in range(len(data)) if 237<data[i]<251]
                        #z.append(len(x))
                        x=[i for i in range(len(data)) if data[i]<251]
                        if(num!=len(x)):
                            num=len(x)
                            outfile1.write('%d \n'%(year*10000+month*100+day+1))
                            for k in x:
                                outfile1.write('%d \n'%(k))
                                outfile1.flush()
                        ds+=1
                        outfile.write('%d %d %d \n'%(year,month,day+1))
                        outfile.flush()
                    
                        
#                else:
#                        print 'Error reading file'
    outfile.close()
    outfile1.close()
#readseaicebin1()
def regrid():
    data=np.loadtxt('/Users/fanjingfang/CLUSTER_DATA/CODE/Python/arctic/DATA/NASSSIC/oceannodes.dat')
    ls=[]
    for i in range(len(data)):
        if(data[i]>10000000):
            ls.append(i)
            print data[i]
    x1=data[ls[0]+1:ls[1]]
    x2=data[ls[1]+1:ls[2]]
    x3=data[ls[2]+1:ls[3]]
    x4=data[ls[3]+1:ls[4]]
    x5=data[ls[4]+1:]
    z=set(x1)&set(x5)
    z=list(z)


def readseaicebin():
    import struct
    import array 
#    with open('/home/jingfang/CLUSTER_CODE/jun/nt_201812_f17_v1.1_n.bin', 'rb') as inh:
#        indata = inh.read()
    def read_binary_file(filename):
        try:
            f = open(filename, 'rb')
            n = os.path.getsize(filename)
            data = array.array('B')
            data.read(f, n)
            f.close()
            fsize = data.__len__()
            return (fsize, data)
        
        except IOError:
            return (-1, [])
        
        # somewhere in your code
    mdays=[31,28,31,30,31,30,31,31,30,31,30,31]
    #a='/Users/fanjingfang/CLUSTER_DATA/'
    a='/p/tmp/jingfang/'
    data = Dataset(a+'CODE/Python/arctic/SMOD_1979-2017_v04r00.nc','r',format='NETCDF4')
    longitude=data.variables['longitude'][:]
    latitute=data.variables['latitude'][:]
    meltonset=data.variables['SMOD'][:]
# =============================================================================
#     data1=np.loadtxt(a+'CODE/Python/arctic/DATA/NASSSIC/oceannodes.dat')
#     outfile0=open(a+'CODE/Python/arctic/DATA/NASSSIC/Ocean.dat','w')
#     for i in range(1,66130):
#         outfile0.write('%d \n'%(data1[i]))
#         outfile0.flush()
#     outfile0.close()
# =============================================================================
    
    data2=np.loadtxt(a+'CODE/Python/arctic/DATA/NASSSIC/dates.dat')
    nodes=np.loadtxt(a+'CODE/Python/arctic/DATA/NASSSIC/Ocean.dat')
    nodes=[int(i) for i in nodes]
    monthds=[0,31,59,90,120,151,181,212,243,273,304,334]
    for i in range(len(data2)):
            year=data2[:,0][i]
            month=data2[:,1][i]
            day=data2[:,2][i]
            year=int(year)
            month=int(month)
            day=int(day)
            label=int(year*10000+month*100+day)
            files=glob.glob(a+"data/seaice/NASSSIC/nt_"+str(label)+"*n.bin")
            if(len(files)!=0):
                filename=files[0]
                    
    #filename='/home/jingfang/CLUSTER_DATA/data/seaice/NASSSIC/nt_20181230_f17_v1.1_n.bin'
                t = read_binary_file(filename)
                fsize = t[0]
                    
                if (fsize > 0):
                        data = t[1][300:]

                        data1 = np.asarray(data)[nodes].tolist()
    #dates=monthds[month]+day
                        outfile=open(a+"CODE/Python/arctic/DATA/NASSSIC/"+str(year)+"_"+str(month)+"_"+str(day)+".dat",'w')
                        for k in data1:
                            outfile.write('%.6f \n'%(k/250.))
                            outfile.flush()
                        outfile.close()
readseaicebin1()







