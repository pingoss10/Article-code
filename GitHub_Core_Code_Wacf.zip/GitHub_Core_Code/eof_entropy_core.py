import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr


def eof_svd(data):
    values = np.asarray(data, dtype=float)
    anomaly = values - values.mean(axis=0, keepdims=True)
    u, s, vt = np.linalg.svd(anomaly, full_matrices=False)
    eigenvalues = s ** 2 / (values.shape[0] - 1)
    probability = eigenvalues / eigenvalues.sum()
    entropy = -np.sum(probability * np.log(probability + 1e-12))
    return vt.T, u, entropy, eigenvalues


def eof_covariance(data):
    values = np.asarray(data, dtype=float)
    anomaly = values - values.mean(axis=1, keepdims=True)
    eigenvalues, eigenvectors = np.linalg.eigh(np.cov(anomaly))
    order = np.argsort(eigenvalues)[::-1]
    eigenvalues, eigenvectors = eigenvalues[order], eigenvectors[:, order]
    probability = eigenvalues / eigenvalues.sum()
    entropy = -np.sum(probability * np.log(probability + 1e-12))
    return eigenvectors, eigenvectors.T @ anomaly, eigenvalues, entropy


def windowed_eof_entropy(spatial_time_series, windows, spatial_indices=None):
    values = np.asarray(spatial_time_series, dtype=float)
    if spatial_indices is not None:
        values = values[np.asarray(spatial_indices)]
    return np.array([eof_svd(values[:, start:end].T)[2] for start, end in windows])


def hemispheric_means(monthly_grid_metrics, northern_nodes):
    values = np.asarray(monthly_grid_metrics, dtype=float)
    return values[:, :northern_nodes].mean(axis=1), values[:, northern_nodes:].mean(axis=1)


def preceding_mean(monthly_values, window=12):
    values = np.asarray(monthly_values, dtype=float)
    return np.array([values[i-window:i].mean() for i in range(window, len(values))])


def entropy_metric_relationship(metric, entropy, months=12):
    n = min(len(metric), len(entropy))
    a, b = preceding_mean(metric[:n], months), preceding_mean(entropy[:n], months)
    correlation, pvalue = pearsonr(a, b)
    return {'metric': a, 'entropy': b, 'r': correlation, 'p': pvalue}


def plot_entropy_relationship(north, south):
    fig, axes = plt.subplots(2, 2, figsize=(10, 6), layout='constrained')
    for row, result in enumerate((north, south)):
        ax = axes[row, 0]
        ax.plot(result['metric'], label='Metric')
        ax.plot(result['entropy'], label='Entropy')
        ax.legend()
        axes[row, 1].scatter(result['metric'], result['entropy'], s=6)
        axes[row, 1].set(xlabel='Metric', ylabel='EOF entropy')
    return fig
