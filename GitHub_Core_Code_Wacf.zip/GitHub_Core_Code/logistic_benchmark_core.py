from __future__ import annotations


import numpy as np


import pandas as pd


import matplotlib.pyplot as plt


from scipy.stats import pearsonr


from scipy.spatial import cKDTree


from numpy.lib.stride_tricks import sliding_window_view


def generate_logistic(mu: float, x0: float, n: int, burn_in: int=1000) -> np.ndarray:
    x = float(x0)
    for _ in range(burn_in):
        x = mu * x * (1.0 - x)
    out = np.empty(n, dtype=float)
    for i in range(n):
        x = mu * x * (1.0 - x)
        out[i] = x
    return out


def add_trend(x: np.ndarray, kind: str) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    t = np.arange(len(x), dtype=float)
    if kind == 'clean':
        return x.copy()
    if kind == 'exp':
        return x + np.exp(4.0 * t / len(x))
    if kind == 'periodic':
        return x + np.sin(2.0 * np.pi * t / 500.0)
    raise ValueError(f'Unknown trend kind: {kind}')


def detrend_poly(x: np.ndarray, degree: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    t = np.arange(len(x), dtype=float)
    coef = np.polyfit(t, x, degree)
    return x - np.polyval(coef, t)


def calc_wacf(x: np.ndarray, tau_max: int=100) -> float:
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n <= 2 * tau_max:
        return np.nan
    length = n - 2 * tau_max
    x1 = x[tau_max:tau_max + length]
    starts = np.arange(0, 2 * tau_max + 1)[:, None]
    offsets = np.arange(length)[None, :]
    X = x[starts + offsets]
    a = x1 - x1.mean()
    B = X - X.mean(axis=1, keepdims=True)
    den = np.sqrt(np.sum(a * a) * np.sum(B * B, axis=1))
    r = np.divide(B @ a, den, out=np.full(len(X), np.nan, dtype=float), where=den > 0)
    vals = np.abs(r)
    mean_ac = np.nanmean(vals)
    std_ac = np.nanstd(vals)
    if not np.isfinite(std_ac) or std_ac == 0:
        return np.nan
    return float((1.0 - mean_ac) / (std_ac * np.sqrt(2.0 * tau_max)))


def calc_sample_entropy(x: np.ndarray, m: int=2, r_ratio: float=0.2) -> float:
    x = np.asarray(x, dtype=float)
    r = r_ratio * np.std(x)
    if not np.isfinite(r) or r <= 0:
        return np.nan

    def count_pairs(dim: int) -> float:
        emb = sliding_window_view(x, dim)
        tree = cKDTree(emb)
        return (tree.count_neighbors(tree, r, p=np.inf) - len(emb)) / 2.0
    B = count_pairs(m)
    A = count_pairs(m + 1)
    if A <= 0 or B <= 0:
        return np.nan
    return float(-np.log(A / B))


def calc_ac1(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    a = x[:-1]
    b = x[1:]
    if np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(pearsonr(a, b)[0])


def calc_lyapunov_rosenstein(x: np.ndarray, emb_dim: int=3, lag: int=1, min_tsep: int=30, trajectory_len: int=30) -> float:
    x = np.asarray(x, dtype=float)
    m = len(x) - (emb_dim - 1) * lag
    if m <= trajectory_len + 1:
        return np.nan
    idx = np.arange(m)[:, None] + np.arange(emb_dim)[None, :] * lag
    emb = x[idx]
    usable = m - trajectory_len
    if usable < 10:
        return np.nan
    tree = cKDTree(emb[:usable])
    k_query = min(50, usable)
    _, idxs = tree.query(emb[:usable], k=k_query)
    neigh = np.full(usable, -1, dtype=int)
    for i in range(usable):
        for j in np.atleast_1d(idxs[i])[1:]:
            j = int(j)
            if abs(j - i) > min_tsep and j < usable:
                neigh[i] = j
                break
    valid = np.where(neigh >= 0)[0]
    if len(valid) < 10:
        return np.nan
    divergence = np.full((len(valid), trajectory_len), np.nan, dtype=float)
    for row, i in enumerate(valid):
        j = neigh[i]
        diff = emb[i:i + trajectory_len] - emb[j:j + trajectory_len]
        distance = np.linalg.norm(diff, axis=1)
        divergence[row] = np.log(np.maximum(distance, 1e-12))
    mean_log = np.nanmean(divergence, axis=0)
    t = np.arange(trajectory_len, dtype=float)
    mask = np.isfinite(mean_log)
    if mask.sum() < 2:
        return np.nan
    return float(np.polyfit(t[mask], mean_log[mask], 1)[0])


def calc_dfa(x: np.ndarray, order: int=1) -> float:
    x = np.asarray(x, dtype=float)
    y = np.cumsum(x - np.mean(x))
    n = len(y)
    max_scale = n // 4
    min_scale = max(4, order + 2)
    if max_scale <= min_scale:
        return np.nan
    scales = np.unique(np.floor(np.logspace(np.log10(min_scale), np.log10(max_scale), 20)).astype(int))
    ss = []
    ff = []
    for scale in scales:
        k = n // scale
        if k < 2:
            continue
        seg = y[:k * scale].reshape(k, scale)
        t = np.arange(scale, dtype=float)
        X = np.vander(t, N=order + 1, increasing=True)
        pinv = np.linalg.pinv(X)
        trend = (X @ (pinv @ seg.T)).T
        fluct = np.sqrt(np.mean((seg - trend) ** 2))
        if np.isfinite(fluct) and fluct > 0:
            ss.append(scale)
            ff.append(fluct)
    if len(ss) < 2:
        return np.nan
    return float(np.polyfit(np.log(ss), np.log(ff), 1)[0])


def calc_laminarity(x: np.ndarray, eps_factor: float=0.1, vmin: int=2) -> float:
    x = np.asarray(x, dtype=float)
    eps = eps_factor * np.std(x)
    if not np.isfinite(eps) or eps <= 0:
        return np.nan
    xs = np.sort(x)

    def count_interval(lo: float, hi: float) -> int:
        if lo > hi:
            return 0
        right = np.searchsorted(xs, hi, side='right')
        left = np.searchsorted(xs, lo, side='left')
        return int(right - left)
    den = 0
    num = 0
    n = len(x)
    for i, xi in enumerate(x):
        lo0, hi0 = (xi - eps, xi + eps)
        den += count_interval(lo0, hi0)
        intervals = []
        if i > 0:
            intervals.append((max(lo0, x[i - 1] - eps), min(hi0, x[i - 1] + eps)))
        if i < n - 1:
            intervals.append((max(lo0, x[i + 1] - eps), min(hi0, x[i + 1] + eps)))
        intervals = [z for z in intervals if z[0] <= z[1]]
        if not intervals:
            continue
        intervals.sort()
        lo, hi = intervals[0]
        subtotal = 0
        for lo2, hi2 in intervals[1:]:
            if lo2 <= hi:
                hi = max(hi, hi2)
            else:
                subtotal += count_interval(lo, hi)
                lo, hi = (lo2, hi2)
        subtotal += count_interval(lo, hi)
        num += subtotal
    return np.nan if den == 0 else float(num / den)


def _opps_symbols(x: np.ndarray, n: int=3, tau: int=1) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    m = len(x) - (n - 1) * tau
    if m <= 0:
        return np.empty(0, dtype=np.int64)
    idx = np.arange(m)[:, None] + np.arange(n)[None, :] * tau
    windows = x[idx]
    tied = np.ptp(windows, axis=1) == 0
    p = np.argsort(windows, axis=1, kind='stable') + 1
    d = np.diff(p, axis=1)
    pos = np.argmax(d, axis=1) + 1
    smax = d[np.arange(m), pos - 1]
    sym = pos.astype(np.int64) * (2 * n + 1) + (smax + n).astype(np.int64)
    sym[tied] = 0
    return sym


def _uniq_groups(sym: np.ndarray, q: int) -> int:
    if len(sym) < q:
        return 0
    sym = np.asarray(sym, dtype=np.int64)
    base = int(sym.max()) + 2 if len(sym) else 2
    groups = sliding_window_view(sym, q)
    powers = base ** np.arange(q - 1, -1, -1, dtype=np.int64)
    codes = groups @ powers
    return int(np.unique(codes).size)


def _copps_r(x: np.ndarray, n: int, s: int, tau_max: int) -> float:
    A = (n - 1) ** 2 + 1
    q = s + 1
    lam = A ** q
    vals = []
    for tau in range(1, tau_max + 1):
        R = _uniq_groups(_opps_symbols(x, n, tau), q)
        vals.append(0.0 if R <= 0 else (R - 1) / (lam - 1))
    vals = np.asarray(vals, dtype=float)
    if np.any(vals <= 0) or np.any(~np.isfinite(vals)):
        return 0.0
    return float(np.exp(np.mean(np.log(vals))))


def calc_copps(x: np.ndarray, n: int=3, s: int=1, tau_max: int=100) -> float:
    rs = _copps_r(x, n, s, tau_max)
    rsp = _copps_r(x, n, s + 1, tau_max)
    if rs == 0 and rsp == 0:
        return 0.0
    if rs <= 0:
        return np.nan
    return float(rsp / rs)


def nanmeanstd(values) -> tuple[float, float]:
    a = np.asarray(values, dtype=float)
    if not np.any(np.isfinite(a)):
        return (np.nan, np.nan)
    return (float(np.nanmean(a)), float(np.nanstd(a)))




def compute_experiment(mu_values, length, trend='clean', repeats=10, seed=42):
    rng = np.random.default_rng(seed)
    mu_values = np.asarray(mu_values, dtype=float)
    initial_conditions = np.clip(rng.random((repeats, len(mu_values))), 1e-6, 1 - 1e-6)
    lle_options = dict(emb_dim=3, lag=1, min_tsep=30, trajectory_len=30) if length == 2000 else dict(emb_dim=3, lag=1, min_tsep=5, trajectory_len=10)
    wacf_taus = (10, 20, 50) if length == 2000 else (10,)
    copps_tau = 100 if length == 2000 else 3
    rows = []
    for i, mu in enumerate(mu_values):
        measurements = {key: [] for key in ('sampen', 'lyap', 'dfa1', 'dfa2', 'ac1_deg1', 'ac1_deg2', 'lam', 'copps')}
        measurements.update({f'wacf_tau{tau}': [] for tau in wacf_taus})
        for initial in initial_conditions[:, i]:
            x = add_trend(generate_logistic(mu, initial, length, 1000), trend)
            for tau in wacf_taus:
                measurements[f'wacf_tau{tau}'].append(calc_wacf(x, tau))
            measurements['sampen'].append(calc_sample_entropy(x, 2, 0.2))
            measurements['lyap'].append(calc_lyapunov_rosenstein(x, **lle_options))
            measurements['dfa1'].append(calc_dfa(x, order=1))
            measurements['dfa2'].append(calc_dfa(x, order=2))
            measurements['ac1_deg1'].append(calc_ac1(detrend_poly(x, 1)))
            measurements['ac1_deg2'].append(calc_ac1(detrend_poly(x, 2)))
            measurements['lam'].append(calc_laminarity(x, 0.1, 2))
            measurements['copps'].append(calc_copps(x, 3, 1, copps_tau))
        row = {'mu': mu}
        for key, values in measurements.items():
            mean, std = nanmeanstd(values)
            row[f'{key}_mean'], row[f'{key}_std'] = mean, std
        if length != 2000:
            row['wacf_mean'], row['wacf_std'] = row['wacf_tau10_mean'], row['wacf_tau10_std']
        rows.append(row)
    return pd.DataFrame(rows)


def plot_experiment(table):
    metrics = [name[:-5] for name in table if name.endswith('_mean')]
    fig, axes = plt.subplots((len(metrics) + 2) // 3, 3, figsize=(11, 3.2 * ((len(metrics) + 2) // 3)), squeeze=False, layout='constrained')
    for ax, metric in zip(axes.flat, metrics):
        x, center = table['mu'], table[f'{metric}_mean']
        ax.plot(x, center)
        deviation = table.get(f'{metric}_std')
        if deviation is not None:
            ax.fill_between(x, center - deviation, center + deviation, alpha=0.15)
        ax.set(xlabel=r'$\mu$', ylabel=metric)
    for ax in list(axes.flat)[len(metrics):]:
        ax.set_visible(False)
    return fig

