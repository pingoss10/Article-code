import numpy as np
import matplotlib.pyplot as plt
from wacf_core import lagged_abs_autocorrelation, logistic_series, spectral_components, wacf


def autocorrelation_examples(length=2000, tau=100):
    rng = np.random.default_rng(42)
    noise = rng.uniform(-1, 1, length)
    filtered, complement = spectral_components(noise, 20)
    trend = complement + 100 * np.arange(length) / length
    return [lagged_abs_autocorrelation(x, tau, length - 2 * tau) for x in (noise, filtered, trend)]


def logistic_curves(mu_values, length=1000, tau=10, realizations=10):
    rng = np.random.default_rng(42)
    curves = []
    for scale in (0.5, 1.0, 2.0):
        values = []
        for mu in mu_values:
            replicates = []
            for _ in range(realizations):
                series = logistic_series(mu, length, rng.random())
                modified = series + 1000 * (np.arange(length) / length) ** scale
                replicates.append(wacf(modified, tau, length - 2 * tau))
            values.append(np.mean(replicates))
        curves.append(values)
    return np.asarray(curves)


def plot_figure1(autocorrelations, mu_values, logistic_values, benchmark, accuracy):
    fig = plt.figure(figsize=(11, 8), layout='constrained')
    layout = fig.add_gridspec(3, 3)
    axes = [fig.add_subplot(layout[i, 0]) for i in range(3)]
    axes += [fig.add_subplot(layout[:2, 1]), fig.add_subplot(layout[:2, 2]), fig.add_subplot(layout[2, 1]), fig.add_subplot(layout[2, 2])]
    for ax, values, name in zip(axes[:3], autocorrelations, ('Original', 'Filtered', 'Trend')):
        ax.plot(np.arange(len(values)) - len(values) // 2, values)
        ax.set_ylabel(name)
    for ax, samples in zip((axes[3], axes[5]), (benchmark.get('mixture', {}), benchmark.get('logistic', {}))):
        for name, pair in samples.items():
            x, y = pair
            ax.plot(x, y, label=name)
        ax.legend(frameon=False)
    for name, values in zip(('Trend 0.5', 'Trend 1', 'Trend 2'), np.asarray(logistic_values)[:3]):
        axes[4].plot(mu_values, values, label=name)
    axes[4].legend(frameon=False)
    for name, values in accuracy.items():
        axes[6].plot(np.linspace(0, 100, len(values)), values, label=name)
    axes[6].legend(frameon=False)
    axes[6].set_xlabel('Noise ratio (%)')
    return fig
