import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import detrend
from scipy.stats import pearsonr, percentileofscore, gaussian_kde


def shuffled_phase_surrogate(series, rng=None):
    rng = np.random.default_rng() if rng is None else rng
    spectrum = np.fft.fft(np.asarray(series, dtype=float))
    phases = np.angle(spectrum).copy()
    rng.shuffle(phases)
    return np.fft.ifft(np.abs(spectrum) * np.exp(1j * phases)).real


def preceding_rolling_mean(monthly_values, months=12):
    data = np.asarray(monthly_values, dtype=float)
    if data.ndim != 2 or data.shape[0] <= months:
        raise ValueError('Expected a (months, grid_cells) array longer than the rolling window')
    prefix = np.vstack((np.zeros((1, data.shape[1])), np.cumsum(data, axis=0)))
    return (prefix[months:-1] - prefix[:-months - 1]) / months


def lagged_predictability_test(monthly_metric, monthly_prediction, window=12, surrogates=100, seed=42):
    metric = np.asarray(monthly_metric, dtype=float)
    prediction = np.abs(np.asarray(monthly_prediction, dtype=float))
    if metric.shape != prediction.shape:
        raise ValueError('Metric and prediction arrays must have identical shapes')
    x = preceding_rolling_mean(metric, window)
    y = preceding_rolling_mean(prediction, window)
    rng = np.random.default_rng(seed)
    correlations = np.empty(x.shape[1], dtype=float)
    percentiles = np.empty(x.shape[1], dtype=float)
    null_correlations = np.empty((x.shape[1], surrogates), dtype=float)
    for i in range(x.shape[1]):
        a, b = detrend(x[:, i]), detrend(y[:, i])
        correlations[i] = pearsonr(a, b).statistic
        samples = [pearsonr(shuffled_phase_surrogate(a, rng), shuffled_phase_surrogate(b, rng)).statistic for _ in range(surrogates)]
        null_correlations[i] = samples
        percentiles[i] = percentileofscore(samples, correlations[i], kind='weak')
    return {'r': correlations, 'percentile': percentiles, 'null': null_correlations,
            'mean_metric': metric.mean(axis=0), 'mean_prediction': prediction.mean(axis=0)}


def plot_predictability(results):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4), layout='constrained')
    values = [(results['mean_metric'], results['mean_prediction']),
              (results['r'], results['percentile'])]
    for ax, (x, y), xlabel, ylabel in zip(axes, values, ('Metric mean', 'Observed correlation'), ('Prediction mean', 'Null percentile')):
        mask = np.isfinite(x) & np.isfinite(y)
        x, y = x[mask], y[mask]
        if len(x) > 2 and np.std(x) > 0 and np.std(y) > 0:
            density = gaussian_kde(np.vstack((x, y)))(np.vstack((x, y)))
            ax.scatter(x, y, c=density, s=6)
        else:
            ax.scatter(x, y, s=6)
        ax.set(xlabel=xlabel, ylabel=ylabel)
    return fig
