import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import griddata
from mpl_toolkits.basemap import Basemap


def significant_region_counts(observed):
    significant = np.asarray(observed)[:, 1] < 0.05
    return np.array([significant[:2796].sum(), significant[2796:5244].sum(), significant[5244:].sum()])


def null_region_counts(null_sample):
    sample = np.asarray(null_sample, dtype=float)
    return np.column_stack((sample[:, 1], sample[:, 0] - sample[:, 1] - sample[:, 2], sample[:, 2]))


def map_panel(ax, grid, observed, central_longitude=0):
    coords = np.asarray(grid, dtype=float)
    values = np.asarray(observed, dtype=float)
    lat, lon = coords[:, 1], coords[:, 2]
    longitude, latitude = np.meshgrid(np.linspace(lon.min(), lon.max(), 360), np.linspace(lat.max(), lat.min(), 180))
    linear = griddata((lon, lat), values[:, 0], (longitude, latitude), method='linear')
    nearest = griddata((lon, lat), values[:, 0], (longitude, latitude), method='nearest')
    surface = np.where(np.isfinite(linear), linear, nearest)
    basemap = Basemap(projection='robin', lon_0=central_longitude, resolution='c', ax=ax)
    basemap.drawcoastlines(linewidth=0.5)
    mesh = basemap.pcolormesh(longitude, latitude, surface, latlon=True, shading='auto', cmap='RdBu_r')
    selected = values[:, 1] < 0.05
    x, y = basemap(lon[selected], lat[selected])
    basemap.scatter(x, y, s=2, color='black')
    return mesh


def regional_boxplot(ax, null_data, observed, labels=('North', 'Tropical', 'South')):
    null_values = null_region_counts(null_data)
    actual = significant_region_counts(observed)
    ax.boxplot([null_values[:, j] for j in range(3)], labels=labels, whis=(5, 95), showfliers=False)
    ax.scatter(np.arange(1, 4), actual, color='C3', zorder=3)
    ax.set_ylabel('Significant grid cells')
    return actual


def plot_figure4(grid, observed_data, null_data):
    names = ('AO', 'IOD', 'ONI', 'AAO')
    fig, axes = plt.subplots(2, 4, figsize=(14, 6), layout='constrained')
    for index, name in enumerate(names):
        mesh = map_panel(axes[0, index], grid, observed_data[name], 0 if name in ('AO', 'AAO') else -180)
        fig.colorbar(mesh, ax=axes[0, index], shrink=0.6)
        axes[0, index].set_title(name)
        regional_boxplot(axes[1, index], null_data[name], observed_data[name])
    return fig
