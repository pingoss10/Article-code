import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress


def hemispheric_mean(wacf_data):
    values = np.asarray(wacf_data, dtype=float).reshape(528, 8040)
    return values[:, :4020].mean(axis=1), values[:, 4020:].mean(axis=1)


def entropy_from_modes(mode_data):
    values = np.asarray(mode_data, dtype=float)
    if values.ndim == 1:
        values = values.reshape(28, -1)
    elif values.shape[1] == 28 and values.shape[0] != 28:
        values = values.T
    return values[-1]


def centered_smooth(values):
    return pd.Series(np.asarray(values, dtype=float)).rolling(12, center=True, min_periods=1).mean().to_numpy()


def trend_and_growth(dates, values):
    table = pd.DataFrame({'year': pd.DatetimeIndex(dates).year, 'value': values}).dropna()
    annual = table.groupby('year').value.mean()
    result = linregress(annual.index.to_numpy(dtype=float), annual.to_numpy(dtype=float))
    first = annual.loc[1980:1989].mean()
    last = annual.loc[2014:2023].mean()
    slope_decade = 10 * result.slope
    return {'trend_decade': slope_decade, 'relative_trend_percent_decade': 100 * slope_decade / annual.mean(), 'growth_percent': 100 * (last - first) / first, 'r': result.rvalue, 'p': result.pvalue}


def plot_figure3(wacf_data, north_modes, south_modes, correlations):
    north_wacf, south_wacf = hemispheric_mean(wacf_data)
    hemispheres = [(north_wacf, entropy_from_modes(north_modes)), (south_wacf, entropy_from_modes(south_modes))]
    fig, axes = plt.subplots(2, 2, figsize=(10, 6), gridspec_kw={'width_ratios': [2, 1]}, layout='constrained')
    for row, (wacf_values, entropy_values) in enumerate(hemispheres):
        n = min(len(wacf_values), len(entropy_values))
        dates = pd.date_range('1980-01-01', periods=n, freq='MS')
        axes[row, 0].plot(dates, centered_smooth(wacf_values[:n]), label='WACF')
        right = axes[row, 0].twinx()
        right.plot(dates, centered_smooth(entropy_values[:n]), color='C1', label='Entropy')
        axes[row, 0].set_title(('Northern', 'Southern')[row] + ' Hemisphere')
        label = ('north', 'south')[row]
        for name in ('wa', 'en'):
            data = np.asarray(correlations[f'{label}_{name}'], dtype=float)
            axes[row, 1].plot(np.arange(3, min(len(data), 28)), data[3:28, 1], label=name)
        axes[row, 1].set_xlabel('Number of modes')
        axes[row, 1].set_ylabel('Correlation')
        axes[row, 1].legend(frameon=False)
    return fig
