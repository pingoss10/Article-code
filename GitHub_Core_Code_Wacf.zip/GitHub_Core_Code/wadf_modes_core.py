import matplotlib.pyplot as plt
from figure4_core import map_panel, significant_region_counts, null_region_counts


def modes_summary(observed_data, null_data):
    return {name: {'observed': significant_region_counts(observed_data[name]), 'null': null_region_counts(null_data[name])} for name in ('AO', 'IOD', 'ONI', 'AAO')}


def plot_wacf_modes(grid, observed_data):
    names = ('AO', 'IOD', 'ONI', 'AAO')
    fig, axes = plt.subplots(2, 2, figsize=(10, 7), layout='constrained')
    for ax, name in zip(axes.flat, names):
        mesh = map_panel(ax, grid, observed_data[name], 0 if name in ('AO', 'AAO') else -180)
        fig.colorbar(mesh, ax=ax, shrink=0.7)
        ax.set_title(name)
    return fig
