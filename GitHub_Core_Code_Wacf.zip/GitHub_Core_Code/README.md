# Core analysis and figure code

This repository contains a streamlined collection of analysis methods and visualization functions extracted from ten research scripts. The core calculations are retained while local file paths, extensive plot styling, repeated imports, executable exploratory snippets, and inline source comments are omitted.

| File | Core functionality |
| --- | --- |
| `wacf_core.py` | Lagged absolute autocorrelation, WACF, Fourier components, DFA and related metrics |
| `figure1_core.py` | Synthetic time-series experiments and Figure 1 visualizations |
| `figure3_core.py` | Hemispheric WACF and entropy series, trend summaries, Figure 3 |
| `figure4_core.py` | Spatial correlation maps, significant-node counts, null distributions, Figure 4 |
| `figure4_single_box_core.py` | Combined regional significance boxplots |
| `wadf_modes_core.py` | Spatial mode comparison and regional significance summaries |
| `logistic_benchmark_core.py` | Five logistic-map benchmark configurations; WACF, SampEn, LLE, DFA-1/2, detrended AC(1), laminarity and COPPS; compact plotting |
| `extreme_event_core.py` | Annual aggregation of monthly extremes and WACF/DFA metrics, Mann–Kendall trends, spatial correlations |
| `predictability_core.py` | Preceding-window metric/predictability relationships, linear detrending, phase-shuffled null distributions, correlation percentiles |
| `eof_entropy_core.py` | SVD/covariance EOF decomposition, eigenvalue-based entropy, spatial windowing and hemispheric relationships |

All functions receive their input arrays directly; no machine-specific `F:/...` or `/home/...` paths are required. The repository does not include the underlying ERA5 and derived observational data. The code is a concise methods extract and does not independently recreate every figure from the original scripts.

The logistic benchmark follows the uploaded `AC1` script: its lag-one statistic is Pearson AC(1), **not** a fitted AR(1) model. The null samples in `predictability_core.py` preserve the original script's phase-shuffle-then-real-IFFT procedure, which is not a strict power-spectrum-preserving Fourier surrogate. It should not be described as preserving each time series' power spectrum without additional verification.

Install dependencies using `pip install -r requirements.txt`. `basemap` is needed for the previously included spatial map functions; `pymannkendall` is needed for Mann–Kendall trends. Functions that depend on external observational arrays cannot run without user-supplied data.

The four newly added modules have passed Python syntax checks and small numerical smoke tests for their available computational paths. The Mann–Kendall function requires the optional runtime dependency `pymannkendall` and was not exercised in the smoke tests. No full-data replication or figure-by-figure numerical equivalence check has been performed.
