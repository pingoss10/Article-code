import numpy as np
from scipy.signal import welch
from scipy.stats import linregress, pearsonr


def logistic_series(mu, n, x0=0.05, burn_in=500):
    x = float(x0)
    result = np.empty(n)
    for i in range(n + burn_in):
        x = mu * x * (1 - x)
        if i >= burn_in:
            result[i - burn_in] = x
    return result


def lagged_abs_autocorrelation(x, tau, length):
    x = np.asarray(x, dtype=float)
    if tau < 1 or length < 3 or len(x) < length + 2 * tau:
        raise ValueError('Invalid lag window or time-series length')
    return np.array([abs(pearsonr(x[tau:tau + length], x[tau + lag:tau + lag + length]).statistic) for lag in range(-tau, tau + 1)])


def wacf(x, tau, length):
    correlations = lagged_abs_autocorrelation(x, tau, length)
    return (1 - correlations.mean()) / correlations.std()


def wacf_normalized(x, tau, length):
    return wacf(x, tau, length) / np.sqrt(2 * tau)


def wacf_unscaled(x, tau, length):
    return 1 - lagged_abs_autocorrelation(x, tau, length).mean()


def spectral_components(x, cutoff):
    spectrum = np.fft.fft(np.asarray(x, dtype=float))
    n = len(spectrum)
    keep = np.zeros(n, dtype=bool)
    keep[:cutoff] = True
    keep[-cutoff:] = True
    low = np.where(keep, spectrum, spectrum * np.exp(-10))
    high = np.where(keep, spectrum * np.exp(-10), spectrum)
    return np.fft.ifft(low).real, np.fft.ifft(high).real


def normalized_welch_spectrum(x, fs):
    frequencies, power = welch(np.asarray(x, dtype=float), fs=fs, nperseg=int(fs))
    return frequencies, power / power.sum()


def dfa(x, min_window=4, max_window=None, window_step=1, order=1):
    x = np.asarray(x, dtype=float)
    profile = np.cumsum(x - x.mean())
    upper = max_window if max_window is not None else len(x) // 4
    windows = np.arange(min_window, upper + 1, window_step)
    fluctuations = []
    for width in windows:
        rms = []
        for start in range(0, len(profile) - width + 1, width):
            segment = profile[start:start + width]
            fitted = np.polyval(np.polyfit(np.arange(width), segment, order), np.arange(width))
            rms.append(np.sqrt(np.mean((segment - fitted) ** 2)))
        fluctuations.append(np.mean(rms))
    fluctuations = np.asarray(fluctuations)
    slope = linregress(np.log10(windows), np.log10(fluctuations)).slope
    return windows, fluctuations, slope


def mixture_series(ratio, length, rng=None):
    rng = np.random.default_rng() if rng is None else rng
    time = np.arange(length)
    sinusoid = np.mean(np.sin(2 * np.pi * np.arange(12) / 12) ** 2) * np.sin(2 * np.pi * time / 12)
    noise = rng.uniform(-np.sqrt(3), np.sqrt(3), length)
    replace = rng.permutation(length) < int(length * ratio)
    return np.where(replace, noise, sinusoid)


def logistic_wacf_curve(mu_values, length, tau, segment_length, realizations=1, rng=None):
    rng = np.random.default_rng() if rng is None else rng
    return np.array([np.mean([wacf(logistic_series(mu, length + 2 * tau, rng.random()), tau, segment_length) for _ in range(realizations)]) for mu in mu_values])
