import numpy as np
import matplotlib.pyplot as plt
from figure4_core import map_panel, significant_region_counts, null_region_counts


def combined_boxplot(ax, observed_data, null_data):
    names = ('AO', 'IOD', 'ONI', 'AAO')
    positions = np.arange(12).reshape(4, 3) + 1
    for i, name in enumerate(names):
        samples = null_region_counts(null_data[name])
        actual = significant_region_counts(observed_data[name])
        ax.boxplot([samples[:, j] for j in range(3)], positions=positions[i], widths=0.55, whis=(5, 95), showfliers=False)
        ax.scatter(positions[i], actual, color='C3', s=18, zorder=3)
    ax.set_xticks(positions.mean(axis=1), names)
    ax.set_ylabel('Significant grid cells')
    return ax


def plot_figure4_single_box(grid, observed_data, null_data):
    names = ('AO', 'IOD', 'ONI', 'AAO')
    fig = plt.figure(figsize=(12, 8), layout='constrained')
    layout = fig.add_gridspec(3, 4)
    for i, name in enumerate(names):
        ax = fig.add_subplot(layout[:2, i])
        mesh = map_panel(ax, grid, observed_data[name], 0 if name in ('AO', 'AAO') else -180)
        ax.set_title(name)
        fig.colorbar(mesh, ax=ax, shrink=0.6)
    combined_boxplot(fig.add_subplot(layout[2, :]), observed_data, null_data)
    return fig
