import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde, pearsonr


def annual_extreme_metrics(monthly_metric, monthly_extremes):
    metric = np.asarray(monthly_metric, dtype=float)
    extremes = np.asarray(monthly_extremes, dtype=float)
    if metric.shape != extremes.shape or metric.ndim != 2 or metric.shape[0] % 12:
        raise ValueError('Inputs must have identical (months, grid_cells) shapes and complete years')
    years = metric.shape[0] // 12
    annual_metric = metric.reshape(years, 12, -1).mean(axis=1).T
    annual_extremes = extremes.reshape(years, 12, -1).sum(axis=1).T
    return annual_metric, annual_extremes


def gridpoint_trends(annual_values):
    import pymannkendall as mk
    values = np.asarray(annual_values, dtype=float)
    results = [mk.original_test(row) for row in values]
    return {'slope': np.array([r.slope for r in results]), 'p': np.array([r.p for r in results]), 'z': np.array([r.z for r in results])}


def analyze_extreme_relationship(monthly_metric, monthly_extremes):
    metric, extremes = annual_extreme_metrics(monthly_metric, monthly_extremes)
    metric_trends, extreme_trends = gridpoint_trends(metric), gridpoint_trends(extremes)
    mean_metric, mean_extremes = metric.mean(axis=1), extremes.mean(axis=1)
    mean_r, mean_p = pearsonr(mean_metric, mean_extremes)
    trend_r, trend_p = pearsonr(metric_trends['z'], extreme_trends['z'])
    return {'mean_metric': mean_metric, 'mean_extremes': mean_extremes,
            'metric_trends': metric_trends, 'extreme_trends': extreme_trends,
            'mean_correlation': (mean_r, mean_p), 'trend_correlation': (trend_r, trend_p)}


def plot_extreme_relationship(results):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4), layout='constrained')
    samples = [(results['mean_metric'], results['mean_extremes']),
               (results['metric_trends']['z'], results['extreme_trends']['z'])]
    for ax, (x, y), xlab, ylab in zip(axes, samples, ('Metric mean', 'Metric trend (Z)'), ('Extreme-event mean', 'Extreme-event trend (Z)')):
        valid = np.isfinite(x) & np.isfinite(y)
        x, y = x[valid], y[valid]
        if len(x) > 2 and np.linalg.matrix_rank(np.stack([x, y])) == 2:
            density = gaussian_kde(np.vstack((x, y)))(np.vstack((x, y)))
            ax.scatter(x, y, c=density, s=6)
        else:
            ax.scatter(x, y, s=6)
        ax.set(xlabel=xlab, ylabel=ylab)
    return fig
